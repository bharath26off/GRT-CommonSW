﻿using System;
using System.Threading;
using System.Windows.Forms;
using Advantech;
using ExceptionLib;
using Master;
using Program;
using UI_Forms;


namespace Master
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            bool isNewInstance;
            using (Mutex mutex = new Mutex(true, "MyUniqueAppMutexName1", out isNewInstance))
            {
                ErrorManage errorManage = new ErrorManage();   
                if (isNewInstance)
                {                    
                    Application.EnableVisualStyles();

                    // LOADING INITIAL CONFIGS
                    GlobalVariable.LoadMachineDetails(); //*****file from :\Data\Config.txt
                    GlobalVariable.DIDO.LoadConfig();
                    GlobalVariable.DIDO.Card_Init();
                    GlobalVariable.DIDO.AxisLoad();
                    GlobalVariable.LoadAlarmCode();

                    //**devchange: OBJECTLIST
                    ObjectList.ConnectAllObj();
                    IO_Stepper.IO_Stepper_Config.LoadConvSteppersFromXml();
                    GlobalVariable.Update_Settings();

                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new Login());
                }
                else
                {
                    MessageBox.Show("Application is already running.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }        
    }
}
