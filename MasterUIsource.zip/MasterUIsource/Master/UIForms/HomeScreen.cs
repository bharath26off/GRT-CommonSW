﻿using ExceptionLib;
using Master;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Web.UI.DataVisualization.Charting;
using System.Windows.Forms;
using System.Xml.Linq;

namespace UI.UI_Forms
{
    public partial class HomeScreen : Form
    {
        DateTime currentTime = DateTime.Now;

        public static string ShiftLAble;

        Image signal_on = Image.FromFile(@"ICO\signal_on.png");
        Image signal_off = Image.FromFile(@"ICO\signal_off.png");

        public HomeScreen()
        {
            InitializeComponent();
            float xRatio = (float)Screen.PrimaryScreen.Bounds.Width / GlobalVariable.OrginalFormWidth;
            float yRatio = (float)Screen.PrimaryScreen.Bounds.Height / GlobalVariable.OrginalFormHeight;
            GlobalVariable.ResizeAllControls(this, xRatio, yRatio);
            ShiftLAble = lblShift.Text;
            label2.Left = (pnlMachineHealth.ClientSize.Width - label2.Width) / 2;
            label4.Left = (pnlMachineStatus.ClientSize.Width - label4.Width) / 2;
            label1.Left = (panel1.ClientSize.Width - label1.Width) / 2;

                       
            #region CONNECTION STATUS GRID
            conectionStatusGrid.AutoGenerateColumns = true; // or add manually
            conectionStatusGrid.DataSource = RefreshConnectionStatus();
            conectionStatusGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // GRID CUSTOMIZE
            conectionStatusGrid.Columns[0].FillWeight = 30; // 30%
            conectionStatusGrid.Columns[1].FillWeight = 50; // 50%
            conectionStatusGrid.Columns[2].FillWeight = 20; // 20%

            // Optional: ensure Status column is image column
            if (conectionStatusGrid.Columns["Status"] is DataGridViewImageColumn col)
            {
                col.ImageLayout = DataGridViewImageCellLayout.Zoom;
            }

            conectionStatusGrid.DefaultCellStyle.SelectionBackColor = conectionStatusGrid.DefaultCellStyle.BackColor;
            conectionStatusGrid.DefaultCellStyle.SelectionForeColor = conectionStatusGrid.DefaultCellStyle.ForeColor;
            #endregion
        }


        /// <summary>
        /// Home load function contain the things which needs to show at the time of form loading
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HomeScreen_Load(object sender, EventArgs e)
        {
            //date.MaxDate = DateTime.Now;
            //date.Value = DateTime.Today;
            //comboShift.SelectedIndex = 0;            
            string shift = GetShift(currentTime);
            lblShift.Text = $" {shift}";
            GlobalVariable.CurrentShift = shift.Trim();


           
        }


        /// <summary>
        /// Function to get shift according to the current time
        /// </summary>
        /// <param name="currentTime"></param>
        /// <returns></returns>
        private string GetShift(DateTime currentTime)
        {
            if (currentTime.Hour >= 0 && currentTime.Hour <= 8)
            {
                return $"A";
            }
            else if (currentTime.Hour >= 8 && currentTime.Hour < 16)
            {
                return $"B";
            }
            else
            {
                return $"C";
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                UpdateRunningLog();
                UpdateLiveAlarmGrid();
                UpdateMachineStatusLabels();

                //conectionStatusGrid.DataSource = RefreshConnectionStatus();

                // to maintain the scroll position
                int scrollIndex = 0;
                if (conectionStatusGrid.FirstDisplayedScrollingRowIndex >= 0)
                    scrollIndex = conectionStatusGrid.FirstDisplayedScrollingRowIndex;

                conectionStatusGrid.DataSource = RefreshConnectionStatus();

                if (scrollIndex >= 0 && scrollIndex < conectionStatusGrid.Rows.Count)
                    conectionStatusGrid.FirstDisplayedScrollingRowIndex = scrollIndex;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void UpdateMachineStatusLabels()
        {
            try
            {
                txtMachineMode.Text= GlobalVariable.g_bMachineMode.ToString();
                txtPasscnt.Text = GlobalVariable.dGlobal_Pass_count.ToString();
                txtFailcnt.Text = GlobalVariable.dGlobal_Reject_count.ToString();
                txtOverallcnt.Text = GlobalVariable.dGlobal_Total_count.ToString();
                txtyYeldcnt.Text = Math.Round(GlobalVariable.dGlobal_Yield_Count, 2) + " %";
                txtCycletime.Text = GlobalVariable.dGlobal_Cycle_time.ToString() + " S";

                txtUph.Text = "0.00";
                double uph = 0;
                if (GlobalVariable.dGlobal_Cycle_time > 0)
                {
                    uph = (3600 / GlobalVariable.dGlobal_Cycle_time); //GlobalVariable.dGlobal_Total_count / (GlobalVariable.dGlobal_Cycle_time / 60);
                }
                txtUph.Text = uph.ToString("0.00");
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "HomeScreen", "timer1_Tick", "Exception Error", ex.ToString());
                //throw;
            }
        }

        private void UpdateRunningLog()
        {
            try
            {

                lstRunningLog.DataSource = null;
                lstRunningLog.DataSource = ExceptionLib.Logger.RunningLog_lst;
                lstRunningLog.Refresh();
                //Application.DoEvents();
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "HomeScreen", "", ex.Message, ex.ToString());
            }
        }
        private void UpdateLiveAlarmGrid()
        {
            try
            {
               
                DataTable table = new DataTable();
                table.Columns.Add("Date And Time", typeof(string));
                table.Columns.Add("Code and Description", typeof(string));
                //if (GlobalVariable.g_bAlarm)
                //{
                //    DataRow data = table.NewRow();
                //    var cellValue = AlarmErrorType.TimeStamp;
                //    data[0] = cellValue.ToString();
                //    var cellValue1 = AlarmErrorType.Alarm;
                //    data[1] = cellValue1.ToString();
                //    table.Rows.Add(data);
                //}


                if (GlobalVariable.g_lstAlarmInfo.Any(a => a.alarmHappen))
                {
                    // GlobalVariable.current_MCStatus = GlobalVariable.MachineStatus.Pause;

                    foreach (var alarm in GlobalVariable.g_lstAlarmInfo)
                    {
                        if (alarm.alarmHappen)
                        {
                            DataRow data = table.NewRow();
                            var cellValue = alarm.AlarmStartTime;
                            data[0] = cellValue.ToString();

                            string ErrorDes = "";
                            if (alarm.AlarmName != "")
                            {
                                ErrorDes = alarm.AlarmName + " - ";
                            }
                            ErrorDes = ErrorDes + alarm.AlarmMessage;

                            var cellValue1 = ErrorDes;
                            data[1] = cellValue1.ToString();
                            table.Rows.Add(data);
                        }
                    }
                }

                dgvAlarmlive.DataSource = table;
                dgvAlarmlive.Columns[0].Width = 150;
                dgvAlarmlive.Columns[1].Width = 1000;

            }
            catch (Exception ex) { }
        }

        private DataTable RefreshConnectionStatus()
        {
            var table = new DataTable();
            table.Columns.Add("Type");
            table.Columns.Add("Device");
            table.Columns.Add("Status", typeof(Image)); 


            // CCDs
            foreach (var kv in ObjectList.CCDObj)
            {
                table.Rows.Add("CCD", $"{kv.Value.ConnectionStrName}",
                    kv.Value.IsConnected ? signal_on : signal_off);
            }
            
            // Scanners
            foreach (var kv in ObjectList.ScnrObj)
            {
                table.Rows.Add("Scanner", $"{kv.Value.ConnectionStrName}",
                    kv.Value.IsConnected ? signal_on : signal_off);
            }

            // Robos
            foreach (var kv in ObjectList.RoboObj)
            {
                table.Rows.Add("Robot", $"{kv.Value.ConnectionStrName}",
                    kv.Value.IsConnected ? signal_on : signal_off);
            }

            // COMPORT

            foreach (var kv in ObjectList.COMObj)
            {
                table.Rows.Add("COM", $"{kv.Value.OPT_COM}",
                    kv.Value.OPT_Connection_Status ? signal_on : signal_off);
            }

            // MOTION CARD
            //**msraj: need to work
            bool motionCardConnectStatus = false;
            table.Rows.Add("Motion Card", "Advantech",
                    motionCardConnectStatus ? signal_on : signal_off);

            //**devchange: Add extra rows as per needed

            return table;
        }


        private void button8_Click(object sender, EventArgs e)
        {
            //string shift = comboShift.Text;
            //if (comboShift.SelectedIndex > -1)
            //{


            //    if (shift == comboShift.Items[0].ToString())
            //    {
            //        MessageBox.Show("Invalid Shift","HomeScreen", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    }
            //    else
            //    {
            //        labelShift.Text = shift;
            //    }
            //}

        }

        /// <summary>
        /// while clicking reset button needs to reset  selected fields
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReset_Click(object sender, EventArgs e)
        {

            string shift = GetShift(currentTime);
            lblShift.Text = $" {shift}";
            //date.MaxDate = DateTime.Today;
            //date.MinDate = new DateTime(2000, 1, 1); 
            //date.Value = DateTime.Today;
            //comboShift.SelectedIndex = 0;
        }

        private void btnUnitSearch_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private async void Homing_Click(object sender, EventArgs e)
        {
            try
            {
				DialogResult result = MessageBox.Show("Do you want to start the Homing process", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
				if (result == DialogResult.OK)
				{
                    return; //**devchange:comment this return after connecting to machine
                    GlobalVariable.bhomeseq_running = true;
					await Master.AutoSequences.HomingSequence.StartHomingSequence();
					GlobalVariable.bhomeseq_running = false;
					GlobalVariable.b_gHomingDone = true;
					GlobalVariable.bactive_machine = true;
					MessageBox.Show("Homing Process Completed", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
					#region Running Log
					await Logger.WriteLogasTask(Logger.LogType.Running, "Homing", "OverAll Homing", "Homing Process Completed", "");
					#endregion
				}

			}
            catch (Exception)
            {
                throw;
            }
        }

        private void lblShift_TextChanged(object sender, EventArgs e)
        {
            ShiftLAble = lblShift.Text;
        }


    }
}
