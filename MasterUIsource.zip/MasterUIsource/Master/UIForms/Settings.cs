﻿using ExceptionLib;
using HelperClassLib;
using Master;
using Program;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using static DIO.DIDO;
using static Master.GlobalVariable;
using LANG = Test_EN.Transform_Language_Tool;

namespace UI
{
    public partial class Settings : Form
    {

        Image signal_on, signal_off;
        List<System.Threading.Timer> ThreadTimer = new List<System.Threading.Timer>();
        public static bool Di_Input_read_lock = false;


        public Settings()
        {
            InitializeComponent();
            IP_Details_table.EditingControlShowing += IP_Details_table_EditingControlShowing;

            float xRatio = (float)Screen.PrimaryScreen.Bounds.Width / GlobalVariable.OrginalFormWidth;
            float yRatio = (float)Screen.PrimaryScreen.Bounds.Height / GlobalVariable.OrginalFormHeight;
            GlobalVariable.ResizeAllControls(this, xRatio, yRatio);


            GridView.Names_Text_Columns(GlobalVariable.Analog_Input_Names, GlobalVariable.Analog_Input_Units, dgvAI);

            //radioButtonProd.Checked = GlobalVariable.Operation_Mode == "Production";
            //radioButtondry.Checked = GlobalVariable.Operation_Mode == "Dry";
            //radioButtoncpk.Checked = GlobalVariable.Operation_Mode == "CPK";
            //radioButtongrr.Checked = GlobalVariable.Operation_Mode == "GRR";
            //radioButtonStatic.Checked = GlobalVariable.Operation_Mode == "Static";
            //radioButtonDynamic.Checked = GlobalVariable.Operation_Mode == "Dynamic";

            radioButtonProd.Checked = GlobalVariable.g_bMachineMode == OperationMode.Production;
            radioButtondry.Checked = GlobalVariable.g_bMachineMode == OperationMode.DryRun;
            radioButtoncpk.Checked = GlobalVariable.g_bMachineMode == OperationMode.CPK;
            radioButtongrr.Checked = GlobalVariable.g_bMachineMode == OperationMode.GRR;
            radioButtonStatic.Checked = GlobalVariable.g_bMachineMode == OperationMode.Static;
            radioButtonDynamic.Checked = GlobalVariable.g_bMachineMode == OperationMode.Dynamic;


            Buzzer_Bypass.Checked = GlobalVariable.Buzzer_Bypass;
            Barcode_scanner_bypass.Checked = GlobalVariable.Scanner_Bypass;
            SFC_PDCA_Bypass.Checked = GlobalVariable.SFC_PDCA_Bypass;
            Safety_door_bypass.Checked = GlobalVariable.Safety_door_Bypass;

            grpSystemSettings.Enabled = false;
            IP_Details_table.Enabled = false;
            Serial_Comm_table.Enabled = false;
            groupBox1.Enabled = false;

            if (GlobalVariable.g_CardInitSucc)
            {
                //**devchange : uncomment after connect to machine
                //ThreadTimer.Add(new System.Threading.Timer(new TimerCallback(Di_Input_read), null, 10, 20)); // reading input connection, 100,10
            }
        }
        private void Di_Input_read(object sender)
        {
            try
            {
                if (Di_Input_read_lock == false)
                {
                    Di_Input_read_lock = true;
                    GlobalVariable.DI = GlobalVariable.ComObj.DI_RefreshValue(GlobalVariable.DI.Length, GlobalVariable.InputPortCfg);
                    GlobalVariable.DO = GlobalVariable.ComObj.DO_RefreshValue(GlobalVariable.DO.Length, GlobalVariable.OutputPortCfg);
                    Di_Input_read_lock = false;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "Input_read", "Di_Input_read()", "Input_read_Error", ex.ToString());
                Di_Input_read_lock = false;
            }

        }


        public static string[][] Vision_settings = new string[20][];
        public static int Colour = 0;
        public static int OPT_ID = 1;
        public static int CCD_ID = 2;

        public static string[][] Axis_Parameter_settings = new string[20][];
        public static int Card_No = 0;
        public static int Axis_ID = 1;
        public static int Axis_Name = 2;
        public static int Pitch = 3;
        public static int Pulse = 4;
        public static int PPR = 5;
        public static int Acc = 6;
        public static int Deacc = 7;
        public static int Manual_Speed = 8;
        public static int Homing_Speed = 9;

        public void Create_Table_grid_data()
        {
            IP_Details_table.DataSource = GetDataFromHelper.GetDataFromXML(TCP_IP_Setting_Path);
            Serial_Comm_table.DataSource = GetDataFromHelper.GetDataFromXML(Serial_Comm_Setting_Path);
            Table_Vision_Settings.DataSource = GetDataFromHelper.GetDataFromXML(Vision_Setting_Path);
            Axis_Settings.DataSource = GetDataFromHelper.GetDataFromXML(Axis_Parameter_Setting_Path);
            AE_LIMITS.DataSource = GetDataFromHelper.GetDataFromXML(AE_Limits_Path_Production);
            CPK_dataGridView2.DataSource = GetDataFromHelper.GetDataFromXML(AE_Limits_Path_CPK);
            GRR_dataGridView3.DataSource = GetDataFromHelper.GetDataFromXML(AE_Limits_Path_GRR);

        }



        private void Settings_Load(object sender, EventArgs e)
        {
            try
            {
                Axis_Settings.Enabled = false;
                Create_Table_grid_data();
                //**devchange : uncomment after connect to machine
                InitSourceForInput();
                InitSourceForOutput();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                Axis_Settings.Enabled = true;
                btnSave.Enabled = true;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (XML.SaveGridToXml(Axis_Settings, GlobalVariable.Axis_Parameter_Setting_Path, "Axis_Parameters"))
            {
                Axis_Parameter_settings = XML.XML_Data_to_Varaiables_Column_String(GlobalVariable.Axis_Parameter_Setting_Path);
                //GlobClass.Write_Parameter_to_Axis();
                GlobalVariable.DIDO.AxisLoad();
                Axis_Settings.Enabled = false;
                MessageBox.Show("Axis Parameters  Saved Successfully !");
            }

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) &&
                !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void richTextBox3_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void btnLoadCell_Start_Click(object sender, EventArgs e)
        {

        }

        private void ChkdCCD1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ChkdCCD5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnEditGeneral_Click(object sender, EventArgs e)
        {

            if (cmbShift.SelectedIndex == -1 || !dtpStartTime.Checked || !dtpStartTime.Checked)
            {
                MessageBox.Show("please fill the data");
            }
            cmbShift.Enabled = true;
            dtpEndTime.Enabled = true;
            dtpStartTime.Enabled = true;
        }

        private void btnSaveGeneral_Click(object sender, EventArgs e)
        {
            if (cmbShift.SelectedIndex == -1 || !dtpStartTime.Checked || !dtpStartTime.Checked)
            {
                MessageBox.Show("please fill the data");
            }
            cmbShift.Enabled = false;
            dtpEndTime.Enabled = false;
            dtpStartTime.Enabled = false;
        }

        private void cmbShift_DrawItem(object sender, DrawItemEventArgs e)
        {
            ComboBox cb = sender as ComboBox;
            e.DrawBackground();

            string text = string.Empty;
            Brush brush = SystemBrushes.WindowText; // Default system text color

            if (e.Index >= 0)
            {
                text = cb.Items[e.Index].ToString();
                brush = new SolidBrush(cb.ForeColor); // Keep default color
            }
            else if (cb.SelectedIndex == -1)
            {
                text = "-- SELECT MODE --";
                brush = Brushes.White; // Placeholder in white
            }

            StringFormat sf = new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            e.Graphics.DrawString(text, cb.Font, brush, e.Bounds, sf);
            e.DrawFocusRectangle();
        }

        private void btnEditSettings_Click(object sender, EventArgs e)
        {
            try
            {
                grpSystemSettings.Enabled = true;
                IP_Details_table.Enabled = true;
                Serial_Comm_table.Enabled = true;
                groupBox1.Enabled = true;
                btnSaveSettings.Enabled = true;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnSaveSettings_Click(object sender, EventArgs e)
        {
            try
            {


                //GlobalVariable.Operation_Mode = radioButtonProd.Checked ? "Production" :
                //    radioButtondry.Checked ? "Dry" :
                //    radioButtoncpk.Checked ? "CPK" :
                //    radioButtongrr.Checked ? "GRR" :
                //    radioButtonStatic.Checked ? "Static" :
                //    radioButtonDynamic.Checked ? "Dynamic" :
                //    GlobalVariable.Operation_Mode;

                // Assigning based on radio button selection
                GlobalVariable.g_bMachineMode =
                      radioButtonProd.Checked ? OperationMode.Production :
                      radioButtondry.Checked ? OperationMode.DryRun :
                      radioButtoncpk.Checked ? OperationMode.CPK :
                      radioButtongrr.Checked ? OperationMode.GRR :
                      radioButtonStatic.Checked ? OperationMode.Static :
                      radioButtonDynamic.Checked ? OperationMode.Dynamic :
                      GlobalVariable.g_bMachineMode;


                GlobalVariable.Safety_door_Bypass = Safety_door_bypass.Checked ? true : false;
                GlobalVariable.Scanner_Bypass = Barcode_scanner_bypass.Checked ? true : false;
                GlobalVariable.Buzzer_Bypass = Barcode_scanner_bypass.Checked ? true : false;
                GlobalVariable.SFC_PDCA_Bypass = SFC_PDCA_Bypass.Checked ? true : false;


                grpSystemSettings.Enabled = false;
                IP_Details_table.Enabled = false;
                Serial_Comm_table.Enabled = false;
                groupBox1.Enabled = false;


                XML.SaveGridToXml1(IP_Details_table, GlobalVariable.TCP_IP_Setting_Path, "TCP_IP_Details", "Server");
                XML.SaveGridToXml1(Serial_Comm_table, GlobalVariable.Serial_Comm_Setting_Path, "OPT", "COM");
                MessageBox.Show("Device Settings Saved Successfully !");
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnccd1Browse_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void cmbTestMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnCCD_start_Click(object sender, EventArgs e)
        {
            try
            {


            }
            catch (Exception)
            {

                throw;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void dryrun_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button23_Click(object sender, EventArgs e)
        {
            if (XML.SaveGridToXml(AE_LIMITS, GlobalVariable.AE_Limits_Path_Production, "AE_Limits_Production"))
            {
                SFC_PDCA.PDCA_Data_Prodution = XML.PDCA_DATA_TO_VARAIBLES(GlobalVariable.AE_Limits_Path_Production); //**msraj
                MessageBox.Show("PDCA Parameters fro Production Saved Successfully !");
            }

        }

        private void CPK_Save_Click(object sender, EventArgs e)
        {
            if (XML.SaveGridToXml(CPK_dataGridView2, GlobalVariable.AE_Limits_Path_CPK, "AE_Limits_CPK"))
            {
                SFC_PDCA.PDCA_Data_CPK = XML.PDCA_DATA_TO_VARAIBLES(GlobalVariable.AE_Limits_Path_CPK); //**msraj
                MessageBox.Show("PDCA Parameters for CPK Saved Successfully !");
            }
        }

        private void button31_Click(object sender, EventArgs e)
        {
            if (XML.SaveGridToXml(GRR_dataGridView3, GlobalVariable.AE_Limits_Path_GRR, "AE_Limits_GRR"))
            {
                SFC_PDCA.PDCA_DATA_GRR = XML.PDCA_DATA_TO_VARAIBLES(GlobalVariable.AE_Limits_Path_GRR); //**msraj
                MessageBox.Show("PDCA Parameters for GRR Saved Successfully !");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (XML.SaveGridToXml(Table_Vision_Settings, GlobalVariable.Vision_Setting_Path, "Vision_Settings"))
            {
                Vision_settings = XML.XML_Data_to_Varaiables_Row(GlobalVariable.Vision_Setting_Path);
                MessageBox.Show("Vision Settings Saved Successfully !");
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            //**devchange: uncomment below methods after connected to machine
            //UpdateInputGridStatus();
            //UpdateOutputGridStatus();
            //ReadAIValue();
            //GridView.Analog_Input_Status(GlobalVariable.Analog_Input_Names, dgvAI, GlobalVariable.AI);

        }
        public static void ReadAIValue()
        {
            try
            {
                GlobalVariable.ComObj.RefreshAISetup(true);
                GlobalVariable.AI = GlobalVariable.ComObj.RefreshAIvalues();
            }
            catch (Exception ex)
            {

            }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void IP_Details_table_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //if (e.Button == MouseButtons.Right)
            //{
            //    IP_Details_table.Rows[e.RowIndex].Selected = true;
            //    contextMenuStrip1.Show(IP_Details_table, IP_Details_table.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true).Location);

            //}
        }
        private void Serial_Comm_table_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //if (e.Button == MouseButtons.Right)
            //{
            //    Serial_Comm_table.Rows[e.RowIndex].Selected = true;
            //    contextMenuStrip1.Show(Serial_Comm_table, Serial_Comm_table.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true).Location);

            //}
        }

        private void Axis_Settings_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //if (e.Button == MouseButtons.Right)
            //{
            //    Axis_Settings.Rows[e.RowIndex].Selected = true;
            //    contextMenuStrip1.Show(Axis_Settings, Axis_Settings.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true).Location);

            //}
        }

        private void Table_Vision_Settings_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //if (e.Button == MouseButtons.Right)
            //{
            //    Table_Vision_Settings.Rows[e.RowIndex].Selected = true;
            //    contextMenuStrip1.Show(Table_Vision_Settings, Table_Vision_Settings.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true).Location);

            //}
        }

        private void contextMenuStrip2_Opening(object sender, CancelEventArgs e)
        {

        }

        private void Add_Click_1(object sender, EventArgs e)
        {
            if (tabControlSettings.SelectedIndex == 1)
            {
                if (tabConnectionDetails.SelectedIndex == 0)
                {
                    IP_Details_table.Rows.Add();
                }
                else if (tabConnectionDetails.SelectedIndex == 1)
                {
                    Serial_Comm_table.Rows.Add();
                }

            }
            else if (tabControlSettings.SelectedIndex == 3)
            {
                Axis_Settings.Rows.Add();
            }
            else if (tabControlSettings.SelectedIndex == 4)
            {
                Table_Vision_Settings.Rows.Add();
            }
            else if (tabControlSettings.SelectedIndex == 5)
            {
                if (tabControl5.SelectedIndex == 0)
                {
                    AE_LIMITS.Rows.Add();
                }
                else if (tabControl5.SelectedIndex == 1)
                {
                    CPK_dataGridView2.Rows.Add();
                }
                else if (tabControl5.SelectedIndex == 2)
                {
                    GRR_dataGridView3.Rows.Add();
                }
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {

            if (tabControlSettings.SelectedIndex == 1)
            {

                if (tabConnectionDetails.SelectedIndex == 0)
                {
                    IP_Details_table.Rows.RemoveAt(IP_Details_table.CurrentRow.Index);
                }
                else if (tabConnectionDetails.SelectedIndex == 1)
                {
                    Serial_Comm_table.Rows.RemoveAt(Serial_Comm_table.CurrentRow.Index);
                }

            }
            else if (tabControlSettings.SelectedIndex == 3)
            {
                Axis_Settings.Rows.RemoveAt(Axis_Settings.CurrentRow.Index);

            }
            else if (tabControlSettings.SelectedIndex == 4)
            {
                Table_Vision_Settings.Rows.RemoveAt(Table_Vision_Settings.CurrentRow.Index);

            }
            else if (tabControlSettings.SelectedIndex == 5)
            {
                if (tabControl5.SelectedIndex == 0)
                {
                    AE_LIMITS.Rows.RemoveAt(AE_LIMITS.CurrentRow.Index);

                }
                else if (tabControl5.SelectedIndex == 1)
                {
                    CPK_dataGridView2.Rows.RemoveAt(CPK_dataGridView2.CurrentRow.Index);

                }
                else if (tabControl5.SelectedIndex == 2)
                {
                    GRR_dataGridView3.Rows.RemoveAt(GRR_dataGridView3.CurrentRow.Index);

                }
            }

        }

        private void grpSystemSettings_Enter(object sender, EventArgs e)
        {

        }

        private void Axis_Config_MouseClick(object sender, MouseEventArgs e)
        {

        }




        private void txtSearchForOutput_TextChanged(object sender, EventArgs e)
        {
            ApplySearchFilter(txtSearchForOutput.Text, DGV_Output1);

        }

        private void txtSearchForInput_TextChanged(object sender, EventArgs e)
        {
            ApplySearchFilter(txtSearchForInput.Text, DGV_Input1);

        }


        private void ApplySearchFilter(string term, DataGridView data)
        {
            foreach (DataGridViewRow row in data.Rows)
            {
                bool visible = false;
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null &&
                        cell.Value.ToString().IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        visible = true;
                        break;
                    }
                }
                row.Visible = visible;
            }
        }
        #region custom properties
        private string input_start = "start";
        [Browsable(true)]
        [Description("The first io name displayed, the default is 'Start'"), Category("Custom control properties"), DisplayName("The first input enumeration name displayed in the current table")]
        public string Input_start
        {
            set
            {
                input_start = value;
                if (input_start == "End")
                {
                    input_start = "Start";
                }
            }
            get { return input_start; }
        }
        private string input_stop = "End";
        [Browsable(true)]
        [Description("The last io name displayed, the default is 'end'"), Category("Custom control properties"), DisplayName("The last input enumeration name displayed in the current table")]
        public string Input_stop
        {

            set
            {
                input_stop = value;
                if (input_stop == "start")
                {
                    input_stop = "End";
                }
            }
            get { return input_stop; }
        }
        #endregion
        public void InitSourceForInput()
        {
            GlobalVariable.lst_Input.Clear();
            signal_on = Image.FromFile(@"ICO\signal_on.png");
            signal_off = Image.FromFile(@"ICO\signal_off.png");

            if (DIO.DIDO.g_lstInput.Count > 0)
            {
                #region Press in the point that needs to be displayed
                int index_start = 0, index_stop = 0, lenth = 0;
                DIO.DIDO.EInput eInput_start, eInput_stop;
                if (input_start != "Start")
                {
                    Enum.TryParse<DIO.DIDO.EInput>(input_start, out eInput_start);
                    index_start = (int)eInput_start;
                }
                Enum.TryParse<DIO.DIDO.EInput>(input_stop, out eInput_stop);
                index_stop = (int)eInput_stop;
                if (input_stop == "End")
                {
                    index_stop = index_stop - 1;
                }
                lenth = index_stop - index_start + 1;
                for (int i = 0; i < lenth; i++)
                {
                    GlobalVariable.lst_Input.Add(DIO.DIDO.g_lstInput[index_start + i]);
                }
                #endregion

                #region adding input to gridview
                for (int i = 0; i < (GlobalVariable.lst_Input.Count); i++)
                {
                    int firstIndex = i;
                    int rowIndex = DGV_Input1.Rows.Add();
                    DataGridViewRow row = DGV_Input1.Rows[rowIndex];
                    row.Cells["InOnOff"].Value = (firstIndex < GlobalVariable.DI.Length && GlobalVariable.DI[firstIndex])
                        ? signal_on
                        : signal_off;
                    row.Cells["InputName"].Value = LANG.TL_MessageBox(GlobalVariable.lst_Input[firstIndex].BitName);
                }
                #endregion
                timer1.Start();
            }
        }
        List<CardDLL.IOutput> lst_Output = new List<CardDLL.IOutput>();
        public void InitSourceForOutput()
        {
            if (g_lstOutput.Count > 0)
            {
                #region Press in the point that needs to be displayed
                int index_start = 0, index_stop = 0, lenth = 0;
                EOutput eInput_start, eInput_stop;
                if (input_start != "Start")
                {
                    Enum.TryParse<EOutput>(input_start, out eInput_start);
                    index_start = (int)eInput_start;
                }
                Enum.TryParse<EOutput>(input_stop, out eInput_stop);
                index_stop = (int)eInput_stop;
                if (input_stop == "End")
                {
                    index_stop = index_stop - 1;
                }
                lenth = index_stop - index_start + 1;
                for (int i = 0; i < lenth; i++)
                {
                    lst_Output.Add(g_lstOutput[index_start + i]);
                }
                for (int i = 0; i < lst_Output.Count(); i++)
                {
                    DataGridViewRow dataGridViewRow = new DataGridViewRow();

                    int index = DGV_Output1.Rows.Add(dataGridViewRow);

                    DGV_Output1.Rows[index].Cells[0].Tag = i + index_start;
                    DGV_Output1.Rows[index].Cells[1].Value = LANG.TL_MessageBox(lst_Output[i].BitName);

                }
                timer2.Start();
                #endregion
            }
        }



        private void UpdateInputGridStatus()
        {

            for (int i = 0; i < GlobalVariable.DI.Length; i++)
            {
                DGV_Input1.Rows[i].Cells[0].Value = GlobalVariable.DI[i] ? signal_on : signal_off;
                DGV_Input1.Rows[i].Cells[1].Value = LANG.TL_MessageBox(GlobalVariable.lst_Input[i].BitName);
            }
        }


        private void UpdateOutputGridStatus()
        {

            //GlobalVariable.DO = dc.DO_RefreshValue();
            for (int i = 0; i < GlobalVariable.DO.Length; i++)
            {
                DGV_Output1.Rows[i].Cells[0].Style.BackColor = GlobalVariable.DO[i] ? Color.Lime : Color.LightGray;
                DGV_Output1.Rows[i].Cells[1].Value = LANG.TL_MessageBox(lst_Output[i].BitName);
            }
        }


        private void DGV_Output1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.ColumnIndex == 0)
                {
                    if (DGV_Output1.Rows[e.RowIndex].Cells[e.ColumnIndex].Tag != null)
                    {
                        var index = (int)DGV_Output1.Rows[e.RowIndex].Cells[e.ColumnIndex].Tag;
                        if ((DGV_Output1.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor == Color.Lime)) // || (DGV_Output.Rows[e.RowIndex].Cells[2].Style.BackColor == Color.Lime))
                        {
                            bool Rtn_OutPutOn = GlobalVariable.DIDO.WriteOPS(false, index);
                            if (Rtn_OutPutOn)
                            {
                                DGV_Output1.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.LightGray;
                            }
                            else
                                DGV_Output1.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.Lime;
                        }
                        else
                        {
                            bool Rtn_OutPutOn = GlobalVariable.DIDO.WriteOPS(true, index);
                            Rtn_OutPutOn = true; // make it true for showing click
                            if (Rtn_OutPutOn)
                            {
                                DGV_Output1.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.Lime;
                                DGV_Output1.Rows[e.RowIndex].Cells[e.ColumnIndex].Selected = false;
                            }
                            else
                                DGV_Output1.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.LightGray;
                        }
                        //  DGV_Output1.CurrentCell = DGV_Output1.Rows[e.RowIndex].Cells[e.ColumnIndex + 1];
                    }
                }
                //DGV_Output1.ClearSelection();

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void IP_Details_table_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (IP_Details_table.CurrentCell.ColumnIndex == 1 || IP_Details_table.CurrentCell.ColumnIndex == 2)
            {
                TextBox tb = e.Control as TextBox;
                if (tb != null)
                {
                    tb.KeyPress -= TextBox_KeyPress_AllowOnlyNumbersAndDot;
                    tb.KeyPress += TextBox_KeyPress_AllowOnlyNumbersAndDot;
                }
            }
        }

        //private void TextBox_KeyPress_AllowOnlyNumbersAndDot(object sender, KeyPressEventArgs e)
        //{
        //    if (Serial_Comm_table.CurrentCell.ColumnIndex == 1 || Serial_Comm_table.CurrentCell.ColumnIndex == 2 ||
        //        IP_Details_table.CurrentCell.ColumnIndex == 1 || IP_Details_table.CurrentCell.ColumnIndex == 2)

        //    {
        //        if (!char.IsControl(e.KeyChar) &&
        //            !char.IsDigit(e.KeyChar) &&
        //            e.KeyChar != '.')
        //        {
        //            e.Handled = true;
        //        }
        //    }
        //    else if (Axis_Settings.CurrentCell.ColumnIndex != 2 || Table_Vision_Settings.CurrentCell.ColumnIndex == 1)
        //    {
        //        if (!char.IsControl(e.KeyChar) &&
        //            !char.IsDigit(e.KeyChar))
        //        {
        //            e.Handled = true;
        //        }
        //    }
        //}
        private void TextBox_KeyPress_AllowOnlyNumbersAndDot(object sender, KeyPressEventArgs e)
        {
            // Check Serial_Comm_table
            if (Serial_Comm_table.CurrentCell != null &&
                (Serial_Comm_table.CurrentCell.ColumnIndex == 1 ||
                 Serial_Comm_table.CurrentCell.ColumnIndex == 2))
            {
                if (!char.IsControl(e.KeyChar) &&
                    !char.IsDigit(e.KeyChar) &&
                    e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                return;
            }

            // Check IP_Details_table
            if (IP_Details_table.CurrentCell != null &&
                (IP_Details_table.CurrentCell.ColumnIndex == 1 ||
                 IP_Details_table.CurrentCell.ColumnIndex == 2))
            {
                if (!char.IsControl(e.KeyChar) &&
                    !char.IsDigit(e.KeyChar) &&
                    e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                return;
            }

            // Check Axis_Settings
            if (Axis_Settings.CurrentCell != null &&
                Axis_Settings.CurrentCell.ColumnIndex != 2)
            {
                if (!char.IsControl(e.KeyChar) &&
                    !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
                return;
            }

            // Check Table_Vision_Settings
            if (Table_Vision_Settings.CurrentCell != null &&
                Table_Vision_Settings.CurrentCell.ColumnIndex == 1)
            {
                if (!char.IsControl(e.KeyChar) &&
                    !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
                return;
            }
        }

        private void Serial_Comm_table_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            int ColumnIndex = Serial_Comm_table.CurrentCell.ColumnIndex;
            if (ColumnIndex == 1 || ColumnIndex == 2)
            {
                TextBox tb = e.Control as TextBox;

                if (tb != null)
                {
                    tb.KeyPress -= TextBox_KeyPress_AllowOnlyNumbersAndDot;
                    tb.KeyPress += TextBox_KeyPress_AllowOnlyNumbersAndDot;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Enabled = true;
        }

        private void button24_Click(object sender, EventArgs e)
        {
            button23.Enabled = true;
        }

        private void Axis_Settings_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            int ColumnIndex = Axis_Settings.CurrentCell.ColumnIndex;
            //if (ColumnIndex == 1 || ColumnIndex == 2)
            {
                TextBox tb = e.Control as TextBox;

                if (tb != null)
                {
                    tb.KeyPress -= TextBox_KeyPress_AllowOnlyNumbersAndDot;
                    tb.KeyPress += TextBox_KeyPress_AllowOnlyNumbersAndDot;
                }
            }
        }

        private void Table_Vision_Settings_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            int ColumnIndex = Table_Vision_Settings.CurrentCell.ColumnIndex;
            if (ColumnIndex == 1 || ColumnIndex == 2)
            {
                TextBox tb = e.Control as TextBox;

                if (tb != null)
                {
                    tb.KeyPress -= TextBox_KeyPress_AllowOnlyNumbersAndDot;
                    tb.KeyPress += TextBox_KeyPress_AllowOnlyNumbersAndDot;
                }
            }
        }
    }


}
