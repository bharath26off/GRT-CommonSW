﻿using DIO;
using DynamicCylinders;
using DynamicVacuums;
using ExceptionLib;
using HelperClassLib;
using Master;
using Program;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using IO_Stepper;

namespace UIForms
{

    public partial class ManualScreen : Form
    {


        public Advantech_PCIE ServoAxis;
        public string Stepper { get; set; }
        public string Servo { get; set; }
        int axisindex = 0;
        int stepperIndex = 0;
        public int PosLimit_Error = 0;

        #region TCP Connections

        //public string filePath = Environment.CurrentDirectory + @"\Data\AvailableDevices.Csv";
        //public EnumerableRowCollection<DataRow> AvblVision;
        //public EnumerableRowCollection<DataRow> AvblScanner;
        //public EnumerableRowCollection<DataRow> AvblOPT;
        public SocketClient TCPObj;
        public Serial_Communication COMPortObj;

        public string RoboResult = string.Empty;

        #endregion

        //public string[] 
        public ManualScreen()
        {
            InitializeComponent();
            ServoAxis = ObjectList.MotorObj[0];
            LoadMotorAxes();
            rbtInputState1.InitRoboInputs();
            rbtOutputState1.InitRoboOutputs();
            loadAvblDevices();
            LoadConveyorMotor();
            float xRatio = (float)Screen.PrimaryScreen.Bounds.Width / GlobalVariable.OrginalFormWidth;
            float yRatio = (float)Screen.PrimaryScreen.Bounds.Height / GlobalVariable.OrginalFormHeight;
            GlobalVariable.ResizeAllControls(this, xRatio, yRatio);
            ErrorHandler.OnErrorRaised += HandleGlobalError;
            grpCCDConn.Left = (tabPageCamera.ClientSize.Width - grpCCDConn.Width) / 2;

			cmbRBTmodeselect.Left = (lblCmd.Right) + 10;
			lblConnStatus.Left = (lblrobotconnstatus.Left) - 90;
			cmbCCD.Left = (lblSelectCCD.Right) + 10;
			lblCCDConn.Left = (lblCCDConnStatus.Left) - 90;
			cmbCOMPort.Left = (label11.Right) + 10;
			label17.Left = (lblOPTConStatus.Left) - 90;
			cmbScanner.Left = (lblScannerSel.Right) + 10;
			lblScannerConn.Left = (lblScanrConStatus.Left) - 90;
			label14.Left = (lblSFCConStatus.Left) - 90;
		}

        public bool isstoped = false;

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            ErrorHandler.OnErrorRaised -= HandleGlobalError;
            base.OnFormClosing(e);
        }

        private void LoadMotorAxes()
        {
            try
            {
                // Loading the Motor Object from ObjectList.MotorObj Dictionary
                var motorList = ObjectList.MotorObj
    .Select(kv => new
    {
        Key = kv.Key,
        Motor = kv.Value,
        Name = kv.Value.motor_Params.name
    })
    .ToList();

                //AxisSelectCombo.DataSource = GlobalVariable.ServoRows.CopyToDataTable();
                //AxisSelectCombo.DisplayMember = "Servo";
                //AxisSelectCombo.ValueMember = "Servo";                

                AxisSelectCombo.DataSource = motorList;
                AxisSelectCombo.DisplayMember = "Name";
                AxisSelectCombo.ValueMember = "Key";

            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "Manual Screen", "LoadMotorAxes", "Exception Error", ex.ToString());

            }
        }

        private void loadAvblDevices()
        {
            try
            {
                cmbCCD.DataSource = null;
                cmbScanner.DataSource = null;
                cmbCOMPort.DataSource = null;

               // DataTable dt = new DataTable();
               // dt = HelperClassLib.GetDataFromHelper.GetDataFromCSV(filePath);
               // AvblVision = dt.AsEnumerable()
               // .Where(row => !string.IsNullOrWhiteSpace(row.Field<string>("Vision")));
               // AvblScanner = dt.AsEnumerable()
               //.Where(row => !string.IsNullOrWhiteSpace(row.Field<string>("Scanner")));
               // AvblOPT = dt.AsEnumerable()
               //     .Where(row => !string.IsNullOrWhiteSpace(row.Field<string>("OPT")));

               // cmbCCD.DataSource = AvblVision.CopyToDataTable();
               // cmbCCD.DisplayMember = "Vision";
               // cmbCCD.ValueMember = "Vision";

               // cmbScanner.DataSource = AvblScanner.CopyToDataTable();
               // cmbScanner.DisplayMember = "Scanner";
               // cmbScanner.ValueMember = "Scanner";

               // cmbCOMPort.DataSource = AvblOPT.CopyToDataTable();
               // cmbCOMPort.DisplayMember = "OPT";
               // cmbCOMPort.ValueMember = "OPT";

               // cmbScanner.SelectedIndex = 0;
               // cmbCCD.SelectedIndex = 0;
               // cmbCOMPort.SelectedIndex = 0;
               // cmbOPTSend.SelectedIndex = 0;

               // if (AvblScanner.Count() > 0)
               // {
               //     lblScannerSel.Visible = true;
               //     cmbScanner.Visible = true;

               // }
               // else
               // {
               //     lblScannerSel.Visible = false;
               //     cmbScanner.Visible = false;
               // }

               // cmbCCD.SelectedIndex = 0;
               // cmbScanner.SelectedIndex = 0;
               // cmbRBTmodeselect.SelectedIndex = 0;



                var ccdList = ObjectList.CCDObj
    .Select(kv => new
    {
        Key = kv.Key,
        CCD = kv.Value,
        Name = kv.Value.ConnectionStrName
    })
    .ToList();

                cmbCCD.DataSource = ccdList;
                cmbCCD.DisplayMember = "Name";
                cmbCCD.ValueMember = "Key";


                var scannerList = ObjectList.ScnrObj
    .Select(kv => new
    {
        Key = kv.Key,
        Scanner = kv.Value,
        Name = kv.Value.ConnectionStrName
    })
    .ToList();

                cmbScanner.DataSource = scannerList;
                cmbScanner.DisplayMember = "Name";
                cmbScanner.ValueMember = "Key";

                var optList = ObjectList.COMObj
    .Select(kv => new
    {
        Key = kv.Key,
        Scanner = kv.Value,
        Name = kv.Value.OPT_COM
    })
    .ToList();

                cmbCOMPort.DataSource = optList;
                cmbCOMPort.DisplayMember = "Name";
                cmbCOMPort.ValueMember = "Key";


                cmbScanner.SelectedIndex = 0;
                cmbCCD.SelectedIndex = 0;
                cmbCOMPort.SelectedIndex = 0;
                cmbOPTSend.SelectedIndex = 0;

                cmbRBTmodeselect.SelectedIndex = 0;





            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "Settings", "", ex.Message, ex.ToString());
            }
        }
                
        private void AxisSelectCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

            Advantech_PCIE selectedMotor = ((dynamic)AxisSelectCombo.SelectedItem).Motor;
            ServoAxis = ObjectList.MotorObj[(int)((dynamic)AxisSelectCombo.SelectedItem).Key];

            //axisindex = AxisSelectCombo.SelectedIndex;
            //ServoAxis = ObjectList.MotorObj[axisindex];
            EnableControls();
        }


        public void EnableControls()
        {
            if (GlobalVariable.g_HomingDone || ServoAxis.Home_Done == true)
            {
                grbPTP.Enabled = true;
                groupBox8.Enabled = true;
                groupBox11.Enabled = true;
            }
            else
            {
                grbPTP.Enabled = false;
                groupBox8.Enabled = false;
                groupBox11.Enabled = false;
            }
        }
        


        private void button45_Click(object sender, EventArgs e)
        {
            try
            {
                //ServoAxis.Jog(0);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void button44_Click(object sender, EventArgs e)
        {
            try
            {
                //ServoAxis.Jog(1);
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void button51_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtServoX_Targetposition.Text.Trim() == "")
                {
                    MessageBox.Show("Please Enter Position", "Manual Screen", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (txtServoX_Targetspeed.Text.Trim() == "")
                {
                    MessageBox.Show("Please Enter Speed", "Manual Screen", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (ServoAxis != null)
                {
                    double dTargetPos = 0;
                    if (!string.IsNullOrEmpty(txtServoX_Targetposition.Text))
                    {
                        dTargetPos = Convert.ToDouble(txtServoX_Targetposition.Text);
                        if (double.TryParse(txtServoX_Targetspeed.Text, out double speedValue))
                        {
                            btnMove.Enabled = false;
                            if (!ServoAxis.Move_Abs(dTargetPos, speedValue, GlobalVariable.g_lstAxisConfig[axisindex].Acc,
                                GlobalVariable.g_lstAxisConfig[axisindex].DeAcc, 15000, false))
                            {
                                //Logger.WriteLog("Device_Interface", "jogfrwrd()", "PCIE-1203_Interface", "Exception Error", es.ToString());
                            }
                            lbl_Servo_TargetPosition.Text = dTargetPos.ToString();
                            btnMove.Enabled = true;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Kindly Enter the TargetPosition ", "Movement", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnServoEnable_Click(object sender, EventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    ServoAxis.ServoOn(true);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnServoDisable_Click(object sender, EventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    ServoAxis.ServoOFF();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnServoClear_Click(object sender, EventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    ServoAxis.ResetAxis();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnMoveStop_Click(object sender, EventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    ServoAxis.Stop();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnHomeStop_Click(object sender, EventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    ServoAxis.Stop();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtHome_Velocity.Text.Length == 0)
                {
                    MessageBox.Show("Please Enter the Velocity for Homing ", "Homing", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                if (ServoAxis != null)
                {
                    double speed = Convert.ToDouble(txtHome_Velocity.Text);
                    ServoAxis.Set_Home_Vel(speed,
                        GlobalVariable.g_lstAxisConfig[axisindex].Acc, GlobalVariable.g_lstAxisConfig[axisindex].DeAcc);
                    //ServoAxis.Set_Home_Vel(speed * GlobalVariable.g_lstAxisConfig[axisindex].pulse_mm, 
                    //   GlobalVariable.g_lstAxisConfig[axisindex].Acc, GlobalVariable.g_lstAxisConfig[axisindex].DeAcc);
                    Task.Run(() => ServoAxis.ManulHoming(1));
                    // GlobalVariable.AxisHomingStatus[axisindex] = true;
                    EnableControls();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnptpMove_Click(object sender, EventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    double dTargetPos = 0;
                    if (!string.IsNullOrEmpty(txtServoX_Targetposition.Text))
                    {
                        dTargetPos = Convert.ToDouble(txtServoX_Targetposition.Text);
                        if (double.TryParse(txtServoX_Targetspeed.Text, out double speedValue))
                        {
                            btnMove.Enabled = false;
                            if (!ServoAxis.Move_Abs(dTargetPos, speedValue, GlobalVariable.g_lstAxisConfig[axisindex].Acc, GlobalVariable.g_lstAxisConfig[axisindex].DeAcc, 5000, false))
                            {
                                //Logger.WriteLog("Device_Interface", "jogfrwrd()", "PCIE-1203_Interface", "Exception Error", es.ToString());
                            }

                            lbl_Servo_TargetPosition.Text = dTargetPos.ToString();
                            btnMove.Enabled = true;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Kindly Enter the TargetPosition ", "Movement", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    double ActPos = 0;
                    double ActPvel = 0;
                    string actstatus = "";
                    ServoAxis.GetCurrentPos(out ActPos, out actstatus, out ActPvel);
                    bool[] ioStatusArray = ServoAxis.ToGetMotionIOStatus();


                    lbl_Servo_Actual_Position.Text = ActPos.ToString("F2");

                    //if (ServoAxis.GetSingleMotionIOBit(Advantech_PCIE.MotionIOBit.RDY))
                    //{
                    //    lblServoEnableColor.BackColor = Color.Green;
                    //    lblServoReadyColor.BackColor = Color.Green;
                    //}
                    //else
                    //{
                    //    lblServoEnableColor.BackColor = Color.Maroon;
                    //    lblServoReadyColor.BackColor = Color.Green;
                    //}
                    if (tabControl2.SelectedIndex == 0)
                    {
                        lblServoEnableColor.BackColor = ioStatusArray[(int)Advantech_PCIE.MotionIOBit.SVON] ? Color.Green : Color.Maroon;
                        //lblServoReadyColor.BackColor = ioStatusArray[(int)Advantech_PCIE.MotionIOBit.SVON] ? Color.Green : Color.Maroon;
                        lblServoHomedColor.BackColor = ServoAxis.Home_Done ? Color.Green : Color.Maroon;
                        lblServoErrorColor.BackColor = ioStatusArray[(int)Advantech_PCIE.MotionIOBit.ALM] ? Color.Green : Color.Maroon;
                        lblNegLimitColor.BackColor = ioStatusArray[(int)Advantech_PCIE.MotionIOBit.LMT_N] ? Color.Green : Color.Maroon;
                        lblPosLimColor.BackColor = ioStatusArray[(int)Advantech_PCIE.MotionIOBit.LMT_P] ? Color.Green : Color.Maroon;
                        lblServoHomeColor.BackColor = ioStatusArray[(int)Advantech_PCIE.MotionIOBit.ORG] ? Color.Green : Color.Maroon;
                    }

                    string str = ServoAxis.ToGetStatus();
                    if (str.Contains("ERROR_STOP"))
                    {
                        lblServoErrorColor.BackColor = Color.Green;
                    }
                    else
                    {
                        lblServoErrorColor.BackColor = Color.Maroon;
                    }
                    //double dActSpeed = 0;

                    //ServoAxis.GetActualVelocity(out dActSpeed);
                    //lbl_Servo_TargetPosition.Text = dActSpeed.ToString();
                    //if (actstatus.ToUpper().Contains("DISABLE"))
                    //{
                    //    lblServoDisableColor.BackColor = Color.Green;
                    //}
                    //else
                    //{
                    //    lblServoDisableColor.BackColor = Color.Maroon;
                    //}

                    //if (actstatus.ToUpper().Contains("HOMING"))
                    //{
                    //    lblServoHomeColor.BackColor = Color.Green;
                    //}
                    //else
                    //{
                    //    lblServoHomeColor.BackColor = Color.Maroon;
                    //}

                    //if (actstatus.ToUpper().Contains("ERROR"))
                    //{
                    //    lblServoErrorColor.BackColor = Color.Green;
                    //}
                    //else
                    //{
                    //    lblServoErrorColor.BackColor = Color.Maroon;
                    //}

                    if (actstatus.ToUpper().Contains("MOTION"))
                    {
                        lblServoRunningColor.BackColor = Color.Green;
                    }
                    else
                    {
                        lblServoRunningColor.BackColor = Color.Maroon;
                    }


                    #region CONVEYOR STEPPER
                    if (tabControl2.SelectedIndex == 2) // FOR STEPPER CONVEYOR TAB
                    {
                        UpdateConvStepperStatus();
                    }

                    #endregion
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnptpStop_Click(object sender, EventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    ServoAxis.Stop();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }



        private void btnWorkConStart_Click(object sender, EventArgs e)
        {

        }
        DynamicVacuum VacForm = new DynamicVacuum();
        DynamicCylinder CylForm = new DynamicCylinder();

        private void ManualScreen_Load(object sender, EventArgs e)
        {
            try
            {
                // GlobalVariable.g_lstAlarmInfo[(int)DIDO.ECode.Button_Picking_Timeout_Error].AlarmHappen = true;
                if (ServoAxis != null)
                {
                    ServoAxis = ObjectList.MotorObj[0];
                }
                //txtServoX_Targetposition.KeyPress += GlobalVariable.AllowOnlyDecimal_TextBox;
                //txtServoX_Targetspeed.KeyPress += GlobalVariable.AllowOnlyDecimal_TextBox;
                //txtHome_Velocity.KeyPress += GlobalVariable.AllowOnlyDecimal_TextBox;
                //txtptppositionx.KeyPress += GlobalVariable.AllowOnlyDecimal_TextBox;
                //txtptpspeedx.KeyPress += GlobalVariable.AllowOnlyDecimal_TextBox;

               CylForm.TopLevel = false;
               CylForm.FormBorderStyle = FormBorderStyle.None;
                CylForm.Dock = DockStyle.Fill;
                PnlCylinderMain.Controls.Add(CylForm);
                CylForm.Show();

                VacForm.TopLevel = false;
                VacForm.FormBorderStyle = FormBorderStyle.None;
                VacForm.Dock = DockStyle.Fill;
                PnlVacuumMain.Controls.Add(VacForm);
                VacForm.Show();
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnConDryrun_Click(object sender, EventArgs e)
        {

        }

        private void label57_Click(object sender, EventArgs e)
        {

        }

        private void label55_Click(object sender, EventArgs e)
        {

        }

        private void btnConStop_Click(object sender, EventArgs e)
        {

        }

        private void btnWorkConStop_Click(object sender, EventArgs e)
        {

        }

        //private void btnptpplusx_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        double dTargetPos = 0;
        //        if (txtptppositionx.Text.Trim() == "")
        //        {
        //            MessageBox.Show("Please Enter Position", "Manual Screen", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //            return;
        //        }
        //        if (txtptpspeedx.Text.Trim() == "")
        //        {
        //            MessageBox.Show("Please Enter Speed", "Manual Screen", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //            return;
        //        }

        //        if (ServoAxis != null)
        //        {
        //            if (!string.IsNullOrEmpty(txtptppositionx.Text))
        //            {
        //                dTargetPos = Convert.ToDouble(txtptppositionx.Text);
        //                if (double.TryParse(txtptpspeedx.Text, out double speedValue))
        //                {
        //                    btnptpplusx.Enabled = false;
        //                    if (!ServoAxis.Move_Rel(dTargetPos, speedValue, GlobalVariable.g_lstAxisConfig[axisindex].Acc, 
        //                        GlobalVariable.g_lstAxisConfig[axisindex].DeAcc, 5000, false))
        //                    {
        //                        //Logger.WriteLog("Device_Interface", "jogfrwrd()", "PCIE-1203_Interface", "Exception Error", es.ToString());
        //                    }
        //                    lbl_Servo_TargetPosition.Text = dTargetPos.ToString();
        //                    btnptpplusx.Enabled = true;
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
        //    }
        //}

        //private void btnptpminx_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        double dTargetPos = 0;
        //        if (txtptppositionx.Text.Trim() == "")
        //        {
        //            MessageBox.Show("Please Enter Position", "Manual Screen", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //            return;
        //        }
        //        if (txtptpspeedx.Text.Trim() == "")
        //        {
        //            MessageBox.Show("Please Enter Speed", "Manual Screen", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //            return;
        //        }

        //        if (ServoAxis != null)
        //        {
        //            if (!string.IsNullOrEmpty(txtptppositionx.Text))
        //            {
        //                dTargetPos = Convert.ToDouble(txtptppositionx.Text);
        //                if (double.TryParse(txtptpspeedx.Text, out double speedValue))
        //                {
        //                    btnptpplusx.Enabled = false;
        //                    if (!ServoAxis.Move_Rel(- dTargetPos, speedValue, GlobalVariable.g_lstAxisConfig[axisindex].Acc, 
        //                        GlobalVariable.g_lstAxisConfig[axisindex].DeAcc, 5000, false))
        //                    {
        //                        //Logger.WriteLog("Device_Interface", "jogfrwrd()", "PCIE-1203_Interface", "Exception Error", es.ToString());
        //                    }
        //                    lbl_Servo_TargetPosition.Text = dTargetPos.ToString();
        //                    btnptpplusx.Enabled = true;
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
        //    }
        //}

        
        private void btnJogForward_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    ServoAxis.Jog(0, Convert.ToDouble(txtJogSpeed.Text), GlobalVariable.g_lstAxisConfig[axisindex].Acc, GlobalVariable.g_lstAxisConfig[axisindex].DeAcc);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnJogForward_MouseUp(object sender, MouseEventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    ServoAxis.StopJog();
                    ServoAxis.Stop();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnJogReverse_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    ServoAxis.Jog(1, Convert.ToDouble(txtJogSpeed.Text), GlobalVariable.g_lstAxisConfig[axisindex].Acc, GlobalVariable.g_lstAxisConfig[axisindex].DeAcc);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnJogReverse_MouseUp(object sender, MouseEventArgs e)
        {
            try
            {
                if (ServoAxis != null)
                {
                    ServoAxis.StopJog();
                    ServoAxis.Stop();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void PnlVacuumMain_Paint(object sender, PaintEventArgs e)
        {

        }

        private void HandleGlobalError(ErrorInfo info)
        {
            richTextBoxStatus.Clear();
            richTextBoxStatus.ReadOnly = true;
            richTextBoxStatus.BorderStyle = BorderStyle.None;



            if (info.Exception != null)
            {
                AppendText("Function Name: ", info.FunctionName);
                AppendText("\nI/O Name: ", info.IOName);
                AppendText("\nException: ", info.Message);
            }
            else if (info.ErrorCode != "0")
            {
                AppendText("Function Name: ", info.FunctionName);
                AppendText("\nI/O Name: ", info.IOName);
                AppendText("\nMessage: ", info.Message);
                AppendText("\nError Code: ", info.ErrorCode);
            }
        }

        void AppendText(string stsHeader, string stsMessage)
        {
            richTextBoxStatus.SelectionColor = Color.Blue;
            richTextBoxStatus.SelectionFont = new Font(richTextBoxStatus.Font, FontStyle.Bold);
            richTextBoxStatus.AppendText(stsHeader);
            //richTextBoxStatus.SelectionColor = (info.ErrorCode == "0") ? Color.Black : Color.Red;
            richTextBoxStatus.SelectionFont = new Font(richTextBoxStatus.Font, FontStyle.Regular);
            richTextBoxStatus.AppendText(stsMessage);
        }

        private void tabControl2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (tabControl2.SelectedIndex == 1)
                {
                    //ServoAxis = ObjectList.MotorObj[stepperIndex + GlobalVariable.ServoRows.Count()];
                }


                if (tabControl2.SelectedTab != tabPageVacuum) 
                {
                    VacForm.btnCloseAll_Click(null, null);
                }

                if (tabControl2.SelectedTab != tabPageCylinder) 
                {
                    CylForm.btnCloseAll_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnPTP_Move_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtPTP_Start.Text.Trim() == "")
                {
                    MessageBox.Show("Please enter start position", "Manual Screen", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (txtPTP_End.Text.Trim() == "")
                {
                    MessageBox.Show("Please enter end position", "Manual Screen", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (ServoAxis != null)
                {
                    Task.Run(() => MovePTP());
                }

            }
            catch (Exception)
            {

                //throw;
            }
        }

        public async Task MovePTP()
        {
            try
            {
                double dTargetstart = 0;
                double dTargetend = 0;
                double speedValue = 0;
                int iteration = Convert.ToInt32(txtIteration.Text.Trim());
                int waittime = Convert.ToInt32(txtWait.Text.Trim());

                for (int i = 0; i < iteration; i++)
                {
                    if (isstoped)
                    {
                        isstoped = false;
                        return;
                    }
                    dTargetstart = Convert.ToDouble(txtPTP_Start.Text);
                    speedValue = Convert.ToDouble(txtPTP_Speed.Text);
                    if (ServoAxis.Move_Abs(dTargetstart, speedValue, GlobalVariable.g_lstAxisConfig[axisindex].Acc, GlobalVariable.g_lstAxisConfig[axisindex].DeAcc, 15000, true))
                    {
                        //lbl_Servo_TargetPosition.Text = dTargetstart.ToString();
                    }
                    else
                    {
                        return;
                    }


                    await Task.Delay(waittime * 1000);


                    dTargetend = Convert.ToDouble(txtPTP_End.Text);
                    speedValue = Convert.ToDouble(txtPTP_Speed.Text);

                    if (ServoAxis.Move_Abs(dTargetend, speedValue, GlobalVariable.g_lstAxisConfig[axisindex].Acc, GlobalVariable.g_lstAxisConfig[axisindex].DeAcc, 15000, true))
                    {
                        //lbl_Servo_TargetPosition.Text = dTargetstart.ToString();
                    }
                    else
                    {
                        return;
                    }

                    await Task.Delay(waittime * 1000);

                }

                MessageBox.Show("Point To Point Process Completed", "Manual Screen", MessageBoxButtons.OK, MessageBoxIcon.Information);



            }
            catch (Exception)
            {

                //throw;
            }
        }

        private void btnPTP_Stop_Click(object sender, EventArgs e)
        {
            try
            {
                isstoped = true;
                ServoAxis.Stop();
            }
            catch (Exception)
            {

                //throw;
            }
        }

        #region Robot Functions

        private void cmbRBTmodeselect_SelectedIndexChanged(object sender, EventArgs e)
        {
            int RoboSelectionMode;
            try
            {
                if (GlobalVariable.g_bMachineMode == GlobalVariable.OperationMode.DryRun)
                {
                    RoboSelectionMode = 1;
                }
                else
                {
                    RoboSelectionMode = 0;
                }
                if (cmbRBTmodeselect.SelectedIndex == 0)
                {
                    txtsendrobotcommand.Text = $"AUTO_MODE,1,0,Auto_mode_Selected,999.999,{RoboSelectionMode},999.999,999.999," +
                        $"999.999,999.999,{DateTime.Now.ToString("dd/MM/yyyy_HH:mm:ss:ffff")},IN,END";
                }
                else if (cmbRBTmodeselect.SelectedIndex == 1)
                {
                    txtsendrobotcommand.Text = $"MANUAL_MODE,1,0,Manual_mode_Selected,999.999,999.999,999.999,999.999," +
                        $"999.999,999.999,{DateTime.Now.ToString("dd/MM/yyyy_HH:mm:ss:ffff")},IN,END";
                }
                else if (cmbRBTmodeselect.SelectedIndex == 2)
                {
                    txtsendrobotcommand.Text = $"INITIALIZATION_MODE,1,0,Initialization_mode_Selected,1,999.999,999.999,999.999," +
                        $"999.999,999.999,{DateTime.Now.ToString("dd/MM/yyyy_HH:mm:ss:ffff")},IN,END";
                }
                else if (cmbRBTmodeselect.SelectedIndex == 3)
                {
                    txtsendrobotcommand.Text = $"CALIBRATION_MODE,1,0,Calibration_mode_Selected,999.999,999.999,999.999,999.999," +
                        $"999.999,999.999,{DateTime.Now.ToString("dd/MM/yyyy_HH:mm:ss:ffff")},IN,END";
                }
                else if (cmbRBTmodeselect.SelectedIndex == 4)
                {
                    txtsendrobotcommand.Text = $"RECIPE_MODE,1,0,Recipe_mode_Selected,999.999,999.999,999.999,999.999," +
                        $"999.999,999.999,{DateTime.Now.ToString("dd/MM/yyyy_HH:mm:ss:ffff")},IN,END";
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnconnect_Click(object sender, EventArgs e)
        {
            try
            {
                Robot.RbtResetProgram();

                if (!ObjectList.Robot.CheckConnectStatus())
                {
                    if (ObjectList.Robot.Connect() && ObjectList.RobotSts.Connect() && ObjectList.RobotErr.Connect())
                    {
                        lblrobotconnstatus.BackColor = Color.Lime;
                    }
                    else
                    {
                        lblrobotconnstatus.BackColor = Color.Maroon;
                    }
                }
                else
                {
                    lblrobotconnstatus.BackColor = Color.Lime;
                }

            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnRBTtrigger_Click(object sender, EventArgs e)
        {
            try
            {

                if (cmbRBTmodeselect.SelectedIndex == 2)
                {
                    RoboResult = ObjectList.Robot.RobotSendandReceivesync(txtsendrobotcommand.Text, GlobalVariable.g_RobotretryCount);
                }
                else
                {
                    RoboResult = ObjectList.Robot.RobotSendandReceivesync(txtsendrobotcommand.Text, GlobalVariable.g_RobotretryCount, false, true);

                }

                if (!string.IsNullOrEmpty(RoboResult))
                {
                    if (RoboResult.ToLower() == "timeout")
                    {
                        GlobalVariable.AlarmTrigger(DIO.DIDO.ECode.Robot_Receive_TimeOut_Error, true, 1);
                        return;
                    }
                    else if (RoboResult.ToLower() == "alarm")
                    {
                        GlobalVariable.AlarmTrigger(DIDO.ECode.Robot_Alarm_Error, true, 1);
                        return;
                    }
                    //if (RoboResult.Split(',')[0].ToUpper() == cmbRBTmodeselect.SelectedValue.ToString().ToUpper())
                    {
                        txtreceivecommnd.Text = RoboResult;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnDisConnect_Click(object sender, EventArgs e)
        {
            try
            {
                ObjectList.Robot.Disconnect();
                ObjectList.RobotSts.Disconnect();
                ObjectList.RobotErr.Disconnect();
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }
        #endregion

        #region Vision Functions

        /// <summary>
        /// Connect CCD
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCCDConnect_Click(object sender, EventArgs e)
        {
            try
            {
                //TCPObj = ObjectList.CCDObj[cmbCCD.SelectedIndex];
                if (cmbCCD.SelectedItem != null)
                {
                    TCPObj = ObjectList.CCDObj[(int)((dynamic)cmbCCD.SelectedItem).Key];
                }
                else
                {
                    MessageBox.Show("can't connect !. selected item is empty");
                    return;
                }

                if (!TCPObj.CheckConnectStatus())
                {
                    if (TCPObj.Connect())
                    {
                        lblCCDConnStatus.BackColor = Color.Lime;
                    }
                    else
                    {
                        lblCCDConnStatus.BackColor = Color.Maroon;
                    }
                }
                else
                {
                    lblCCDConnStatus.BackColor = Color.Lime;
                }

            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        /// <summary>
        /// Trigger CCD Commands
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCCDTrigger_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtSendCmd.Text))
                {
                    txtRecivdCmd.Text = "";

                    if (TCPObj.Send(txtSendCmd.Text.Trim()))
                    {
                        string ScnrResult = TCPObj.Receive(600001);
                        txtRecivdCmd.Text = ScnrResult;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnCamDisConnect_Click(object sender, EventArgs e)
        {
            TCPObj.Disconnect();
        }
        #endregion

        #region Scanner Functions

        /// <summary>
        /// Connect Scanner
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnScannerConnect_Click(object sender, EventArgs e)
        {
            try
            {
                //TCPObj = ObjectList.ScnrObj[cmbScanner.SelectedIndex];
                
                if (cmbScanner.SelectedItem != null)
                {
                    TCPObj = ObjectList.CCDObj[(int)((dynamic)cmbScanner.SelectedItem).Key];
                }
                else
                {
                    MessageBox.Show("can't connect !. selected item is empty");
                    return;
                }

                if (!TCPObj.CheckConnectStatus())
                {
                    if (TCPObj.Connect())
                    {
                        lblScanrConStatus.BackColor = Color.Lime;
                    }
                    else
                    {
                        lblScanrConStatus.BackColor = Color.Maroon;
                    }
                }
                else
                {
                    lblScanrConStatus.BackColor = Color.Lime;
                }

            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        /// <summary>
        /// Trigger Scanner
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnScannerTrigger_Click(object sender, EventArgs e)
        {
            try
            {
                txtScannerRecieve.Text = "";

                if (TCPObj.Send(txtScannerSend.Text.Trim()))
                {
                    string ScnrResult = TCPObj.Receive(600001);
                    txtScannerRecieve.Text = ScnrResult;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnScnrDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                TCPObj.Disconnect();
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }
        #endregion

        #region OPT Related Functions

        private void btnOPTConnect_Click(object sender, EventArgs e)
        {
            try
            {
                //COMPortObj = ObjectList.COMObj[cmbCOMPort.SelectedIndex];
              
                if (cmbCOMPort.SelectedItem != null)
                {
                    COMPortObj = ObjectList.COMObj[(int)((dynamic)cmbCOMPort.SelectedItem).Key];
                }
                else
                {
                    MessageBox.Show("can't connect !. selected item is empty");
                    return;
                }

                if (COMPortObj != null && !COMPortObj.Connect_OPT())
                {
                    MessageBox.Show("OPT Controller Connection Failed !", "OPT Connection", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnOPTTrigger_Click(object sender, EventArgs e)
        {
            try
            {
                COMPortObj = ObjectList.COMObj[cmbCOMPort.SelectedIndex];

                if (COMPortObj != null && !COMPortObj.Write_OPT(cmbOPTSend.SelectedValue.ToString()))
                {
                    MessageBox.Show("OPT Controller Send Failed !", "OPT Connection", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnOPTDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                COMPortObj = ObjectList.COMObj[cmbCOMPort.SelectedIndex];

                if (COMPortObj != null && !COMPortObj.Disconnect_OPT())
                {
                    MessageBox.Show("OPT Controller Connection Failed !", "OPT Connection", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void cmbOPTSend_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        #endregion

        #region SFC & PDCA Functions

        private void btnSFCConnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ObjectList.SFC.CheckConnectStatus())
                {
                    if (ObjectList.SFC.Connect())
                    {
                        lblSFCConStatus.BackColor = Color.Lime;
                    }
                    else
                    {
                        lblSFCConStatus.BackColor = Color.Maroon;
                    }
                }
                else
                {
                    lblSFCConStatus.BackColor = Color.Lime;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnSFCTrigger_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        private void btnSFCDisConnect_Click(object sender, EventArgs e)
        {
            try
            {
                ObjectList.SFC.Disconnect();
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "ManualScreen", "", ex.Message, ex.ToString());
            }
        }

        #endregion




        #region CONVEYOR STEPPER 


        public void LoadConveyorMotor()
        {

            cmbConveyorStepperCombo.SelectedIndexChanged -= cmbConveyorStepperCombo_SelectedIndexChanged;

            var motorList = IO_Stepper_Config.ConvStepperMotorObj
    .Select(kv => new
    {
        Key = kv.Key,
        Motor = kv.Value,
        Name = kv.Value.MotorName,
    })
    .ToList();

            if (motorList != null && motorList.Count != 0)
            {
                cmbConveyorStepperCombo.DataSource = motorList;
                cmbConveyorStepperCombo.DisplayMember = "Name";
                cmbConveyorStepperCombo.ValueMember = "Key";

                cmbConveyorStepperCombo.SelectedIndex = 0; // select first item
                cmbConveyorStepperCombo_SelectedIndexChanged(cmbConveyorStepperCombo, EventArgs.Empty);
                cmbConveyorStepperCombo.SelectedIndexChanged += cmbConveyorStepperCombo_SelectedIndexChanged;
            }
        }

        private void cmbConveyorStepperCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateConvStepperStatus();
        }

        private void Conv_Forward_Click(object sender, EventArgs e)
        {
            var stepper = GetSelectedStepper();
            if (stepper != null)
            {
                bool success = stepper.Forward();
                if (!success)
                    MessageBox.Show("Forward failed!");
            }
        }

        private void Conv_Reverse_Click(object sender, EventArgs e)
        {
            var stepper = GetSelectedStepper();
            if (stepper != null)
            {
                bool success = stepper.Reverse();
                if (!success)
                    MessageBox.Show("Reverse failed!");
            }
        }

        private void Conv_Stop_Click(object sender, EventArgs e)
        {
            var stepper = GetSelectedStepper();
            if (stepper != null)
            {
                bool success = stepper.Stop();
                if (!success)
                    MessageBox.Show("Stop failed!");
            }
        }

        private void Conv_Reset_Click(object sender, EventArgs e)
        {
            var stepper = GetSelectedStepper();
            if (stepper != null)
            {
                bool success = stepper.AlarmReset();
                if (!success)
                    MessageBox.Show("Alarm reset failed!");
            }
        }

        private IO_Stepper.IO_Stepper GetSelectedStepper()
        {
            var selectedItem = cmbConveyorStepperCombo.SelectedItem;
            if (selectedItem != null)
            {
                // Your DataSource is an anonymous type: { Key, MotorName, Stepper }
                dynamic item = selectedItem;
                return item.Motor;
            }
            return null;
        }
        private void UpdateConvStepperStatus()
        {
            if (cmbConveyorStepperCombo.SelectedItem is object selected)
            {
                var stepper = ((dynamic)selected).Motor;

                bool alarm = stepper.AlarmHappen;

                Conv_Status.BackColor = alarm ? Color.Maroon : Color.Lime;
                Conv_Status.ForeColor = Color.Black;
                Conv_Status.Text = alarm ? "Alarm !" : "Ready";
            }
        }

        #endregion

        private void txtServoX_Targetposition_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            GlobalVariable.ApplyTextBoxConfig(txt, "MCpositionLen", e, allowDecimal: true, allowMinus: true);
        }

        private void txtServoX_Targetspeed_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            GlobalVariable.ApplyTextBoxConfig(txt, "MCSpeedLen", e, allowDecimal: false, allowMinus: false);
        }

        private void txtHome_Velocity_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            GlobalVariable.ApplyTextBoxConfig(txt, "HCVelocityLen", e, allowDecimal: false, allowMinus: false);
        }

        private void txtJogSpeed_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            GlobalVariable.ApplyTextBoxConfig(txt, "JCSpeedLenLen", e, allowDecimal: false, allowMinus: false);
        }

        private void txtPTP_Start_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            GlobalVariable.ApplyTextBoxConfig(txt, "PPCStartPositionLen", e, allowDecimal: true, allowMinus: true);
        }

        private void txtPTP_End_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            GlobalVariable.ApplyTextBoxConfig(txt, "PPCEndPositionLen", e, allowDecimal: true, allowMinus: true);
        }

        private void txtPTP_Speed_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            GlobalVariable.ApplyTextBoxConfig(txt, "PPCSpeedLen", e, allowDecimal: false, allowMinus: false);
        }

        private void txtWait_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            GlobalVariable.ApplyTextBoxConfig(txt, "PPCWaitLen", e, allowDecimal: false, allowMinus: false);
        }

        private void txtIteration_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            GlobalVariable.ApplyTextBoxConfig(txt, "PPCIterationLen", e, allowDecimal: false, allowMinus: false);
        }

        private void txtSpeed_CrrCny1_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            GlobalVariable.ApplyTextBoxConfig(txt, "CrrCynSpeedLen", e, allowDecimal: false, allowMinus: false);
        }
    }
}
