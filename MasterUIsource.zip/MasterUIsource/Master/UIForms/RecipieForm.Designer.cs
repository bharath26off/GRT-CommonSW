﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace UI.UI_Forms
{
    partial class RecipieForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RecipieForm));
            this.RecipieTabPanel = new System.Windows.Forms.Panel();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.label316 = new System.Windows.Forms.Label();
            this.label313 = new System.Windows.Forms.Label();
            this.label315 = new System.Windows.Forms.Label();
            this.label314 = new System.Windows.Forms.Label();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.grpMoveAbsolute = new System.Windows.Forms.GroupBox();
            this.btnMoveAbs = new System.Windows.Forms.Button();
            this.lblServoX_TargetSpeed = new System.Windows.Forms.Label();
            this.txtetSpeedAbs = new System.Windows.Forms.TextBox();
            this.lblMoveAbsSpeed = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbMoveMode = new System.Windows.Forms.ComboBox();
            this.cmbAxisMoveAbs = new System.Windows.Forms.ComboBox();
            this.lblMoveAbsSelectAxis = new System.Windows.Forms.Label();
            this.btnStop = new System.Windows.Forms.Button();
            this.lblServoX_TargetPosition = new System.Windows.Forms.Label();
            this.txtPositionAbs = new System.Windows.Forms.TextBox();
            this.lblMoveAbsPos = new System.Windows.Forms.Label();
            this.grpGantry = new System.Windows.Forms.GroupBox();
            this.btnZDec = new System.Windows.Forms.Button();
            this.btnZAdd = new System.Windows.Forms.Button();
            this.lblZ_Position = new System.Windows.Forms.Label();
            this.txt_PrfPos_Z1 = new System.Windows.Forms.TextBox();
            this.lblY_Position = new System.Windows.Forms.Label();
            this.txt_PrfPos_Y1 = new System.Windows.Forms.TextBox();
            this.btnXAdd = new System.Windows.Forms.Button();
            this.btnYDec = new System.Windows.Forms.Button();
            this.btnYAdd = new System.Windows.Forms.Button();
            this.btnXDec = new System.Windows.Forms.Button();
            this.lblX_Position = new System.Windows.Forms.Label();
            this.txt_PrfPos_X1 = new System.Windows.Forms.TextBox();
            this.grp_EditSave = new System.Windows.Forms.GroupBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.lblSave = new System.Windows.Forms.Label();
            this.lblEdit = new System.Windows.Forms.Label();
            this.tabRecipe = new System.Windows.Forms.TabControl();
            this.PickGantry = new System.Windows.Forms.TabPage();
            this.cmbSelGantry = new System.Windows.Forms.ComboBox();
            this.lblSelGantry = new System.Windows.Forms.Label();
            this.dgv_PickGantry = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.moveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teachToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Robot = new System.Windows.Forms.TabPage();
            this.btnSaveRobot = new System.Windows.Forms.Button();
            this.dgv_Robot = new System.Windows.Forms.DataGridView();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.RecipieTabPanel.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.grpMoveAbsolute.SuspendLayout();
            this.grpGantry.SuspendLayout();
            this.grp_EditSave.SuspendLayout();
            this.tabRecipe.SuspendLayout();
            this.PickGantry.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PickGantry)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.Robot.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Robot)).BeginInit();
            this.SuspendLayout();
            // 
            // RecipieTabPanel
            // 
            this.RecipieTabPanel.Controls.Add(this.pnlMain);
            this.RecipieTabPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RecipieTabPanel.Location = new System.Drawing.Point(0, 0);
            this.RecipieTabPanel.Margin = new System.Windows.Forms.Padding(4);
            this.RecipieTabPanel.Name = "RecipieTabPanel";
            this.RecipieTabPanel.Size = new System.Drawing.Size(1300, 763);
            this.RecipieTabPanel.TabIndex = 0;
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.panel2);
            this.pnlMain.Controls.Add(this.grp_EditSave);
            this.pnlMain.Controls.Add(this.tabRecipe);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Margin = new System.Windows.Forms.Padding(4);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1300, 763);
            this.pnlMain.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.groupBox7);
            this.panel2.Controls.Add(this.grpMoveAbsolute);
            this.panel2.Controls.Add(this.grpGantry);
            this.panel2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(28, 507);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1205, 256);
            this.panel2.TabIndex = 83;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.White;
            this.groupBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox7.Controls.Add(this.textBox62);
            this.groupBox7.Controls.Add(this.label316);
            this.groupBox7.Controls.Add(this.label313);
            this.groupBox7.Controls.Add(this.label315);
            this.groupBox7.Controls.Add(this.label314);
            this.groupBox7.Controls.Add(this.textBox63);
            this.groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox7.Location = new System.Drawing.Point(858, 8);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(337, 241);
            this.groupBox7.TabIndex = 86;
            this.groupBox7.TabStop = false;
            // 
            // textBox62
            // 
            this.textBox62.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox62.Location = new System.Drawing.Point(184, 59);
            this.textBox62.Margin = new System.Windows.Forms.Padding(4);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(79, 24);
            this.textBox62.TabIndex = 16;
            this.textBox62.Text = "0000";
            this.textBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label316
            // 
            this.label316.AutoSize = true;
            this.label316.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label316.Location = new System.Drawing.Point(31, 66);
            this.label316.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label316.Name = "label316";
            this.label316.Size = new System.Drawing.Size(86, 17);
            this.label316.TabIndex = 14;
            this.label316.Text = "Loadcell 2";
            // 
            // label313
            // 
            this.label313.AutoSize = true;
            this.label313.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label313.Location = new System.Drawing.Point(271, 65);
            this.label313.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label313.Name = "label313";
            this.label313.Size = new System.Drawing.Size(30, 20);
            this.label313.TabIndex = 18;
            this.label313.Text = "kg";
            // 
            // label315
            // 
            this.label315.AutoSize = true;
            this.label315.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label315.Location = new System.Drawing.Point(31, 25);
            this.label315.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label315.Name = "label315";
            this.label315.Size = new System.Drawing.Size(86, 17);
            this.label315.TabIndex = 13;
            this.label315.Text = "Loadcell 1";
            // 
            // label314
            // 
            this.label314.AutoSize = true;
            this.label314.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label314.Location = new System.Drawing.Point(271, 22);
            this.label314.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label314.Name = "label314";
            this.label314.Size = new System.Drawing.Size(30, 20);
            this.label314.TabIndex = 17;
            this.label314.Text = "kg";
            // 
            // textBox63
            // 
            this.textBox63.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox63.Location = new System.Drawing.Point(184, 18);
            this.textBox63.Margin = new System.Windows.Forms.Padding(4);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(79, 24);
            this.textBox63.TabIndex = 15;
            this.textBox63.Text = "0000";
            this.textBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // grpMoveAbsolute
            // 
            this.grpMoveAbsolute.BackColor = System.Drawing.Color.Silver;
            this.grpMoveAbsolute.Controls.Add(this.btnMoveAbs);
            this.grpMoveAbsolute.Controls.Add(this.lblServoX_TargetSpeed);
            this.grpMoveAbsolute.Controls.Add(this.txtetSpeedAbs);
            this.grpMoveAbsolute.Controls.Add(this.lblMoveAbsSpeed);
            this.grpMoveAbsolute.Controls.Add(this.label1);
            this.grpMoveAbsolute.Controls.Add(this.cmbMoveMode);
            this.grpMoveAbsolute.Controls.Add(this.cmbAxisMoveAbs);
            this.grpMoveAbsolute.Controls.Add(this.lblMoveAbsSelectAxis);
            this.grpMoveAbsolute.Controls.Add(this.btnStop);
            this.grpMoveAbsolute.Controls.Add(this.lblServoX_TargetPosition);
            this.grpMoveAbsolute.Controls.Add(this.txtPositionAbs);
            this.grpMoveAbsolute.Controls.Add(this.lblMoveAbsPos);
            this.grpMoveAbsolute.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpMoveAbsolute.Location = new System.Drawing.Point(4, 8);
            this.grpMoveAbsolute.Margin = new System.Windows.Forms.Padding(4);
            this.grpMoveAbsolute.Name = "grpMoveAbsolute";
            this.grpMoveAbsolute.Padding = new System.Windows.Forms.Padding(4);
            this.grpMoveAbsolute.Size = new System.Drawing.Size(401, 241);
            this.grpMoveAbsolute.TabIndex = 84;
            this.grpMoveAbsolute.TabStop = false;
            this.grpMoveAbsolute.Text = "0";
            // 
            // btnMoveAbs
            // 
            this.btnMoveAbs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnMoveAbs.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMoveAbs.ForeColor = System.Drawing.Color.White;
            this.btnMoveAbs.Location = new System.Drawing.Point(282, 138);
            this.btnMoveAbs.Margin = new System.Windows.Forms.Padding(4);
            this.btnMoveAbs.Name = "btnMoveAbs";
            this.btnMoveAbs.Size = new System.Drawing.Size(111, 46);
            this.btnMoveAbs.TabIndex = 88;
            this.btnMoveAbs.Text = "Move";
            this.btnMoveAbs.UseVisualStyleBackColor = false;
            this.btnMoveAbs.Click += new System.EventHandler(this.btnMoveAbs_Click);
            // 
            // lblServoX_TargetSpeed
            // 
            this.lblServoX_TargetSpeed.AutoSize = true;
            this.lblServoX_TargetSpeed.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServoX_TargetSpeed.Location = new System.Drawing.Point(216, 109);
            this.lblServoX_TargetSpeed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblServoX_TargetSpeed.Name = "lblServoX_TargetSpeed";
            this.lblServoX_TargetSpeed.Size = new System.Drawing.Size(59, 18);
            this.lblServoX_TargetSpeed.TabIndex = 87;
            this.lblServoX_TargetSpeed.Text = "(mm/s)";
            // 
            // txtetSpeedAbs
            // 
            this.txtetSpeedAbs.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtetSpeedAbs.Location = new System.Drawing.Point(113, 98);
            this.txtetSpeedAbs.Margin = new System.Windows.Forms.Padding(4);
            this.txtetSpeedAbs.Name = "txtetSpeedAbs";
            this.txtetSpeedAbs.Size = new System.Drawing.Size(96, 30);
            this.txtetSpeedAbs.TabIndex = 86;
            this.txtetSpeedAbs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtetSpeedAbs_KeyPress);
            // 
            // lblMoveAbsSpeed
            // 
            this.lblMoveAbsSpeed.AutoSize = true;
            this.lblMoveAbsSpeed.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoveAbsSpeed.Location = new System.Drawing.Point(8, 104);
            this.lblMoveAbsSpeed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMoveAbsSpeed.Name = "lblMoveAbsSpeed";
            this.lblMoveAbsSpeed.Size = new System.Drawing.Size(54, 18);
            this.lblMoveAbsSpeed.TabIndex = 85;
            this.lblMoveAbsSpeed.Text = "Speed";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 65);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 18);
            this.label1.TabIndex = 84;
            this.label1.Text = "Move Mode";
            // 
            // cmbMoveMode
            // 
            this.cmbMoveMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMoveMode.FormattingEnabled = true;
            this.cmbMoveMode.Items.AddRange(new object[] {
            "Absolute",
            "Jog"});
            this.cmbMoveMode.Location = new System.Drawing.Point(113, 57);
            this.cmbMoveMode.Margin = new System.Windows.Forms.Padding(4);
            this.cmbMoveMode.Name = "cmbMoveMode";
            this.cmbMoveMode.Size = new System.Drawing.Size(280, 26);
            this.cmbMoveMode.TabIndex = 83;
            this.cmbMoveMode.SelectedIndexChanged += new System.EventHandler(this.cmbMoveMode_SelectedIndexChanged);
            // 
            // cmbAxisMoveAbs
            // 
            this.cmbAxisMoveAbs.FormattingEnabled = true;
            this.cmbAxisMoveAbs.Items.AddRange(new object[] {
            "X",
            "Y",
            "Z"});
            this.cmbAxisMoveAbs.Location = new System.Drawing.Point(113, 22);
            this.cmbAxisMoveAbs.Margin = new System.Windows.Forms.Padding(4);
            this.cmbAxisMoveAbs.Name = "cmbAxisMoveAbs";
            this.cmbAxisMoveAbs.Size = new System.Drawing.Size(280, 26);
            this.cmbAxisMoveAbs.TabIndex = 82;
            this.cmbAxisMoveAbs.SelectedIndexChanged += new System.EventHandler(this.cmbAxisMoveAbs_SelectedIndexChanged);
            this.cmbAxisMoveAbs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmbAxisMoveAbs_KeyPress);
            // 
            // lblMoveAbsSelectAxis
            // 
            this.lblMoveAbsSelectAxis.AutoSize = true;
            this.lblMoveAbsSelectAxis.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoveAbsSelectAxis.Location = new System.Drawing.Point(8, 25);
            this.lblMoveAbsSelectAxis.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMoveAbsSelectAxis.Name = "lblMoveAbsSelectAxis";
            this.lblMoveAbsSelectAxis.Size = new System.Drawing.Size(91, 18);
            this.lblMoveAbsSelectAxis.TabIndex = 81;
            this.lblMoveAbsSelectAxis.Text = "Select Axis";
            // 
            // btnStop
            // 
            this.btnStop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnStop.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStop.ForeColor = System.Drawing.Color.White;
            this.btnStop.Location = new System.Drawing.Point(282, 93);
            this.btnStop.Margin = new System.Windows.Forms.Padding(4);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(111, 46);
            this.btnStop.TabIndex = 80;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = false;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // lblServoX_TargetPosition
            // 
            this.lblServoX_TargetPosition.AutoSize = true;
            this.lblServoX_TargetPosition.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServoX_TargetPosition.Location = new System.Drawing.Point(219, 154);
            this.lblServoX_TargetPosition.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblServoX_TargetPosition.Name = "lblServoX_TargetPosition";
            this.lblServoX_TargetPosition.Size = new System.Drawing.Size(46, 18);
            this.lblServoX_TargetPosition.TabIndex = 77;
            this.lblServoX_TargetPosition.Text = "(mm)";
            // 
            // txtPositionAbs
            // 
            this.txtPositionAbs.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPositionAbs.Location = new System.Drawing.Point(113, 148);
            this.txtPositionAbs.Margin = new System.Windows.Forms.Padding(4);
            this.txtPositionAbs.Name = "txtPositionAbs";
            this.txtPositionAbs.Size = new System.Drawing.Size(96, 30);
            this.txtPositionAbs.TabIndex = 74;
            this.txtPositionAbs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPositionAbs_KeyPress);
            // 
            // lblMoveAbsPos
            // 
            this.lblMoveAbsPos.AutoSize = true;
            this.lblMoveAbsPos.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMoveAbsPos.Location = new System.Drawing.Point(8, 149);
            this.lblMoveAbsPos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMoveAbsPos.Name = "lblMoveAbsPos";
            this.lblMoveAbsPos.Size = new System.Drawing.Size(69, 18);
            this.lblMoveAbsPos.TabIndex = 73;
            this.lblMoveAbsPos.Text = "Position";
            // 
            // grpGantry
            // 
            this.grpGantry.Controls.Add(this.btnZDec);
            this.grpGantry.Controls.Add(this.btnZAdd);
            this.grpGantry.Controls.Add(this.lblZ_Position);
            this.grpGantry.Controls.Add(this.txt_PrfPos_Z1);
            this.grpGantry.Controls.Add(this.lblY_Position);
            this.grpGantry.Controls.Add(this.txt_PrfPos_Y1);
            this.grpGantry.Controls.Add(this.btnXAdd);
            this.grpGantry.Controls.Add(this.btnYDec);
            this.grpGantry.Controls.Add(this.btnYAdd);
            this.grpGantry.Controls.Add(this.btnXDec);
            this.grpGantry.Controls.Add(this.lblX_Position);
            this.grpGantry.Controls.Add(this.txt_PrfPos_X1);
            this.grpGantry.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpGantry.Location = new System.Drawing.Point(424, 8);
            this.grpGantry.Margin = new System.Windows.Forms.Padding(4);
            this.grpGantry.Name = "grpGantry";
            this.grpGantry.Padding = new System.Windows.Forms.Padding(4);
            this.grpGantry.Size = new System.Drawing.Size(419, 241);
            this.grpGantry.TabIndex = 0;
            this.grpGantry.TabStop = false;
            this.grpGantry.Text = "Gantry";
            // 
            // btnZDec
            // 
            this.btnZDec.BackColor = System.Drawing.Color.Black;
            this.btnZDec.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnZDec.BackgroundImage")));
            this.btnZDec.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnZDec.Location = new System.Drawing.Point(54, 174);
            this.btnZDec.Margin = new System.Windows.Forms.Padding(4);
            this.btnZDec.Name = "btnZDec";
            this.btnZDec.Size = new System.Drawing.Size(67, 62);
            this.btnZDec.TabIndex = 20;
            this.btnZDec.UseVisualStyleBackColor = false;
            this.btnZDec.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnZDec_MouseDown);
            this.btnZDec.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnZDec_MouseUp);
            // 
            // btnZAdd
            // 
            this.btnZAdd.BackColor = System.Drawing.Color.Black;
            this.btnZAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnZAdd.BackgroundImage")));
            this.btnZAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnZAdd.Location = new System.Drawing.Point(157, 174);
            this.btnZAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnZAdd.Name = "btnZAdd";
            this.btnZAdd.Size = new System.Drawing.Size(67, 62);
            this.btnZAdd.TabIndex = 19;
            this.btnZAdd.UseVisualStyleBackColor = false;
            this.btnZAdd.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnZAdd_MouseDown);
            this.btnZAdd.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnZAdd_MouseUp);
            // 
            // lblZ_Position
            // 
            this.lblZ_Position.AutoSize = true;
            this.lblZ_Position.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZ_Position.Location = new System.Drawing.Point(266, 180);
            this.lblZ_Position.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblZ_Position.Name = "lblZ_Position";
            this.lblZ_Position.Size = new System.Drawing.Size(121, 17);
            this.lblZ_Position.TabIndex = 10;
            this.lblZ_Position.Text = "Z Position (mm)";
            // 
            // txt_PrfPos_Z1
            // 
            this.txt_PrfPos_Z1.Enabled = false;
            this.txt_PrfPos_Z1.Location = new System.Drawing.Point(277, 197);
            this.txt_PrfPos_Z1.Margin = new System.Windows.Forms.Padding(4);
            this.txt_PrfPos_Z1.Name = "txt_PrfPos_Z1";
            this.txt_PrfPos_Z1.Size = new System.Drawing.Size(109, 27);
            this.txt_PrfPos_Z1.TabIndex = 9;
            this.txt_PrfPos_Z1.Text = "0";
            this.txt_PrfPos_Z1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblY_Position
            // 
            this.lblY_Position.AutoSize = true;
            this.lblY_Position.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblY_Position.Location = new System.Drawing.Point(265, 105);
            this.lblY_Position.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblY_Position.Name = "lblY_Position";
            this.lblY_Position.Size = new System.Drawing.Size(120, 17);
            this.lblY_Position.TabIndex = 14;
            this.lblY_Position.Text = "Y Position (mm)";
            // 
            // txt_PrfPos_Y1
            // 
            this.txt_PrfPos_Y1.Enabled = false;
            this.txt_PrfPos_Y1.Location = new System.Drawing.Point(276, 122);
            this.txt_PrfPos_Y1.Margin = new System.Windows.Forms.Padding(4);
            this.txt_PrfPos_Y1.Name = "txt_PrfPos_Y1";
            this.txt_PrfPos_Y1.Size = new System.Drawing.Size(109, 27);
            this.txt_PrfPos_Y1.TabIndex = 13;
            this.txt_PrfPos_Y1.Text = "0";
            this.txt_PrfPos_Y1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnXAdd
            // 
            this.btnXAdd.BackColor = System.Drawing.Color.Black;
            this.btnXAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnXAdd.BackgroundImage")));
            this.btnXAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnXAdd.Location = new System.Drawing.Point(173, 62);
            this.btnXAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnXAdd.Name = "btnXAdd";
            this.btnXAdd.Size = new System.Drawing.Size(67, 62);
            this.btnXAdd.TabIndex = 9;
            this.btnXAdd.UseVisualStyleBackColor = false;
            this.btnXAdd.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnXAdd_MouseDown);
            this.btnXAdd.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnXAdd_MouseUp);
            // 
            // btnYDec
            // 
            this.btnYDec.BackColor = System.Drawing.Color.Black;
            this.btnYDec.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnYDec.BackgroundImage")));
            this.btnYDec.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnYDec.Location = new System.Drawing.Point(100, 18);
            this.btnYDec.Margin = new System.Windows.Forms.Padding(4);
            this.btnYDec.Name = "btnYDec";
            this.btnYDec.Size = new System.Drawing.Size(67, 62);
            this.btnYDec.TabIndex = 11;
            this.btnYDec.UseVisualStyleBackColor = false;
            this.btnYDec.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnYDec_MouseDown);
            this.btnYDec.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnYDec_MouseUp);
            // 
            // btnYAdd
            // 
            this.btnYAdd.BackColor = System.Drawing.Color.Black;
            this.btnYAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnYAdd.BackgroundImage")));
            this.btnYAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnYAdd.Location = new System.Drawing.Point(100, 101);
            this.btnYAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnYAdd.Name = "btnYAdd";
            this.btnYAdd.Size = new System.Drawing.Size(67, 62);
            this.btnYAdd.TabIndex = 10;
            this.btnYAdd.UseVisualStyleBackColor = false;
            this.btnYAdd.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnYAdd_MouseDown);
            this.btnYAdd.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnYAdd_MouseUp);
            // 
            // btnXDec
            // 
            this.btnXDec.BackColor = System.Drawing.Color.Black;
            this.btnXDec.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnXDec.BackgroundImage")));
            this.btnXDec.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnXDec.Location = new System.Drawing.Point(26, 62);
            this.btnXDec.Margin = new System.Windows.Forms.Padding(4);
            this.btnXDec.Name = "btnXDec";
            this.btnXDec.Size = new System.Drawing.Size(67, 62);
            this.btnXDec.TabIndex = 12;
            this.btnXDec.UseVisualStyleBackColor = false;
            this.btnXDec.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnXDec_MouseDown);
            this.btnXDec.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnXDec_MouseUp);
            // 
            // lblX_Position
            // 
            this.lblX_Position.AutoSize = true;
            this.lblX_Position.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblX_Position.Location = new System.Drawing.Point(265, 46);
            this.lblX_Position.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblX_Position.Name = "lblX_Position";
            this.lblX_Position.Size = new System.Drawing.Size(121, 17);
            this.lblX_Position.TabIndex = 2;
            this.lblX_Position.Text = "X Position (mm)";
            // 
            // txt_PrfPos_X1
            // 
            this.txt_PrfPos_X1.Enabled = false;
            this.txt_PrfPos_X1.Location = new System.Drawing.Point(276, 63);
            this.txt_PrfPos_X1.Margin = new System.Windows.Forms.Padding(4);
            this.txt_PrfPos_X1.Name = "txt_PrfPos_X1";
            this.txt_PrfPos_X1.Size = new System.Drawing.Size(109, 27);
            this.txt_PrfPos_X1.TabIndex = 1;
            this.txt_PrfPos_X1.Text = "0";
            this.txt_PrfPos_X1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // grp_EditSave
            // 
            this.grp_EditSave.BackColor = System.Drawing.SystemColors.Control;
            this.grp_EditSave.Controls.Add(this.btnSave);
            this.grp_EditSave.Controls.Add(this.btnEdit);
            this.grp_EditSave.Controls.Add(this.lblSave);
            this.grp_EditSave.Controls.Add(this.lblEdit);
            this.grp_EditSave.Location = new System.Drawing.Point(1245, 154);
            this.grp_EditSave.Margin = new System.Windows.Forms.Padding(4);
            this.grp_EditSave.Name = "grp_EditSave";
            this.grp_EditSave.Padding = new System.Windows.Forms.Padding(4);
            this.grp_EditSave.Size = new System.Drawing.Size(105, 251);
            this.grp_EditSave.TabIndex = 85;
            this.grp_EditSave.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.LightGray;
            this.btnSave.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSave.BackgroundImage")));
            this.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSave.Enabled = false;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnSave.Location = new System.Drawing.Point(17, 135);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(67, 62);
            this.btnSave.TabIndex = 61;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.LightGray;
            this.btnEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEdit.BackgroundImage")));
            this.btnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEdit.Enabled = false;
            this.btnEdit.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnEdit.Location = new System.Drawing.Point(17, 23);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(4);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(67, 62);
            this.btnEdit.TabIndex = 60;
            this.btnEdit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // lblSave
            // 
            this.lblSave.AutoSize = true;
            this.lblSave.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSave.Location = new System.Drawing.Point(23, 212);
            this.lblSave.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSave.Name = "lblSave";
            this.lblSave.Size = new System.Drawing.Size(54, 20);
            this.lblSave.TabIndex = 2;
            this.lblSave.Text = "Save";
            // 
            // lblEdit
            // 
            this.lblEdit.AutoSize = true;
            this.lblEdit.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEdit.Location = new System.Drawing.Point(25, 98);
            this.lblEdit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEdit.Name = "lblEdit";
            this.lblEdit.Size = new System.Drawing.Size(47, 20);
            this.lblEdit.TabIndex = 2;
            this.lblEdit.Text = "Edit";
            // 
            // tabRecipe
            // 
            this.tabRecipe.Controls.Add(this.PickGantry);
            this.tabRecipe.Controls.Add(this.Robot);
            this.tabRecipe.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabRecipe.Location = new System.Drawing.Point(4, 4);
            this.tabRecipe.Margin = new System.Windows.Forms.Padding(4);
            this.tabRecipe.Name = "tabRecipe";
            this.tabRecipe.SelectedIndex = 0;
            this.tabRecipe.Size = new System.Drawing.Size(1233, 501);
            this.tabRecipe.TabIndex = 84;
            // 
            // PickGantry
            // 
            this.PickGantry.Controls.Add(this.cmbSelGantry);
            this.PickGantry.Controls.Add(this.lblSelGantry);
            this.PickGantry.Controls.Add(this.dgv_PickGantry);
            this.PickGantry.Location = new System.Drawing.Point(4, 34);
            this.PickGantry.Margin = new System.Windows.Forms.Padding(4);
            this.PickGantry.Name = "PickGantry";
            this.PickGantry.Size = new System.Drawing.Size(1225, 463);
            this.PickGantry.TabIndex = 5;
            this.PickGantry.Text = "GANTRY";
            this.PickGantry.UseVisualStyleBackColor = true;
            // 
            // cmbSelGantry
            // 
            this.cmbSelGantry.FormattingEnabled = true;
            this.cmbSelGantry.Location = new System.Drawing.Point(217, 20);
            this.cmbSelGantry.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSelGantry.Name = "cmbSelGantry";
            this.cmbSelGantry.Size = new System.Drawing.Size(233, 33);
            this.cmbSelGantry.TabIndex = 2;
            this.cmbSelGantry.SelectedIndexChanged += new System.EventHandler(this.cmbSelGantry_SelectedIndexChanged);
            // 
            // lblSelGantry
            // 
            this.lblSelGantry.AutoSize = true;
            this.lblSelGantry.Location = new System.Drawing.Point(29, 23);
            this.lblSelGantry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelGantry.Name = "lblSelGantry";
            this.lblSelGantry.Size = new System.Drawing.Size(162, 25);
            this.lblSelGantry.TabIndex = 1;
            this.lblSelGantry.Text = "Select Gantry";
            // 
            // dgv_PickGantry
            // 
            this.dgv_PickGantry.AllowUserToAddRows = false;
            this.dgv_PickGantry.AllowUserToDeleteRows = false;
            this.dgv_PickGantry.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_PickGantry.BackgroundColor = System.Drawing.Color.White;
            this.dgv_PickGantry.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_PickGantry.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv_PickGantry.Location = new System.Drawing.Point(0, 69);
            this.dgv_PickGantry.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_PickGantry.Name = "dgv_PickGantry";
            this.dgv_PickGantry.RowHeadersWidth = 51;
            this.dgv_PickGantry.Size = new System.Drawing.Size(1219, 394);
            this.dgv_PickGantry.TabIndex = 0;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.moveToolStripMenuItem,
            this.teachToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(117, 52);
            // 
            // moveToolStripMenuItem
            // 
            this.moveToolStripMenuItem.Name = "moveToolStripMenuItem";
            this.moveToolStripMenuItem.Size = new System.Drawing.Size(116, 24);
            this.moveToolStripMenuItem.Text = "Move";
            this.moveToolStripMenuItem.Click += new System.EventHandler(this.moveToolStripMenuItem_Click);
            // 
            // teachToolStripMenuItem
            // 
            this.teachToolStripMenuItem.Name = "teachToolStripMenuItem";
            this.teachToolStripMenuItem.Size = new System.Drawing.Size(116, 24);
            this.teachToolStripMenuItem.Text = "Teach";
            this.teachToolStripMenuItem.Click += new System.EventHandler(this.teachToolStripMenuItem_Click);
            // 
            // Robot
            // 
            this.Robot.Controls.Add(this.btnSaveRobot);
            this.Robot.Controls.Add(this.dgv_Robot);
            this.Robot.Location = new System.Drawing.Point(4, 34);
            this.Robot.Margin = new System.Windows.Forms.Padding(4);
            this.Robot.Name = "Robot";
            this.Robot.Size = new System.Drawing.Size(1225, 463);
            this.Robot.TabIndex = 7;
            this.Robot.Text = "ROBOT";
            this.Robot.UseVisualStyleBackColor = true;
            // 
            // btnSaveRobot
            // 
            this.btnSaveRobot.AutoSize = true;
            this.btnSaveRobot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnSaveRobot.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnSaveRobot.ForeColor = System.Drawing.Color.White;
            this.btnSaveRobot.Location = new System.Drawing.Point(759, 32);
            this.btnSaveRobot.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveRobot.Name = "btnSaveRobot";
            this.btnSaveRobot.Size = new System.Drawing.Size(183, 46);
            this.btnSaveRobot.TabIndex = 33;
            this.btnSaveRobot.Text = "Save Robot";
            this.btnSaveRobot.UseVisualStyleBackColor = false;
            this.btnSaveRobot.Click += new System.EventHandler(this.btnSaveRobot_Click);
            // 
            // dgv_Robot
            // 
            this.dgv_Robot.AllowUserToAddRows = false;
            this.dgv_Robot.BackgroundColor = System.Drawing.Color.White;
            this.dgv_Robot.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Robot.Location = new System.Drawing.Point(4, 2);
            this.dgv_Robot.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_Robot.Name = "dgv_Robot";
            this.dgv_Robot.RowHeadersWidth = 51;
            this.dgv_Robot.Size = new System.Drawing.Size(747, 533);
            this.dgv_Robot.TabIndex = 4;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // RecipieForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 763);
            this.Controls.Add(this.RecipieTabPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "RecipieForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "RecipieForm";
            this.Load += new System.EventHandler(this.RecipieForm_Load);
            this.RecipieTabPanel.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.grpMoveAbsolute.ResumeLayout(false);
            this.grpMoveAbsolute.PerformLayout();
            this.grpGantry.ResumeLayout(false);
            this.grpGantry.PerformLayout();
            this.grp_EditSave.ResumeLayout(false);
            this.grp_EditSave.PerformLayout();
            this.tabRecipe.ResumeLayout(false);
            this.PickGantry.ResumeLayout(false);
            this.PickGantry.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PickGantry)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.Robot.ResumeLayout(false);
            this.Robot.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Robot)).EndInit();
            this.ResumeLayout(false);

        }

        private void cmbAxisMoveAbs_DropDownClosed(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cmbAxisMoveAbs.Text) || !cmbAxisMoveAbs.Items.Contains(cmbAxisMoveAbs.Text))
            {
                cmbAxisMoveAbs.Text = "SELECT";
                cmbAxisMoveAbs.ForeColor = Color.Gray;
            }
        }

        private void cmbAxisMoveAbs_DropDown(object sender, EventArgs e)
        {
            if (cmbAxisMoveAbs.Text == "SELECT" && cmbAxisMoveAbs.ForeColor == Color.Gray)
            {
                cmbAxisMoveAbs.Text = "";
                cmbAxisMoveAbs.ForeColor = Color.Black;
            }
        }

        private void cmbAxisMoveRel_DropDownClosed(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cmbAxisMoveAbs.Text) || !cmbAxisMoveAbs.Items.Contains(cmbAxisMoveAbs.Text))
            {
                cmbAxisMoveAbs.Text = "SELECT";
                cmbAxisMoveAbs.ForeColor = Color.Gray;
            }
        }

        private void cmbAxisMoveRel_DropDown(object sender, EventArgs e)
        {
            if (cmbAxisMoveAbs.Text == "SELECT" && cmbAxisMoveAbs.ForeColor == Color.Gray)
            {
                cmbAxisMoveAbs.Text = "";
                cmbAxisMoveAbs.ForeColor = Color.Black;
            }
        }






        #endregion

        private Panel RecipieTabPanel;
        private Panel pnlMain;
        private Panel panel2;
        private GroupBox grp_EditSave;
        private Label lblSave;
        private Label lblEdit;
        private Button btnEdit;
        private TabControl tabRecipe;
        private TabPage PickGantry;
        private DataGridView dgv_PickGantry;
        private TabPage Robot;
        private Button btnSaveRobot;
        private DataGridView dgv_Robot;
        private Button btnSave;
        private GroupBox grpGantry;
        private Button btnZDec;
        private Button btnZAdd;
        private Label lblZ_Position;
        private TextBox txt_PrfPos_Z1;
        private Label lblY_Position;
        private TextBox txt_PrfPos_Y1;
        private Button btnXAdd;
        private Button btnYDec;
        private Button btnYAdd;
        private Button btnXDec;
        private Label lblX_Position;
        private TextBox txt_PrfPos_X1;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem moveToolStripMenuItem;
        private ToolStripMenuItem teachToolStripMenuItem;
        private Label lblSelGantry;
        private ComboBox cmbSelGantry;
        private Timer timer1;
        private GroupBox grpMoveAbsolute;
        private ComboBox cmbAxisMoveAbs;
        private Label lblMoveAbsSelectAxis;
        private Button btnStop;
        private Label lblServoX_TargetPosition;
        private TextBox txtPositionAbs;
        private Label lblMoveAbsPos;
        private GroupBox groupBox7;
        private TextBox textBox62;
        private Label label316;
        private Label label313;
        private Label label315;
        private Label label314;
        private TextBox textBox63;
        private ComboBox cmbMoveMode;
        private Label label1;
        private Label lblServoX_TargetSpeed;
        private TextBox txtetSpeedAbs;
        private Label lblMoveAbsSpeed;
        private Button btnMoveAbs;
        // private Button Btn_SavePos;
    }
}