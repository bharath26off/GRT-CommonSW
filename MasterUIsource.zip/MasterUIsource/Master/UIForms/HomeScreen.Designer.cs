﻿using System.Drawing;
using System.Windows.Forms;
using System.Web.UI.DataVisualization.Charting;

namespace UI.UI_Forms
{
    partial class HomeScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.conectionStatusGrid = new System.Windows.Forms.DataGridView();
            this.pnlMachineStatus = new System.Windows.Forms.Panel();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.txtMachineMode = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtUph = new System.Windows.Forms.TextBox();
            this.txtCycletime = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.txtyYeldcnt = new System.Windows.Forms.TextBox();
            this.txtOverallcnt = new System.Windows.Forms.TextBox();
            this.txtFailcnt = new System.Windows.Forms.TextBox();
            this.txtPasscnt = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.pnlMachineHealth = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.lblShift = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lblTotaltime = new System.Windows.Forms.Label();
            this.lblIdletime = new System.Windows.Forms.Label();
            this.lblDowntime = new System.Windows.Forms.Label();
            this.lblRunTime = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.Homing = new System.Windows.Forms.Button();
            this.tabLog = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lstRunningLog = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgvAlarmlive = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.conectionStatusGrid)).BeginInit();
            this.pnlMachineStatus.SuspendLayout();
            this.pnlMachineHealth.SuspendLayout();
            this.tabLog.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlarmlive)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1365, 763);
            this.tabControl1.TabIndex = 139;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel1);
            this.tabPage3.Controls.Add(this.pnlMachineStatus);
            this.tabPage3.Controls.Add(this.pnlMachineHealth);
            this.tabPage3.Controls.Add(this.Homing);
            this.tabPage3.Controls.Add(this.tabLog);
            this.tabPage3.Location = new System.Drawing.Point(4, 34);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1357, 725);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "HOME SCREEN";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.conectionStatusGrid);
            this.panel1.Location = new System.Drawing.Point(796, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(558, 627);
            this.panel1.TabIndex = 98;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(158, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(297, 28);
            this.label1.TabIndex = 100;
            this.label1.Text = "CONNECTION STATUS";
            // 
            // conectionStatusGrid
            // 
            this.conectionStatusGrid.AllowUserToAddRows = false;
            this.conectionStatusGrid.BackgroundColor = System.Drawing.SystemColors.Control;
            this.conectionStatusGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.conectionStatusGrid.Location = new System.Drawing.Point(10, 45);
            this.conectionStatusGrid.Margin = new System.Windows.Forms.Padding(4);
            this.conectionStatusGrid.Name = "conectionStatusGrid";
            this.conectionStatusGrid.ReadOnly = true;
            this.conectionStatusGrid.RowHeadersWidth = 51;
            this.conectionStatusGrid.Size = new System.Drawing.Size(539, 568);
            this.conectionStatusGrid.TabIndex = 98;
            // 
            // pnlMachineStatus
            // 
            this.pnlMachineStatus.BackColor = System.Drawing.Color.White;
            this.pnlMachineStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMachineStatus.Controls.Add(this.textBox23);
            this.pnlMachineStatus.Controls.Add(this.txtMachineMode);
            this.pnlMachineStatus.Controls.Add(this.textBox25);
            this.pnlMachineStatus.Controls.Add(this.textBox7);
            this.pnlMachineStatus.Controls.Add(this.textBox6);
            this.pnlMachineStatus.Controls.Add(this.textBox5);
            this.pnlMachineStatus.Controls.Add(this.textBox4);
            this.pnlMachineStatus.Controls.Add(this.textBox3);
            this.pnlMachineStatus.Controls.Add(this.textBox2);
            this.pnlMachineStatus.Controls.Add(this.label4);
            this.pnlMachineStatus.Controls.Add(this.txtUph);
            this.pnlMachineStatus.Controls.Add(this.txtCycletime);
            this.pnlMachineStatus.Controls.Add(this.textBox17);
            this.pnlMachineStatus.Controls.Add(this.textBox16);
            this.pnlMachineStatus.Controls.Add(this.txtyYeldcnt);
            this.pnlMachineStatus.Controls.Add(this.txtOverallcnt);
            this.pnlMachineStatus.Controls.Add(this.txtFailcnt);
            this.pnlMachineStatus.Controls.Add(this.txtPasscnt);
            this.pnlMachineStatus.Controls.Add(this.textBox13);
            this.pnlMachineStatus.Controls.Add(this.textBox12);
            this.pnlMachineStatus.Controls.Add(this.textBox11);
            this.pnlMachineStatus.Controls.Add(this.textBox8);
            this.pnlMachineStatus.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pnlMachineStatus.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.pnlMachineStatus.Location = new System.Drawing.Point(393, 15);
            this.pnlMachineStatus.Margin = new System.Windows.Forms.Padding(4);
            this.pnlMachineStatus.Name = "pnlMachineStatus";
            this.pnlMachineStatus.Size = new System.Drawing.Size(395, 324);
            this.pnlMachineStatus.TabIndex = 96;
            // 
            // textBox23
            // 
            this.textBox23.BackColor = System.Drawing.Color.White;
            this.textBox23.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox23.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(174, 57);
            this.textBox23.Margin = new System.Windows.Forms.Padding(4);
            this.textBox23.Name = "textBox23";
            this.textBox23.ReadOnly = true;
            this.textBox23.Size = new System.Drawing.Size(20, 21);
            this.textBox23.TabIndex = 108;
            this.textBox23.Text = " :";
            // 
            // txtMachineMode
            // 
            this.txtMachineMode.BackColor = System.Drawing.Color.White;
            this.txtMachineMode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMachineMode.Enabled = false;
            this.txtMachineMode.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMachineMode.Location = new System.Drawing.Point(222, 57);
            this.txtMachineMode.Margin = new System.Windows.Forms.Padding(4);
            this.txtMachineMode.Name = "txtMachineMode";
            this.txtMachineMode.ReadOnly = true;
            this.txtMachineMode.Size = new System.Drawing.Size(164, 21);
            this.txtMachineMode.TabIndex = 107;
            this.txtMachineMode.Text = "Dry Run";
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.Color.White;
            this.textBox25.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox25.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox25.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(14, 57);
            this.textBox25.Margin = new System.Windows.Forms.Padding(4);
            this.textBox25.Name = "textBox25";
            this.textBox25.ReadOnly = true;
            this.textBox25.Size = new System.Drawing.Size(156, 21);
            this.textBox25.TabIndex = 106;
            this.textBox25.Text = "Machine Mode";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.White;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(174, 285);
            this.textBox7.Margin = new System.Windows.Forms.Padding(4);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(20, 21);
            this.textBox7.TabIndex = 105;
            this.textBox7.Text = " :";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.White;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(174, 242);
            this.textBox6.Margin = new System.Windows.Forms.Padding(4);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(20, 21);
            this.textBox6.TabIndex = 104;
            this.textBox6.Text = " :";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.White;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(174, 206);
            this.textBox5.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(20, 21);
            this.textBox5.TabIndex = 103;
            this.textBox5.Text = " :";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.White;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(174, 169);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(20, 21);
            this.textBox4.TabIndex = 102;
            this.textBox4.Text = " :";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(174, 131);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(20, 21);
            this.textBox3.TabIndex = 101;
            this.textBox3.Text = " :";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(174, 95);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(20, 21);
            this.textBox2.TabIndex = 100;
            this.textBox2.Text = " :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(111, 7);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(245, 28);
            this.label4.TabIndex = 99;
            this.label4.Text = "MACHINE STATUS";
            // 
            // txtUph
            // 
            this.txtUph.BackColor = System.Drawing.Color.White;
            this.txtUph.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUph.Enabled = false;
            this.txtUph.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUph.Location = new System.Drawing.Point(222, 285);
            this.txtUph.Margin = new System.Windows.Forms.Padding(4);
            this.txtUph.Name = "txtUph";
            this.txtUph.ReadOnly = true;
            this.txtUph.Size = new System.Drawing.Size(164, 21);
            this.txtUph.TabIndex = 98;
            this.txtUph.Text = "0";
            // 
            // txtCycletime
            // 
            this.txtCycletime.BackColor = System.Drawing.Color.White;
            this.txtCycletime.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCycletime.Enabled = false;
            this.txtCycletime.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCycletime.Location = new System.Drawing.Point(222, 242);
            this.txtCycletime.Margin = new System.Windows.Forms.Padding(4);
            this.txtCycletime.Name = "txtCycletime";
            this.txtCycletime.ReadOnly = true;
            this.txtCycletime.Size = new System.Drawing.Size(164, 21);
            this.txtCycletime.TabIndex = 98;
            this.txtCycletime.Text = "0";
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.Color.White;
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox17.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox17.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(14, 285);
            this.textBox17.Margin = new System.Windows.Forms.Padding(4);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(156, 21);
            this.textBox17.TabIndex = 97;
            this.textBox17.Text = "UPH               ";
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.White;
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox16.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox16.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(14, 242);
            this.textBox16.Margin = new System.Windows.Forms.Padding(4);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(156, 21);
            this.textBox16.TabIndex = 97;
            this.textBox16.Text = "Cycle Time      ";
            // 
            // txtyYeldcnt
            // 
            this.txtyYeldcnt.BackColor = System.Drawing.Color.White;
            this.txtyYeldcnt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtyYeldcnt.Enabled = false;
            this.txtyYeldcnt.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtyYeldcnt.Location = new System.Drawing.Point(222, 169);
            this.txtyYeldcnt.Margin = new System.Windows.Forms.Padding(4);
            this.txtyYeldcnt.Name = "txtyYeldcnt";
            this.txtyYeldcnt.ReadOnly = true;
            this.txtyYeldcnt.Size = new System.Drawing.Size(164, 21);
            this.txtyYeldcnt.TabIndex = 96;
            this.txtyYeldcnt.Text = "0";
            // 
            // txtOverallcnt
            // 
            this.txtOverallcnt.BackColor = System.Drawing.Color.White;
            this.txtOverallcnt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOverallcnt.Enabled = false;
            this.txtOverallcnt.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOverallcnt.Location = new System.Drawing.Point(222, 206);
            this.txtOverallcnt.Margin = new System.Windows.Forms.Padding(4);
            this.txtOverallcnt.Name = "txtOverallcnt";
            this.txtOverallcnt.ReadOnly = true;
            this.txtOverallcnt.Size = new System.Drawing.Size(164, 21);
            this.txtOverallcnt.TabIndex = 95;
            this.txtOverallcnt.Text = "0";
            // 
            // txtFailcnt
            // 
            this.txtFailcnt.BackColor = System.Drawing.Color.White;
            this.txtFailcnt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFailcnt.Enabled = false;
            this.txtFailcnt.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFailcnt.Location = new System.Drawing.Point(222, 131);
            this.txtFailcnt.Margin = new System.Windows.Forms.Padding(4);
            this.txtFailcnt.Name = "txtFailcnt";
            this.txtFailcnt.ReadOnly = true;
            this.txtFailcnt.Size = new System.Drawing.Size(164, 21);
            this.txtFailcnt.TabIndex = 94;
            this.txtFailcnt.Text = "0";
            // 
            // txtPasscnt
            // 
            this.txtPasscnt.BackColor = System.Drawing.Color.White;
            this.txtPasscnt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPasscnt.Enabled = false;
            this.txtPasscnt.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPasscnt.Location = new System.Drawing.Point(222, 95);
            this.txtPasscnt.Margin = new System.Windows.Forms.Padding(4);
            this.txtPasscnt.Name = "txtPasscnt";
            this.txtPasscnt.ReadOnly = true;
            this.txtPasscnt.Size = new System.Drawing.Size(164, 21);
            this.txtPasscnt.TabIndex = 36;
            this.txtPasscnt.Text = "0";
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.White;
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox13.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox13.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(14, 169);
            this.textBox13.Margin = new System.Windows.Forms.Padding(4);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(156, 21);
            this.textBox13.TabIndex = 35;
            this.textBox13.Text = "Yield              ";
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.Color.White;
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox12.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox12.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(14, 206);
            this.textBox12.Margin = new System.Windows.Forms.Padding(4);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(156, 21);
            this.textBox12.TabIndex = 35;
            this.textBox12.Text = "Overall Count  ";
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.White;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox11.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(14, 131);
            this.textBox11.Margin = new System.Windows.Forms.Padding(4);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(156, 21);
            this.textBox11.TabIndex = 35;
            this.textBox11.Text = "Fail Count       ";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.White;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox8.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(14, 95);
            this.textBox8.Margin = new System.Windows.Forms.Padding(4);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(156, 21);
            this.textBox8.TabIndex = 35;
            this.textBox8.Text = "Pass Count     ";
            // 
            // pnlMachineHealth
            // 
            this.pnlMachineHealth.BackColor = System.Drawing.Color.White;
            this.pnlMachineHealth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMachineHealth.Controls.Add(this.button3);
            this.pnlMachineHealth.Controls.Add(this.label2);
            this.pnlMachineHealth.Controls.Add(this.linkLabel2);
            this.pnlMachineHealth.Controls.Add(this.lblShift);
            this.pnlMachineHealth.Controls.Add(this.label3);
            this.pnlMachineHealth.Controls.Add(this.button12);
            this.pnlMachineHealth.Controls.Add(this.button13);
            this.pnlMachineHealth.Controls.Add(this.button14);
            this.pnlMachineHealth.Controls.Add(this.label14);
            this.pnlMachineHealth.Controls.Add(this.label17);
            this.pnlMachineHealth.Controls.Add(this.label20);
            this.pnlMachineHealth.Controls.Add(this.label21);
            this.pnlMachineHealth.Controls.Add(this.lblTotaltime);
            this.pnlMachineHealth.Controls.Add(this.lblIdletime);
            this.pnlMachineHealth.Controls.Add(this.lblDowntime);
            this.pnlMachineHealth.Controls.Add(this.lblRunTime);
            this.pnlMachineHealth.Controls.Add(this.label26);
            this.pnlMachineHealth.Controls.Add(this.label27);
            this.pnlMachineHealth.Controls.Add(this.label28);
            this.pnlMachineHealth.Controls.Add(this.label29);
            this.pnlMachineHealth.Location = new System.Drawing.Point(9, 16);
            this.pnlMachineHealth.Margin = new System.Windows.Forms.Padding(4);
            this.pnlMachineHealth.Name = "pnlMachineHealth";
            this.pnlMachineHealth.Size = new System.Drawing.Size(376, 323);
            this.pnlMachineHealth.TabIndex = 95;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Blue;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(16, 286);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(28, 28);
            this.button3.TabIndex = 89;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 7);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(247, 28);
            this.label2.TabIndex = 93;
            this.label2.Text = "MACHINE HEALTH";
            // 
            // linkLabel2
            // 
            this.linkLabel2.Location = new System.Drawing.Point(0, 0);
            this.linkLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(132, 28);
            this.linkLabel2.TabIndex = 0;
            // 
            // lblShift
            // 
            this.lblShift.AutoSize = true;
            this.lblShift.BackColor = System.Drawing.Color.Transparent;
            this.lblShift.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShift.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblShift.Location = new System.Drawing.Point(140, 63);
            this.lblShift.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShift.Name = "lblShift";
            this.lblShift.Size = new System.Drawing.Size(22, 20);
            this.lblShift.TabIndex = 90;
            this.lblShift.Text = "A";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label3.Location = new System.Drawing.Point(13, 63);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 20);
            this.label3.TabIndex = 89;
            this.label3.Text = "Current Shift";
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Yellow;
            this.button12.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(16, 228);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(28, 28);
            this.button12.TabIndex = 88;
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Red;
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(16, 168);
            this.button13.Margin = new System.Windows.Forms.Padding(4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(28, 28);
            this.button13.TabIndex = 86;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button14.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(16, 108);
            this.button14.Margin = new System.Windows.Forms.Padding(4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(28, 28);
            this.button14.TabIndex = 85;
            this.button14.UseVisualStyleBackColor = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(271, 290);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 20);
            this.label14.TabIndex = 42;
            this.label14.Text = "Hr";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(271, 232);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(31, 20);
            this.label17.TabIndex = 41;
            this.label17.Text = "Hr";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(271, 172);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 20);
            this.label20.TabIndex = 39;
            this.label20.Text = "Hr";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(271, 112);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(31, 20);
            this.label21.TabIndex = 38;
            this.label21.Text = "Hr";
            // 
            // lblTotaltime
            // 
            this.lblTotaltime.BackColor = System.Drawing.Color.Transparent;
            this.lblTotaltime.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotaltime.Location = new System.Drawing.Point(211, 289);
            this.lblTotaltime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotaltime.Name = "lblTotaltime";
            this.lblTotaltime.Size = new System.Drawing.Size(53, 22);
            this.lblTotaltime.TabIndex = 37;
            this.lblTotaltime.Text = "0";
            // 
            // lblIdletime
            // 
            this.lblIdletime.BackColor = System.Drawing.Color.Transparent;
            this.lblIdletime.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdletime.Location = new System.Drawing.Point(211, 231);
            this.lblIdletime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIdletime.Name = "lblIdletime";
            this.lblIdletime.Size = new System.Drawing.Size(53, 22);
            this.lblIdletime.TabIndex = 36;
            this.lblIdletime.Text = "0";
            // 
            // lblDowntime
            // 
            this.lblDowntime.BackColor = System.Drawing.Color.Transparent;
            this.lblDowntime.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDowntime.Location = new System.Drawing.Point(211, 171);
            this.lblDowntime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDowntime.Name = "lblDowntime";
            this.lblDowntime.Size = new System.Drawing.Size(53, 22);
            this.lblDowntime.TabIndex = 34;
            this.lblDowntime.Text = "0";
            // 
            // lblRunTime
            // 
            this.lblRunTime.BackColor = System.Drawing.Color.Transparent;
            this.lblRunTime.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRunTime.Location = new System.Drawing.Point(211, 111);
            this.lblRunTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRunTime.Name = "lblRunTime";
            this.lblRunTime.Size = new System.Drawing.Size(53, 22);
            this.lblRunTime.TabIndex = 33;
            this.lblRunTime.Text = "0";
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(51, 288);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(148, 25);
            this.label26.TabIndex = 32;
            this.label26.Text = "Total Time   :";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(51, 232);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(138, 20);
            this.label27.TabIndex = 31;
            this.label27.Text = "Idle Time    :";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(51, 171);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(140, 22);
            this.label28.TabIndex = 29;
            this.label28.Text = "Down Time  :";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(51, 110);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(137, 25);
            this.label29.TabIndex = 28;
            this.label29.Text = "Run Time    :";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Homing
            // 
            this.Homing.BackColor = System.Drawing.Color.Yellow;
            this.Homing.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Homing.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Homing.Location = new System.Drawing.Point(985, 659);
            this.Homing.Margin = new System.Windows.Forms.Padding(4);
            this.Homing.Name = "Homing";
            this.Homing.Size = new System.Drawing.Size(220, 53);
            this.Homing.TabIndex = 94;
            this.Homing.Text = "System Reset / Homing";
            this.Homing.UseVisualStyleBackColor = false;
            this.Homing.Click += new System.EventHandler(this.Homing_Click);
            // 
            // tabLog
            // 
            this.tabLog.Controls.Add(this.tabPage1);
            this.tabLog.Controls.Add(this.tabPage2);
            this.tabLog.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabLog.Location = new System.Drawing.Point(9, 347);
            this.tabLog.Margin = new System.Windows.Forms.Padding(4);
            this.tabLog.Name = "tabLog";
            this.tabLog.SelectedIndex = 0;
            this.tabLog.Size = new System.Drawing.Size(779, 374);
            this.tabLog.TabIndex = 46;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lstRunningLog);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(771, 343);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Running Log";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lstRunningLog
            // 
            this.lstRunningLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstRunningLog.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstRunningLog.FormattingEnabled = true;
            this.lstRunningLog.ItemHeight = 18;
            this.lstRunningLog.Location = new System.Drawing.Point(4, 4);
            this.lstRunningLog.Margin = new System.Windows.Forms.Padding(4);
            this.lstRunningLog.Name = "lstRunningLog";
            this.lstRunningLog.Size = new System.Drawing.Size(763, 335);
            this.lstRunningLog.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgvAlarmlive);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(771, 347);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Alarm";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgvAlarmlive
            // 
            this.dgvAlarmlive.AllowUserToAddRows = false;
            this.dgvAlarmlive.BackgroundColor = System.Drawing.Color.Red;
            this.dgvAlarmlive.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAlarmlive.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAlarmlive.Location = new System.Drawing.Point(4, 4);
            this.dgvAlarmlive.Margin = new System.Windows.Forms.Padding(4);
            this.dgvAlarmlive.Name = "dgvAlarmlive";
            this.dgvAlarmlive.ReadOnly = true;
            this.dgvAlarmlive.RowHeadersWidth = 51;
            this.dgvAlarmlive.Size = new System.Drawing.Size(763, 339);
            this.dgvAlarmlive.TabIndex = 51;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 34);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1357, 725);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "MACHINE DETAILS";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // HomeScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1365, 763);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Name = "HomeScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "HomeScreen";
            this.Load += new System.EventHandler(this.HomeScreen_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.conectionStatusGrid)).EndInit();
            this.pnlMachineStatus.ResumeLayout(false);
            this.pnlMachineStatus.PerformLayout();
            this.pnlMachineHealth.ResumeLayout(false);
            this.pnlMachineHealth.PerformLayout();
            this.tabLog.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlarmlive)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Timer timer1;
        private TabControl tabControl1;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private Button Homing;
        private TabControl tabLog;
        private TabPage tabPage1;
        private ListBox lstRunningLog;
        private TabPage tabPage2;
        private DataGridView dgvAlarmlive;
        private Panel pnlMachineHealth;
        private Button button3;
        private Label label2;
        private LinkLabel linkLabel2;
        private Label lblShift;
        private Label label3;
        private Button button12;
        private Button button13;
        private Button button14;
        private Label label14;
        private Label label17;
        private Label label20;
        private Label label21;
        private Label lblTotaltime;
        private Label lblIdletime;
        private Label lblDowntime;
        private Label lblRunTime;
        private Label label26;
        private Label label27;
        private Label label28;
        private Label label29;
        private Panel pnlMachineStatus;
        private TextBox textBox23;
        private TextBox txtMachineMode;
        private TextBox textBox25;
        private TextBox textBox7;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private Label label4;
        private TextBox txtUph;
        private TextBox txtCycletime;
        private TextBox textBox17;
        private TextBox textBox16;
        private TextBox txtyYeldcnt;
        private TextBox txtOverallcnt;
        private TextBox txtFailcnt;
        private TextBox txtPasscnt;
        private TextBox textBox13;
        private TextBox textBox12;
        private TextBox textBox11;
        private TextBox textBox8;
        private Panel panel1;
        private DataGridView conectionStatusGrid;
        private Label label1;
    }
}