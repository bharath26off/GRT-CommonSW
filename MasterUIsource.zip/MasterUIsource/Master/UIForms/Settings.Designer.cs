﻿using System.Drawing;
using System.Windows.Forms;

namespace UI
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
     

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Settings));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Calibration = new System.Windows.Forms.TabPage();
            this.CaliberationPanel = new System.Windows.Forms.Panel();
            this.tabCalib = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.grpCameraCalib = new System.Windows.Forms.GroupBox();
            this.grpboxCamera = new System.Windows.Forms.GroupBox();
            this.chkCCD5 = new System.Windows.Forms.CheckBox();
            this.chkCCD1 = new System.Windows.Forms.CheckBox();
            this.btnCamera_Stop = new System.Windows.Forms.Button();
            this.btnCamera_Start = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.AE_LIMITS = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.CPK_Save = new System.Windows.Forms.Button();
            this.CPK_Edit = new System.Windows.Forms.Button();
            this.CPK_dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.GRR_dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Table_Vision_Settings = new System.Windows.Forms.DataGridView();
            this.MotorDebug = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnedit = new System.Windows.Forms.Button();
            this.grbMotor = new System.Windows.Forms.GroupBox();
            this.Axis_Settings = new System.Windows.Forms.DataGridView();
            this.IODiagnostics = new System.Windows.Forms.TabPage();
            this.tabIO = new System.Windows.Forms.TabControl();
            this.btn_input = new System.Windows.Forms.TabPage();
            this.txtSearchForOutput = new System.Windows.Forms.TextBox();
            this.txtSearchForInput = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.DGV_Output1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGV_Input1 = new System.Windows.Forms.DataGridView();
            this.InOnOff = new System.Windows.Forms.DataGridViewImageColumn();
            this.InputName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dgvAI = new System.Windows.Forms.DataGridView();
            this.Device = new System.Windows.Forms.TabPage();
            this.DeviceSettingsPanel = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.SFC_PDCA_Bypass = new System.Windows.Forms.CheckBox();
            this.Buzzer_Bypass = new System.Windows.Forms.CheckBox();
            this.Safety_door_bypass = new System.Windows.Forms.CheckBox();
            this.Barcode_scanner_bypass = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tabConnectionDetails = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.IP_Details_table = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.Serial_Comm_table = new System.Windows.Forms.DataGridView();
            this.btnEditSettings = new System.Windows.Forms.Button();
            this.btnSaveSettings = new System.Windows.Forms.Button();
            this.grpSystemSettings = new System.Windows.Forms.GroupBox();
            this.radioButtonDynamic = new System.Windows.Forms.RadioButton();
            this.radioButtonStatic = new System.Windows.Forms.RadioButton();
            this.radioButtongrr = new System.Windows.Forms.RadioButton();
            this.radioButtoncpk = new System.Windows.Forms.RadioButton();
            this.radioButtondry = new System.Windows.Forms.RadioButton();
            this.radioButtonProd = new System.Windows.Forms.RadioButton();
            this.General = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pnlShiftSettings = new System.Windows.Forms.Panel();
            this.grpShiftSettings = new System.Windows.Forms.GroupBox();
            this.cmbShift = new System.Windows.Forms.ComboBox();
            this.lblShift = new System.Windows.Forms.Label();
            this.lblEndTime = new System.Windows.Forms.Label();
            this.dtpEndTime = new System.Windows.Forms.DateTimePicker();
            this.lblStartTime = new System.Windows.Forms.Label();
            this.dtpStartTime = new System.Windows.Forms.DateTimePicker();
            this.btnEditGeneral = new System.Windows.Forms.Button();
            this.btnSaveGeneral = new System.Windows.Forms.Button();
            this.pnlGeneral = new System.Windows.Forms.Panel();
            this.pnlSupport = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.pnlInfo = new System.Windows.Forms.Panel();
            this.lblTotalRejectVal = new System.Windows.Forms.Label();
            this.lblTotalLifeCycleVal = new System.Windows.Forms.Label();
            this.lblSWRevVal = new System.Windows.Forms.Label();
            this.lbSWUpdateVal = new System.Windows.Forms.Label();
            this.lblBuildDateVal = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblSwUpdated = new System.Windows.Forms.Label();
            this.lblBuildDate = new System.Windows.Forms.Label();
            this.lblSWRev = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lblLifecycle = new System.Windows.Forms.Label();
            this.lblRejection = new System.Windows.Forms.Label();
            this.tabControlSettings = new System.Windows.Forms.TabControl();
            this.Add = new System.Windows.Forms.ToolStripMenuItem();
            this.Delete = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.dataGridViewImageColumn2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btn_Cali_Rob_Connect = new System.Windows.Forms.Button();
            this.btn_Cali_Rob_Trigger = new System.Windows.Forms.Button();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.RecieveDataRobo = new System.Windows.Forms.RichTextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.Robo_textBox = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.cmbRoboTrigger = new System.Windows.Forms.ComboBox();
            this.Calibration.SuspendLayout();
            this.CaliberationPanel.SuspendLayout();
            this.tabCalib.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.grpCameraCalib.SuspendLayout();
            this.grpboxCamera.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AE_LIMITS)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CPK_dataGridView2)).BeginInit();
            this.tabPage12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GRR_dataGridView3)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Table_Vision_Settings)).BeginInit();
            this.MotorDebug.SuspendLayout();
            this.panel2.SuspendLayout();
            this.grbMotor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Axis_Settings)).BeginInit();
            this.IODiagnostics.SuspendLayout();
            this.tabIO.SuspendLayout();
            this.btn_input.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Output1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Input1)).BeginInit();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAI)).BeginInit();
            this.Device.SuspendLayout();
            this.DeviceSettingsPanel.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabConnectionDetails.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.IP_Details_table)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Serial_Comm_table)).BeginInit();
            this.grpSystemSettings.SuspendLayout();
            this.General.SuspendLayout();
            this.panel5.SuspendLayout();
            this.pnlShiftSettings.SuspendLayout();
            this.grpShiftSettings.SuspendLayout();
            this.pnlGeneral.SuspendLayout();
            this.pnlSupport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnlInfo.SuspendLayout();
            this.tabControlSettings.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Calibration
            // 
            this.Calibration.Controls.Add(this.CaliberationPanel);
            this.Calibration.Location = new System.Drawing.Point(4, 45);
            this.Calibration.Margin = new System.Windows.Forms.Padding(4);
            this.Calibration.Name = "Calibration";
            this.Calibration.Size = new System.Drawing.Size(1357, 714);
            this.Calibration.TabIndex = 7;
            this.Calibration.Text = "Calibration";
            this.Calibration.UseVisualStyleBackColor = true;
            // 
            // CaliberationPanel
            // 
            this.CaliberationPanel.Controls.Add(this.tabCalib);
            this.CaliberationPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CaliberationPanel.Location = new System.Drawing.Point(0, 0);
            this.CaliberationPanel.Margin = new System.Windows.Forms.Padding(4);
            this.CaliberationPanel.Name = "CaliberationPanel";
            this.CaliberationPanel.Size = new System.Drawing.Size(1357, 714);
            this.CaliberationPanel.TabIndex = 0;
            // 
            // tabCalib
            // 
            this.tabCalib.Controls.Add(this.tabPage2);
            this.tabCalib.Controls.Add(this.tabPage4);
            this.tabCalib.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCalib.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabCalib.Location = new System.Drawing.Point(0, 0);
            this.tabCalib.Margin = new System.Windows.Forms.Padding(4);
            this.tabCalib.Multiline = true;
            this.tabCalib.Name = "tabCalib";
            this.tabCalib.SelectedIndex = 0;
            this.tabCalib.Size = new System.Drawing.Size(1357, 714);
            this.tabCalib.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.grpCameraCalib);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1349, 683);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Camera";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // grpCameraCalib
            // 
            this.grpCameraCalib.BackColor = System.Drawing.Color.WhiteSmoke;
            this.grpCameraCalib.Controls.Add(this.grpboxCamera);
            this.grpCameraCalib.Controls.Add(this.btnCamera_Stop);
            this.grpCameraCalib.Controls.Add(this.btnCamera_Start);
            this.grpCameraCalib.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.grpCameraCalib.Location = new System.Drawing.Point(24, 30);
            this.grpCameraCalib.Margin = new System.Windows.Forms.Padding(4);
            this.grpCameraCalib.Name = "grpCameraCalib";
            this.grpCameraCalib.Padding = new System.Windows.Forms.Padding(4);
            this.grpCameraCalib.Size = new System.Drawing.Size(484, 315);
            this.grpCameraCalib.TabIndex = 185;
            this.grpCameraCalib.TabStop = false;
            this.grpCameraCalib.Text = "CCD Calibration";
            // 
            // grpboxCamera
            // 
            this.grpboxCamera.BackColor = System.Drawing.Color.WhiteSmoke;
            this.grpboxCamera.Controls.Add(this.chkCCD5);
            this.grpboxCamera.Controls.Add(this.chkCCD1);
            this.grpboxCamera.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpboxCamera.Location = new System.Drawing.Point(12, 72);
            this.grpboxCamera.Margin = new System.Windows.Forms.Padding(4);
            this.grpboxCamera.Name = "grpboxCamera";
            this.grpboxCamera.Padding = new System.Windows.Forms.Padding(4);
            this.grpboxCamera.Size = new System.Drawing.Size(411, 107);
            this.grpboxCamera.TabIndex = 152;
            this.grpboxCamera.TabStop = false;
            this.grpboxCamera.Text = "Choose Camera";
            // 
            // chkCCD5
            // 
            this.chkCCD5.AutoSize = true;
            this.chkCCD5.Location = new System.Drawing.Point(268, 47);
            this.chkCCD5.Margin = new System.Windows.Forms.Padding(4);
            this.chkCCD5.Name = "chkCCD5";
            this.chkCCD5.Size = new System.Drawing.Size(85, 24);
            this.chkCCD5.TabIndex = 90;
            this.chkCCD5.Text = "CCD 4";
            this.chkCCD5.UseVisualStyleBackColor = true;
            // 
            // chkCCD1
            // 
            this.chkCCD1.AutoSize = true;
            this.chkCCD1.Location = new System.Drawing.Point(66, 47);
            this.chkCCD1.Margin = new System.Windows.Forms.Padding(4);
            this.chkCCD1.Name = "chkCCD1";
            this.chkCCD1.Size = new System.Drawing.Size(131, 24);
            this.chkCCD1.TabIndex = 87;
            this.chkCCD1.Text = "CCD 1, 2 & 3";
            this.chkCCD1.UseVisualStyleBackColor = true;
            // 
            // btnCamera_Stop
            // 
            this.btnCamera_Stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnCamera_Stop.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCamera_Stop.ForeColor = System.Drawing.Color.White;
            this.btnCamera_Stop.Location = new System.Drawing.Point(259, 224);
            this.btnCamera_Stop.Margin = new System.Windows.Forms.Padding(4);
            this.btnCamera_Stop.Name = "btnCamera_Stop";
            this.btnCamera_Stop.Size = new System.Drawing.Size(132, 43);
            this.btnCamera_Stop.TabIndex = 100;
            this.btnCamera_Stop.Text = "Stop";
            this.btnCamera_Stop.UseVisualStyleBackColor = false;
            // 
            // btnCamera_Start
            // 
            this.btnCamera_Start.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnCamera_Start.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCamera_Start.ForeColor = System.Drawing.Color.White;
            this.btnCamera_Start.Location = new System.Drawing.Point(26, 224);
            this.btnCamera_Start.Margin = new System.Windows.Forms.Padding(4);
            this.btnCamera_Start.Name = "btnCamera_Start";
            this.btnCamera_Start.Size = new System.Drawing.Size(132, 43);
            this.btnCamera_Start.TabIndex = 100;
            this.btnCamera_Start.Text = "Start";
            this.btnCamera_Start.UseVisualStyleBackColor = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox7);
            this.tabPage4.Location = new System.Drawing.Point(4, 27);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1349, 683);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Robot";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl5);
            this.tabPage1.Location = new System.Drawing.Point(4, 45);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1357, 714);
            this.tabPage1.TabIndex = 9;
            this.tabPage1.Text = "SFC & PDCA Settings";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage23);
            this.tabControl5.Controls.Add(this.tabPage8);
            this.tabControl5.Controls.Add(this.tabPage12);
            this.tabControl5.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl5.Location = new System.Drawing.Point(-4, 1);
            this.tabControl5.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(1357, 713);
            this.tabControl5.TabIndex = 161;
            // 
            // tabPage23
            // 
            this.tabPage23.BackColor = System.Drawing.Color.White;
            this.tabPage23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage23.Controls.Add(this.button23);
            this.tabPage23.Controls.Add(this.button24);
            this.tabPage23.Controls.Add(this.AE_LIMITS);
            this.tabPage23.Location = new System.Drawing.Point(4, 29);
            this.tabPage23.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage23.Size = new System.Drawing.Size(1349, 680);
            this.tabPage23.TabIndex = 1;
            this.tabPage23.Text = "AE Limits (Production)";
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button23.Enabled = false;
            this.button23.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.ForeColor = System.Drawing.Color.White;
            this.button23.Location = new System.Drawing.Point(736, 618);
            this.button23.Margin = new System.Windows.Forms.Padding(4);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(132, 43);
            this.button23.TabIndex = 161;
            this.button23.Text = "Save";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button24.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.ForeColor = System.Drawing.Color.White;
            this.button24.Location = new System.Drawing.Point(596, 618);
            this.button24.Margin = new System.Windows.Forms.Padding(4);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(132, 43);
            this.button24.TabIndex = 160;
            this.button24.Text = "Edit";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // AE_LIMITS
            // 
            this.AE_LIMITS.AllowUserToAddRows = false;
            this.AE_LIMITS.AllowUserToDeleteRows = false;
            this.AE_LIMITS.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.AE_LIMITS.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AE_LIMITS.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle31;
            this.AE_LIMITS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AE_LIMITS.DefaultCellStyle = dataGridViewCellStyle32;
            this.AE_LIMITS.EnableHeadersVisualStyles = false;
            this.AE_LIMITS.GridColor = System.Drawing.Color.Black;
            this.AE_LIMITS.Location = new System.Drawing.Point(3, 3);
            this.AE_LIMITS.Margin = new System.Windows.Forms.Padding(4);
            this.AE_LIMITS.Name = "AE_LIMITS";
            this.AE_LIMITS.RowHeadersVisible = false;
            this.AE_LIMITS.RowHeadersWidth = 51;
            this.AE_LIMITS.Size = new System.Drawing.Size(1336, 607);
            this.AE_LIMITS.TabIndex = 155;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.CPK_Save);
            this.tabPage8.Controls.Add(this.CPK_Edit);
            this.tabPage8.Controls.Add(this.CPK_dataGridView2);
            this.tabPage8.Location = new System.Drawing.Point(4, 29);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(1349, 680);
            this.tabPage8.TabIndex = 2;
            this.tabPage8.Text = "AE Limits (CPK)";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // CPK_Save
            // 
            this.CPK_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.CPK_Save.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CPK_Save.ForeColor = System.Drawing.Color.White;
            this.CPK_Save.Location = new System.Drawing.Point(729, 619);
            this.CPK_Save.Margin = new System.Windows.Forms.Padding(4);
            this.CPK_Save.Name = "CPK_Save";
            this.CPK_Save.Size = new System.Drawing.Size(132, 43);
            this.CPK_Save.TabIndex = 164;
            this.CPK_Save.Text = "Save";
            this.CPK_Save.UseVisualStyleBackColor = false;
            this.CPK_Save.Click += new System.EventHandler(this.CPK_Save_Click);
            // 
            // CPK_Edit
            // 
            this.CPK_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.CPK_Edit.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CPK_Edit.ForeColor = System.Drawing.Color.White;
            this.CPK_Edit.Location = new System.Drawing.Point(589, 619);
            this.CPK_Edit.Margin = new System.Windows.Forms.Padding(4);
            this.CPK_Edit.Name = "CPK_Edit";
            this.CPK_Edit.Size = new System.Drawing.Size(132, 43);
            this.CPK_Edit.TabIndex = 163;
            this.CPK_Edit.Text = "Edit";
            this.CPK_Edit.UseVisualStyleBackColor = false;
            // 
            // CPK_dataGridView2
            // 
            this.CPK_dataGridView2.AllowUserToAddRows = false;
            this.CPK_dataGridView2.AllowUserToDeleteRows = false;
            this.CPK_dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CPK_dataGridView2.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.CPK_dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle33;
            this.CPK_dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CPK_dataGridView2.DefaultCellStyle = dataGridViewCellStyle34;
            this.CPK_dataGridView2.EnableHeadersVisualStyles = false;
            this.CPK_dataGridView2.GridColor = System.Drawing.Color.Black;
            this.CPK_dataGridView2.Location = new System.Drawing.Point(4, 4);
            this.CPK_dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.CPK_dataGridView2.Name = "CPK_dataGridView2";
            this.CPK_dataGridView2.RowHeadersVisible = false;
            this.CPK_dataGridView2.RowHeadersWidth = 51;
            this.CPK_dataGridView2.Size = new System.Drawing.Size(1341, 607);
            this.CPK_dataGridView2.TabIndex = 162;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.button31);
            this.tabPage12.Controls.Add(this.button32);
            this.tabPage12.Controls.Add(this.GRR_dataGridView3);
            this.tabPage12.Location = new System.Drawing.Point(4, 29);
            this.tabPage12.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Size = new System.Drawing.Size(1349, 680);
            this.tabPage12.TabIndex = 3;
            this.tabPage12.Text = "AE Limits (GRR)";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button31.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.ForeColor = System.Drawing.Color.White;
            this.button31.Location = new System.Drawing.Point(721, 619);
            this.button31.Margin = new System.Windows.Forms.Padding(4);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(132, 43);
            this.button31.TabIndex = 164;
            this.button31.Text = "Save";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button32.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.ForeColor = System.Drawing.Color.White;
            this.button32.Location = new System.Drawing.Point(581, 619);
            this.button32.Margin = new System.Windows.Forms.Padding(4);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(132, 43);
            this.button32.TabIndex = 163;
            this.button32.Text = "Edit";
            this.button32.UseVisualStyleBackColor = false;
            // 
            // GRR_dataGridView3
            // 
            this.GRR_dataGridView3.AllowUserToAddRows = false;
            this.GRR_dataGridView3.AllowUserToDeleteRows = false;
            this.GRR_dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GRR_dataGridView3.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GRR_dataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle35;
            this.GRR_dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.GRR_dataGridView3.DefaultCellStyle = dataGridViewCellStyle36;
            this.GRR_dataGridView3.EnableHeadersVisualStyles = false;
            this.GRR_dataGridView3.GridColor = System.Drawing.Color.Black;
            this.GRR_dataGridView3.Location = new System.Drawing.Point(4, 4);
            this.GRR_dataGridView3.Margin = new System.Windows.Forms.Padding(4);
            this.GRR_dataGridView3.Name = "GRR_dataGridView3";
            this.GRR_dataGridView3.RowHeadersVisible = false;
            this.GRR_dataGridView3.RowHeadersWidth = 51;
            this.GRR_dataGridView3.Size = new System.Drawing.Size(1341, 607);
            this.GRR_dataGridView3.TabIndex = 162;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.Table_Vision_Settings);
            this.tabPage3.Location = new System.Drawing.Point(4, 45);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1357, 714);
            this.tabPage3.TabIndex = 10;
            this.tabPage3.Text = "Vision Settings";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button1.Enabled = false;
            this.button1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(660, 646);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(132, 43);
            this.button1.TabIndex = 163;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(520, 646);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(132, 43);
            this.button2.TabIndex = 162;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Table_Vision_Settings
            // 
            this.Table_Vision_Settings.AllowUserToAddRows = false;
            this.Table_Vision_Settings.AllowUserToDeleteRows = false;
            this.Table_Vision_Settings.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Table_Vision_Settings.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Table_Vision_Settings.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.Table_Vision_Settings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle38.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Table_Vision_Settings.DefaultCellStyle = dataGridViewCellStyle38;
            this.Table_Vision_Settings.EnableHeadersVisualStyles = false;
            this.Table_Vision_Settings.GridColor = System.Drawing.Color.Black;
            this.Table_Vision_Settings.Location = new System.Drawing.Point(10, 22);
            this.Table_Vision_Settings.Margin = new System.Windows.Forms.Padding(4);
            this.Table_Vision_Settings.Name = "Table_Vision_Settings";
            this.Table_Vision_Settings.RowHeadersVisible = false;
            this.Table_Vision_Settings.RowHeadersWidth = 51;
            this.Table_Vision_Settings.Size = new System.Drawing.Size(1336, 607);
            this.Table_Vision_Settings.TabIndex = 156;
            this.Table_Vision_Settings.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Table_Vision_Settings_CellMouseClick);
            this.Table_Vision_Settings.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.Table_Vision_Settings_EditingControlShowing);
            // 
            // MotorDebug
            // 
            this.MotorDebug.Controls.Add(this.panel2);
            this.MotorDebug.Location = new System.Drawing.Point(4, 45);
            this.MotorDebug.Margin = new System.Windows.Forms.Padding(4);
            this.MotorDebug.Name = "MotorDebug";
            this.MotorDebug.Size = new System.Drawing.Size(1357, 714);
            this.MotorDebug.TabIndex = 8;
            this.MotorDebug.Text = "Axis Parameter Settings";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnSave);
            this.panel2.Controls.Add(this.btnedit);
            this.panel2.Controls.Add(this.grbMotor);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1357, 714);
            this.panel2.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnSave.Enabled = false;
            this.btnSave.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(718, 652);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(123, 43);
            this.btnSave.TabIndex = 92;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnedit
            // 
            this.btnedit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnedit.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnedit.ForeColor = System.Drawing.Color.White;
            this.btnedit.Location = new System.Drawing.Point(559, 652);
            this.btnedit.Margin = new System.Windows.Forms.Padding(4);
            this.btnedit.Name = "btnedit";
            this.btnedit.Size = new System.Drawing.Size(123, 43);
            this.btnedit.TabIndex = 72;
            this.btnedit.Text = "Edit";
            this.btnedit.UseVisualStyleBackColor = false;
            this.btnedit.Click += new System.EventHandler(this.btnedit_Click);
            // 
            // grbMotor
            // 
            this.grbMotor.Controls.Add(this.Axis_Settings);
            this.grbMotor.Location = new System.Drawing.Point(4, 5);
            this.grbMotor.Margin = new System.Windows.Forms.Padding(4);
            this.grbMotor.Name = "grbMotor";
            this.grbMotor.Padding = new System.Windows.Forms.Padding(4);
            this.grbMotor.Size = new System.Drawing.Size(1340, 641);
            this.grbMotor.TabIndex = 91;
            this.grbMotor.TabStop = false;
            // 
            // Axis_Settings
            // 
            this.Axis_Settings.AllowUserToAddRows = false;
            this.Axis_Settings.AllowUserToDeleteRows = false;
            this.Axis_Settings.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Axis_Settings.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.Axis_Settings.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle39.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Axis_Settings.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.Axis_Settings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle40.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle40.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Axis_Settings.DefaultCellStyle = dataGridViewCellStyle40;
            this.Axis_Settings.EnableHeadersVisualStyles = false;
            this.Axis_Settings.Location = new System.Drawing.Point(0, 31);
            this.Axis_Settings.Margin = new System.Windows.Forms.Padding(4);
            this.Axis_Settings.MultiSelect = false;
            this.Axis_Settings.Name = "Axis_Settings";
            this.Axis_Settings.RowHeadersVisible = false;
            this.Axis_Settings.RowHeadersWidth = 51;
            this.Axis_Settings.Size = new System.Drawing.Size(1337, 608);
            this.Axis_Settings.TabIndex = 90;
            this.Axis_Settings.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Axis_Settings_CellMouseClick);
            this.Axis_Settings.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.Axis_Settings_EditingControlShowing);
            // 
            // IODiagnostics
            // 
            this.IODiagnostics.Controls.Add(this.tabIO);
            this.IODiagnostics.Location = new System.Drawing.Point(4, 45);
            this.IODiagnostics.Margin = new System.Windows.Forms.Padding(4);
            this.IODiagnostics.Name = "IODiagnostics";
            this.IODiagnostics.Size = new System.Drawing.Size(1357, 714);
            this.IODiagnostics.TabIndex = 4;
            this.IODiagnostics.Text = "I/O Diagnostics";
            this.IODiagnostics.UseVisualStyleBackColor = true;
            // 
            // tabIO
            // 
            this.tabIO.Controls.Add(this.btn_input);
            this.tabIO.Controls.Add(this.tabPage10);
            this.tabIO.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabIO.Font = new System.Drawing.Font("Verdana", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabIO.Location = new System.Drawing.Point(0, 0);
            this.tabIO.Margin = new System.Windows.Forms.Padding(4);
            this.tabIO.Name = "tabIO";
            this.tabIO.SelectedIndex = 0;
            this.tabIO.Size = new System.Drawing.Size(1357, 711);
            this.tabIO.TabIndex = 5;
            // 
            // btn_input
            // 
            this.btn_input.BackColor = System.Drawing.Color.White;
            this.btn_input.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btn_input.Controls.Add(this.txtSearchForOutput);
            this.btn_input.Controls.Add(this.txtSearchForInput);
            this.btn_input.Controls.Add(this.label30);
            this.btn_input.Controls.Add(this.label29);
            this.btn_input.Controls.Add(this.DGV_Output1);
            this.btn_input.Controls.Add(this.DGV_Input1);
            this.btn_input.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_input.Location = new System.Drawing.Point(4, 27);
            this.btn_input.Margin = new System.Windows.Forms.Padding(4);
            this.btn_input.Name = "btn_input";
            this.btn_input.Size = new System.Drawing.Size(1349, 680);
            this.btn_input.TabIndex = 7;
            this.btn_input.Text = "Digital I/O";
            // 
            // txtSearchForOutput
            // 
            this.txtSearchForOutput.Location = new System.Drawing.Point(927, 20);
            this.txtSearchForOutput.Name = "txtSearchForOutput";
            this.txtSearchForOutput.Size = new System.Drawing.Size(332, 27);
            this.txtSearchForOutput.TabIndex = 10;
            this.txtSearchForOutput.TextChanged += new System.EventHandler(this.txtSearchForOutput_TextChanged);
            // 
            // txtSearchForInput
            // 
            this.txtSearchForInput.Location = new System.Drawing.Point(190, 17);
            this.txtSearchForInput.Name = "txtSearchForInput";
            this.txtSearchForInput.Size = new System.Drawing.Size(332, 27);
            this.txtSearchForInput.TabIndex = 3;
            this.txtSearchForInput.TextChanged += new System.EventHandler(this.txtSearchForInput_TextChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(776, 20);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(145, 20);
            this.label30.TabIndex = 9;
            this.label30.Text = "Search Output";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(52, 20);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(132, 20);
            this.label29.TabIndex = 8;
            this.label29.Text = "Search Input";
            // 
            // DGV_Output1
            // 
            this.DGV_Output1.AllowUserToAddRows = false;
            this.DGV_Output1.AllowUserToDeleteRows = false;
            this.DGV_Output1.AllowUserToResizeColumns = false;
            this.DGV_Output1.AllowUserToResizeRows = false;
            this.DGV_Output1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Output1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewImageColumn1,
            this.dataGridViewTextBoxColumn1});
            this.DGV_Output1.Location = new System.Drawing.Point(682, 58);
            this.DGV_Output1.Name = "DGV_Output1";
            this.DGV_Output1.RowHeadersVisible = false;
            this.DGV_Output1.RowHeadersWidth = 51;
            this.DGV_Output1.RowTemplate.Height = 24;
            this.DGV_Output1.Size = new System.Drawing.Size(652, 611);
            this.DGV_Output1.TabIndex = 5;
            this.DGV_Output1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DGV_Output1_CellMouseClick);
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dataGridViewImageColumn1.HeaderText = "On/Off";
            this.dataGridViewImageColumn1.MinimumWidth = 6;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            this.dataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewImageColumn1.Width = 80;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.HeaderText = "Output Name";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // DGV_Input1
            // 
            this.DGV_Input1.AllowUserToAddRows = false;
            this.DGV_Input1.AllowUserToDeleteRows = false;
            this.DGV_Input1.AllowUserToResizeColumns = false;
            this.DGV_Input1.AllowUserToResizeRows = false;
            this.DGV_Input1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Input1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.InOnOff,
            this.InputName});
            this.DGV_Input1.Location = new System.Drawing.Point(14, 58);
            this.DGV_Input1.Name = "DGV_Input1";
            this.DGV_Input1.RowHeadersVisible = false;
            this.DGV_Input1.RowHeadersWidth = 51;
            this.DGV_Input1.RowTemplate.Height = 24;
            this.DGV_Input1.Size = new System.Drawing.Size(652, 611);
            this.DGV_Input1.TabIndex = 4;
            // 
            // InOnOff
            // 
            this.InOnOff.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.InOnOff.HeaderText = "On/Off";
            this.InOnOff.Image = ((System.Drawing.Image)(resources.GetObject("InOnOff.Image")));
            this.InOnOff.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.InOnOff.MinimumWidth = 6;
            this.InOnOff.Name = "InOnOff";
            this.InOnOff.ReadOnly = true;
            this.InOnOff.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.InOnOff.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.InOnOff.Width = 80;
            // 
            // InputName
            // 
            this.InputName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.InputName.HeaderText = "Input Name";
            this.InputName.MinimumWidth = 6;
            this.InputName.Name = "InputName";
            this.InputName.ReadOnly = true;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.label3);
            this.tabPage10.Controls.Add(this.label4);
            this.tabPage10.Controls.Add(this.dataGridView2);
            this.tabPage10.Controls.Add(this.dgvAI);
            this.tabPage10.Location = new System.Drawing.Point(4, 27);
            this.tabPage10.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(1349, 680);
            this.tabPage10.TabIndex = 5;
            this.tabPage10.Text = "Analog I/O";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(947, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "Analog_Output";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(233, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "Analog_Input";
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.Location = new System.Drawing.Point(742, 36);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(570, 632);
            this.dataGridView2.TabIndex = 5;
            this.dataGridView2.Visible = false;
            // 
            // dgvAI
            // 
            this.dgvAI.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Verdana", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle41.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAI.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle41;
            this.dgvAI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAI.EnableHeadersVisualStyles = false;
            this.dgvAI.Location = new System.Drawing.Point(36, 36);
            this.dgvAI.Name = "dgvAI";
            this.dgvAI.RowHeadersVisible = false;
            this.dgvAI.RowHeadersWidth = 51;
            this.dgvAI.RowTemplate.Height = 24;
            this.dgvAI.Size = new System.Drawing.Size(570, 632);
            this.dgvAI.TabIndex = 4;
            // 
            // Device
            // 
            this.Device.Controls.Add(this.DeviceSettingsPanel);
            this.Device.Location = new System.Drawing.Point(4, 45);
            this.Device.Margin = new System.Windows.Forms.Padding(4);
            this.Device.Name = "Device";
            this.Device.Size = new System.Drawing.Size(1357, 714);
            this.Device.TabIndex = 3;
            this.Device.Text = "Device Settings";
            this.Device.UseVisualStyleBackColor = true;
            // 
            // DeviceSettingsPanel
            // 
            this.DeviceSettingsPanel.Controls.Add(this.groupBox1);
            this.DeviceSettingsPanel.Controls.Add(this.panel4);
            this.DeviceSettingsPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DeviceSettingsPanel.Location = new System.Drawing.Point(0, 0);
            this.DeviceSettingsPanel.Margin = new System.Windows.Forms.Padding(4);
            this.DeviceSettingsPanel.Name = "DeviceSettingsPanel";
            this.DeviceSettingsPanel.Size = new System.Drawing.Size(1357, 714);
            this.DeviceSettingsPanel.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.SFC_PDCA_Bypass);
            this.groupBox1.Controls.Add(this.Buzzer_Bypass);
            this.groupBox1.Controls.Add(this.Safety_door_bypass);
            this.groupBox1.Controls.Add(this.Barcode_scanner_bypass);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(963, 98);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(292, 336);
            this.groupBox1.TabIndex = 103;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bypass Settings";
            // 
            // SFC_PDCA_Bypass
            // 
            this.SFC_PDCA_Bypass.Appearance = System.Windows.Forms.Appearance.Button;
            this.SFC_PDCA_Bypass.AutoSize = true;
            this.SFC_PDCA_Bypass.FlatAppearance.CheckedBackColor = System.Drawing.Color.LimeGreen;
            this.SFC_PDCA_Bypass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SFC_PDCA_Bypass.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SFC_PDCA_Bypass.Location = new System.Drawing.Point(32, 176);
            this.SFC_PDCA_Bypass.Margin = new System.Windows.Forms.Padding(4);
            this.SFC_PDCA_Bypass.Name = "SFC_PDCA_Bypass";
            this.SFC_PDCA_Bypass.Size = new System.Drawing.Size(185, 32);
            this.SFC_PDCA_Bypass.TabIndex = 26;
            this.SFC_PDCA_Bypass.Text = "SFC_PDCA Bypass";
            this.SFC_PDCA_Bypass.UseVisualStyleBackColor = true;
            // 
            // Buzzer_Bypass
            // 
            this.Buzzer_Bypass.Appearance = System.Windows.Forms.Appearance.Button;
            this.Buzzer_Bypass.AutoSize = true;
            this.Buzzer_Bypass.FlatAppearance.CheckedBackColor = System.Drawing.Color.LimeGreen;
            this.Buzzer_Bypass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Buzzer_Bypass.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Buzzer_Bypass.Location = new System.Drawing.Point(32, 134);
            this.Buzzer_Bypass.Margin = new System.Windows.Forms.Padding(4);
            this.Buzzer_Bypass.Name = "Buzzer_Bypass";
            this.Buzzer_Bypass.Size = new System.Drawing.Size(149, 32);
            this.Buzzer_Bypass.TabIndex = 25;
            this.Buzzer_Bypass.Text = "Buzzer Bypass";
            this.Buzzer_Bypass.UseVisualStyleBackColor = true;
            // 
            // Safety_door_bypass
            // 
            this.Safety_door_bypass.Appearance = System.Windows.Forms.Appearance.Button;
            this.Safety_door_bypass.AutoSize = true;
            this.Safety_door_bypass.BackColor = System.Drawing.Color.Transparent;
            this.Safety_door_bypass.FlatAppearance.CheckedBackColor = System.Drawing.Color.LimeGreen;
            this.Safety_door_bypass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Safety_door_bypass.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Safety_door_bypass.Location = new System.Drawing.Point(32, 50);
            this.Safety_door_bypass.Margin = new System.Windows.Forms.Padding(4);
            this.Safety_door_bypass.Name = "Safety_door_bypass";
            this.Safety_door_bypass.Size = new System.Drawing.Size(197, 32);
            this.Safety_door_bypass.TabIndex = 24;
            this.Safety_door_bypass.Text = "Safety Door Bypass";
            this.Safety_door_bypass.UseVisualStyleBackColor = false;
            // 
            // Barcode_scanner_bypass
            // 
            this.Barcode_scanner_bypass.Appearance = System.Windows.Forms.Appearance.Button;
            this.Barcode_scanner_bypass.AutoSize = true;
            this.Barcode_scanner_bypass.FlatAppearance.CheckedBackColor = System.Drawing.Color.LimeGreen;
            this.Barcode_scanner_bypass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Barcode_scanner_bypass.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Barcode_scanner_bypass.Location = new System.Drawing.Point(32, 92);
            this.Barcode_scanner_bypass.Margin = new System.Windows.Forms.Padding(4);
            this.Barcode_scanner_bypass.Name = "Barcode_scanner_bypass";
            this.Barcode_scanner_bypass.Size = new System.Drawing.Size(162, 32);
            this.Barcode_scanner_bypass.TabIndex = 23;
            this.Barcode_scanner_bypass.Text = "Scanner Bypass";
            this.Barcode_scanner_bypass.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.tabConnectionDetails);
            this.panel4.Controls.Add(this.btnEditSettings);
            this.panel4.Controls.Add(this.btnSaveSettings);
            this.panel4.Controls.Add(this.grpSystemSettings);
            this.panel4.Location = new System.Drawing.Point(4, 4);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1344, 703);
            this.panel4.TabIndex = 105;
            // 
            // tabConnectionDetails
            // 
            this.tabConnectionDetails.Controls.Add(this.tabPage5);
            this.tabConnectionDetails.Controls.Add(this.tabPage6);
            this.tabConnectionDetails.Location = new System.Drawing.Point(48, 94);
            this.tabConnectionDetails.Name = "tabConnectionDetails";
            this.tabConnectionDetails.SelectedIndex = 0;
            this.tabConnectionDetails.Size = new System.Drawing.Size(556, 345);
            this.tabConnectionDetails.TabIndex = 107;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.IP_Details_table);
            this.tabPage5.Location = new System.Drawing.Point(4, 31);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(548, 310);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "TCP IP";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // IP_Details_table
            // 
            this.IP_Details_table.AllowUserToAddRows = false;
            this.IP_Details_table.AllowUserToDeleteRows = false;
            this.IP_Details_table.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.IP_Details_table.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.IP_Details_table.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle42.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.IP_Details_table.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.IP_Details_table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle43.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.IP_Details_table.DefaultCellStyle = dataGridViewCellStyle43;
            this.IP_Details_table.EnableHeadersVisualStyles = false;
            this.IP_Details_table.Location = new System.Drawing.Point(7, 10);
            this.IP_Details_table.Margin = new System.Windows.Forms.Padding(4);
            this.IP_Details_table.MultiSelect = false;
            this.IP_Details_table.Name = "IP_Details_table";
            this.IP_Details_table.RowHeadersVisible = false;
            this.IP_Details_table.RowHeadersWidth = 51;
            this.IP_Details_table.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.IP_Details_table.Size = new System.Drawing.Size(534, 295);
            this.IP_Details_table.TabIndex = 92;
            this.IP_Details_table.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.IP_Details_table_EditingControlShowing);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.Serial_Comm_table);
            this.tabPage6.Location = new System.Drawing.Point(4, 31);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(548, 310);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Serial Comm";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // Serial_Comm_table
            // 
            this.Serial_Comm_table.AllowUserToAddRows = false;
            this.Serial_Comm_table.AllowUserToDeleteRows = false;
            this.Serial_Comm_table.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Serial_Comm_table.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.Serial_Comm_table.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle44.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle44.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Serial_Comm_table.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle44;
            this.Serial_Comm_table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle45.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle45.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle45.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle45.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle45.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Serial_Comm_table.DefaultCellStyle = dataGridViewCellStyle45;
            this.Serial_Comm_table.EnableHeadersVisualStyles = false;
            this.Serial_Comm_table.Location = new System.Drawing.Point(7, 8);
            this.Serial_Comm_table.Margin = new System.Windows.Forms.Padding(4);
            this.Serial_Comm_table.MultiSelect = false;
            this.Serial_Comm_table.Name = "Serial_Comm_table";
            this.Serial_Comm_table.RowHeadersVisible = false;
            this.Serial_Comm_table.RowHeadersWidth = 51;
            this.Serial_Comm_table.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Serial_Comm_table.Size = new System.Drawing.Size(534, 295);
            this.Serial_Comm_table.TabIndex = 93;
            this.Serial_Comm_table.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.Serial_Comm_table_CellMouseClick);
            this.Serial_Comm_table.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.Serial_Comm_table_EditingControlShowing);
            // 
            // btnEditSettings
            // 
            this.btnEditSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnEditSettings.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditSettings.ForeColor = System.Drawing.Color.White;
            this.btnEditSettings.Location = new System.Drawing.Point(521, 510);
            this.btnEditSettings.Margin = new System.Windows.Forms.Padding(4);
            this.btnEditSettings.Name = "btnEditSettings";
            this.btnEditSettings.Size = new System.Drawing.Size(147, 43);
            this.btnEditSettings.TabIndex = 105;
            this.btnEditSettings.Text = "Edit";
            this.btnEditSettings.UseVisualStyleBackColor = false;
            this.btnEditSettings.Click += new System.EventHandler(this.btnEditSettings_Click);
            // 
            // btnSaveSettings
            // 
            this.btnSaveSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnSaveSettings.Enabled = false;
            this.btnSaveSettings.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveSettings.ForeColor = System.Drawing.Color.White;
            this.btnSaveSettings.Location = new System.Drawing.Point(722, 510);
            this.btnSaveSettings.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveSettings.Name = "btnSaveSettings";
            this.btnSaveSettings.Size = new System.Drawing.Size(147, 43);
            this.btnSaveSettings.TabIndex = 106;
            this.btnSaveSettings.Text = "Save";
            this.btnSaveSettings.UseVisualStyleBackColor = false;
            this.btnSaveSettings.Click += new System.EventHandler(this.btnSaveSettings_Click);
            // 
            // grpSystemSettings
            // 
            this.grpSystemSettings.BackColor = System.Drawing.Color.White;
            this.grpSystemSettings.Controls.Add(this.radioButtonDynamic);
            this.grpSystemSettings.Controls.Add(this.radioButtonStatic);
            this.grpSystemSettings.Controls.Add(this.radioButtongrr);
            this.grpSystemSettings.Controls.Add(this.radioButtoncpk);
            this.grpSystemSettings.Controls.Add(this.radioButtondry);
            this.grpSystemSettings.Controls.Add(this.radioButtonProd);
            this.grpSystemSettings.Enabled = false;
            this.grpSystemSettings.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSystemSettings.Location = new System.Drawing.Point(641, 94);
            this.grpSystemSettings.Margin = new System.Windows.Forms.Padding(4);
            this.grpSystemSettings.Name = "grpSystemSettings";
            this.grpSystemSettings.Padding = new System.Windows.Forms.Padding(4);
            this.grpSystemSettings.Size = new System.Drawing.Size(295, 336);
            this.grpSystemSettings.TabIndex = 102;
            this.grpSystemSettings.TabStop = false;
            this.grpSystemSettings.Text = "System Settings";
            this.grpSystemSettings.Enter += new System.EventHandler(this.grpSystemSettings_Enter);
            // 
            // radioButtonDynamic
            // 
            this.radioButtonDynamic.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButtonDynamic.AutoSize = true;
            this.radioButtonDynamic.FlatAppearance.CheckedBackColor = System.Drawing.Color.LimeGreen;
            this.radioButtonDynamic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radioButtonDynamic.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDynamic.Location = new System.Drawing.Point(49, 269);
            this.radioButtonDynamic.Name = "radioButtonDynamic";
            this.radioButtonDynamic.Size = new System.Drawing.Size(197, 34);
            this.radioButtonDynamic.TabIndex = 37;
            this.radioButtonDynamic.TabStop = true;
            this.radioButtonDynamic.Text = "Dynamic Test Mode";
            this.radioButtonDynamic.UseVisualStyleBackColor = true;
            // 
            // radioButtonStatic
            // 
            this.radioButtonStatic.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButtonStatic.AutoSize = true;
            this.radioButtonStatic.FlatAppearance.CheckedBackColor = System.Drawing.Color.LimeGreen;
            this.radioButtonStatic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radioButtonStatic.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonStatic.Location = new System.Drawing.Point(49, 226);
            this.radioButtonStatic.Name = "radioButtonStatic";
            this.radioButtonStatic.Size = new System.Drawing.Size(169, 34);
            this.radioButtonStatic.TabIndex = 36;
            this.radioButtonStatic.TabStop = true;
            this.radioButtonStatic.Text = "Static Test Mode";
            this.radioButtonStatic.UseVisualStyleBackColor = true;
            // 
            // radioButtongrr
            // 
            this.radioButtongrr.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButtongrr.AutoSize = true;
            this.radioButtongrr.FlatAppearance.CheckedBackColor = System.Drawing.Color.LimeGreen;
            this.radioButtongrr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radioButtongrr.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtongrr.Location = new System.Drawing.Point(49, 183);
            this.radioButtongrr.Name = "radioButtongrr";
            this.radioButtongrr.Size = new System.Drawing.Size(116, 34);
            this.radioButtongrr.TabIndex = 35;
            this.radioButtongrr.TabStop = true;
            this.radioButtongrr.Text = "GRR Mode";
            this.radioButtongrr.UseVisualStyleBackColor = true;
            // 
            // radioButtoncpk
            // 
            this.radioButtoncpk.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButtoncpk.AutoSize = true;
            this.radioButtoncpk.FlatAppearance.CheckedBackColor = System.Drawing.Color.LimeGreen;
            this.radioButtoncpk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radioButtoncpk.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtoncpk.Location = new System.Drawing.Point(49, 140);
            this.radioButtoncpk.Name = "radioButtoncpk";
            this.radioButtoncpk.Size = new System.Drawing.Size(112, 34);
            this.radioButtoncpk.TabIndex = 29;
            this.radioButtoncpk.TabStop = true;
            this.radioButtoncpk.Text = "CPK Mode";
            this.radioButtoncpk.UseVisualStyleBackColor = true;
            // 
            // radioButtondry
            // 
            this.radioButtondry.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButtondry.AutoSize = true;
            this.radioButtondry.FlatAppearance.CheckedBackColor = System.Drawing.Color.LimeGreen;
            this.radioButtondry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radioButtondry.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtondry.Location = new System.Drawing.Point(49, 97);
            this.radioButtondry.Name = "radioButtondry";
            this.radioButtondry.Size = new System.Drawing.Size(96, 34);
            this.radioButtondry.TabIndex = 28;
            this.radioButtondry.TabStop = true;
            this.radioButtondry.Text = "Dry Run";
            this.radioButtondry.UseVisualStyleBackColor = true;
            // 
            // radioButtonProd
            // 
            this.radioButtonProd.Appearance = System.Windows.Forms.Appearance.Button;
            this.radioButtonProd.AutoSize = true;
            this.radioButtonProd.FlatAppearance.CheckedBackColor = System.Drawing.Color.LimeGreen;
            this.radioButtonProd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radioButtonProd.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonProd.Location = new System.Drawing.Point(49, 54);
            this.radioButtonProd.Name = "radioButtonProd";
            this.radioButtonProd.Size = new System.Drawing.Size(158, 34);
            this.radioButtonProd.TabIndex = 27;
            this.radioButtonProd.TabStop = true;
            this.radioButtonProd.Text = "Production Run";
            this.radioButtonProd.UseVisualStyleBackColor = true;
            // 
            // General
            // 
            this.General.Controls.Add(this.panel5);
            this.General.Location = new System.Drawing.Point(4, 45);
            this.General.Margin = new System.Windows.Forms.Padding(4);
            this.General.Name = "General";
            this.General.Size = new System.Drawing.Size(1357, 714);
            this.General.TabIndex = 5;
            this.General.Text = "General";
            this.General.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.pnlShiftSettings);
            this.panel5.Controls.Add(this.pnlGeneral);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1357, 714);
            this.panel5.TabIndex = 0;
            // 
            // pnlShiftSettings
            // 
            this.pnlShiftSettings.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlShiftSettings.Controls.Add(this.grpShiftSettings);
            this.pnlShiftSettings.Location = new System.Drawing.Point(631, 4);
            this.pnlShiftSettings.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pnlShiftSettings.Name = "pnlShiftSettings";
            this.pnlShiftSettings.Size = new System.Drawing.Size(613, 335);
            this.pnlShiftSettings.TabIndex = 64;
            // 
            // grpShiftSettings
            // 
            this.grpShiftSettings.BackColor = System.Drawing.Color.White;
            this.grpShiftSettings.Controls.Add(this.cmbShift);
            this.grpShiftSettings.Controls.Add(this.lblShift);
            this.grpShiftSettings.Controls.Add(this.lblEndTime);
            this.grpShiftSettings.Controls.Add(this.dtpEndTime);
            this.grpShiftSettings.Controls.Add(this.lblStartTime);
            this.grpShiftSettings.Controls.Add(this.dtpStartTime);
            this.grpShiftSettings.Controls.Add(this.btnEditGeneral);
            this.grpShiftSettings.Controls.Add(this.btnSaveGeneral);
            this.grpShiftSettings.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold);
            this.grpShiftSettings.Location = new System.Drawing.Point(13, 22);
            this.grpShiftSettings.Margin = new System.Windows.Forms.Padding(4);
            this.grpShiftSettings.Name = "grpShiftSettings";
            this.grpShiftSettings.Padding = new System.Windows.Forms.Padding(4);
            this.grpShiftSettings.Size = new System.Drawing.Size(591, 305);
            this.grpShiftSettings.TabIndex = 52;
            this.grpShiftSettings.TabStop = false;
            this.grpShiftSettings.Text = "Shift Settings";
            // 
            // cmbShift
            // 
            this.cmbShift.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbShift.Enabled = false;
            this.cmbShift.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbShift.FormattingEnabled = true;
            this.cmbShift.Items.AddRange(new object[] {
            "A",
            "B",
            "C"});
            this.cmbShift.Location = new System.Drawing.Point(169, 70);
            this.cmbShift.Margin = new System.Windows.Forms.Padding(4);
            this.cmbShift.Name = "cmbShift";
            this.cmbShift.Size = new System.Drawing.Size(148, 28);
            this.cmbShift.TabIndex = 56;
            this.cmbShift.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cmbShift_DrawItem);
            // 
            // lblShift
            // 
            this.lblShift.BackColor = System.Drawing.Color.White;
            this.lblShift.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShift.Location = new System.Drawing.Point(11, 71);
            this.lblShift.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShift.Name = "lblShift";
            this.lblShift.Size = new System.Drawing.Size(151, 22);
            this.lblShift.TabIndex = 55;
            this.lblShift.Text = "Shift          :";
            // 
            // lblEndTime
            // 
            this.lblEndTime.BackColor = System.Drawing.Color.White;
            this.lblEndTime.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEndTime.Location = new System.Drawing.Point(11, 172);
            this.lblEndTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEndTime.Name = "lblEndTime";
            this.lblEndTime.Size = new System.Drawing.Size(151, 22);
            this.lblEndTime.TabIndex = 54;
            this.lblEndTime.Text = "End Time   :";
            // 
            // dtpEndTime
            // 
            this.dtpEndTime.Enabled = false;
            this.dtpEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpEndTime.Location = new System.Drawing.Point(169, 172);
            this.dtpEndTime.Margin = new System.Windows.Forms.Padding(4);
            this.dtpEndTime.Name = "dtpEndTime";
            this.dtpEndTime.ShowUpDown = true;
            this.dtpEndTime.Size = new System.Drawing.Size(148, 32);
            this.dtpEndTime.TabIndex = 53;
            // 
            // lblStartTime
            // 
            this.lblStartTime.AutoSize = true;
            this.lblStartTime.BackColor = System.Drawing.Color.White;
            this.lblStartTime.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartTime.Location = new System.Drawing.Point(11, 121);
            this.lblStartTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStartTime.Name = "lblStartTime";
            this.lblStartTime.Size = new System.Drawing.Size(139, 23);
            this.lblStartTime.TabIndex = 52;
            this.lblStartTime.Text = "Start Time :";
            // 
            // dtpStartTime
            // 
            this.dtpStartTime.Enabled = false;
            this.dtpStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpStartTime.Location = new System.Drawing.Point(169, 117);
            this.dtpStartTime.Margin = new System.Windows.Forms.Padding(4);
            this.dtpStartTime.Name = "dtpStartTime";
            this.dtpStartTime.ShowUpDown = true;
            this.dtpStartTime.Size = new System.Drawing.Size(148, 32);
            this.dtpStartTime.TabIndex = 51;
            // 
            // btnEditGeneral
            // 
            this.btnEditGeneral.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnEditGeneral.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditGeneral.ForeColor = System.Drawing.Color.White;
            this.btnEditGeneral.Location = new System.Drawing.Point(182, 245);
            this.btnEditGeneral.Margin = new System.Windows.Forms.Padding(4);
            this.btnEditGeneral.Name = "btnEditGeneral";
            this.btnEditGeneral.Size = new System.Drawing.Size(124, 37);
            this.btnEditGeneral.TabIndex = 50;
            this.btnEditGeneral.Text = "Edit";
            this.btnEditGeneral.UseVisualStyleBackColor = false;
            this.btnEditGeneral.Click += new System.EventHandler(this.btnEditGeneral_Click);
            // 
            // btnSaveGeneral
            // 
            this.btnSaveGeneral.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnSaveGeneral.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveGeneral.ForeColor = System.Drawing.Color.White;
            this.btnSaveGeneral.Location = new System.Drawing.Point(314, 245);
            this.btnSaveGeneral.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveGeneral.Name = "btnSaveGeneral";
            this.btnSaveGeneral.Size = new System.Drawing.Size(124, 37);
            this.btnSaveGeneral.TabIndex = 49;
            this.btnSaveGeneral.Text = "Save";
            this.btnSaveGeneral.UseVisualStyleBackColor = false;
            this.btnSaveGeneral.Click += new System.EventHandler(this.btnSaveGeneral_Click);
            // 
            // pnlGeneral
            // 
            this.pnlGeneral.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlGeneral.Controls.Add(this.pnlSupport);
            this.pnlGeneral.Controls.Add(this.pnlInfo);
            this.pnlGeneral.Location = new System.Drawing.Point(3, 4);
            this.pnlGeneral.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pnlGeneral.Name = "pnlGeneral";
            this.pnlGeneral.Size = new System.Drawing.Size(560, 672);
            this.pnlGeneral.TabIndex = 63;
            // 
            // pnlSupport
            // 
            this.pnlSupport.BackColor = System.Drawing.Color.White;
            this.pnlSupport.Controls.Add(this.pictureBox2);
            this.pnlSupport.Controls.Add(this.label39);
            this.pnlSupport.Controls.Add(this.label11);
            this.pnlSupport.Controls.Add(this.label38);
            this.pnlSupport.Controls.Add(this.label12);
            this.pnlSupport.Controls.Add(this.label13);
            this.pnlSupport.Controls.Add(this.label14);
            this.pnlSupport.Controls.Add(this.label17);
            this.pnlSupport.Location = new System.Drawing.Point(23, 310);
            this.pnlSupport.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pnlSupport.Name = "pnlSupport";
            this.pnlSupport.Size = new System.Drawing.Size(511, 341);
            this.pnlSupport.TabIndex = 56;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 48);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(144, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 46;
            this.pictureBox2.TabStop = false;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(11, 289);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(420, 24);
            this.label39.TabIndex = 43;
            this.label39.Text = "Email: xxxxr@titan.co.in | www.titanteal.com";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 250);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(218, 24);
            this.label11.TabIndex = 43;
            this.label11.Text = "Mobile: +91xxxxxxxxx";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(12, 214);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(151, 24);
            this.label38.TabIndex = 43;
            this.label38.Text = "Hosur - 635126";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(11, 176);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(269, 24);
            this.label12.TabIndex = 42;
            this.label12.Text = "SIPCOT Industrial Complex,";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(11, 135);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(175, 24);
            this.label13.TabIndex = 41;
            this.label13.Text = "Unit - I, NO.27 & 28";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(11, 97);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(402, 24);
            this.label14.TabIndex = 40;
            this.label14.Text = "Titan Engineering and Automation Limited";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 13F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(9, 11);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(144, 27);
            this.label17.TabIndex = 39;
            this.label17.Text = "For Support";
            // 
            // pnlInfo
            // 
            this.pnlInfo.BackColor = System.Drawing.Color.White;
            this.pnlInfo.Controls.Add(this.lblTotalRejectVal);
            this.pnlInfo.Controls.Add(this.lblTotalLifeCycleVal);
            this.pnlInfo.Controls.Add(this.lblSWRevVal);
            this.pnlInfo.Controls.Add(this.lbSWUpdateVal);
            this.pnlInfo.Controls.Add(this.lblBuildDateVal);
            this.pnlInfo.Controls.Add(this.label10);
            this.pnlInfo.Controls.Add(this.label9);
            this.pnlInfo.Controls.Add(this.label8);
            this.pnlInfo.Controls.Add(this.label7);
            this.pnlInfo.Controls.Add(this.label6);
            this.pnlInfo.Controls.Add(this.lblSwUpdated);
            this.pnlInfo.Controls.Add(this.lblBuildDate);
            this.pnlInfo.Controls.Add(this.lblSWRev);
            this.pnlInfo.Controls.Add(this.label22);
            this.pnlInfo.Controls.Add(this.lblLifecycle);
            this.pnlInfo.Controls.Add(this.lblRejection);
            this.pnlInfo.Location = new System.Drawing.Point(23, 22);
            this.pnlInfo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(511, 267);
            this.pnlInfo.TabIndex = 55;
            // 
            // lblTotalRejectVal
            // 
            this.lblTotalRejectVal.AutoSize = true;
            this.lblTotalRejectVal.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalRejectVal.Location = new System.Drawing.Point(224, 209);
            this.lblTotalRejectVal.Name = "lblTotalRejectVal";
            this.lblTotalRejectVal.Size = new System.Drawing.Size(0, 22);
            this.lblTotalRejectVal.TabIndex = 47;
            // 
            // lblTotalLifeCycleVal
            // 
            this.lblTotalLifeCycleVal.AutoSize = true;
            this.lblTotalLifeCycleVal.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalLifeCycleVal.Location = new System.Drawing.Point(224, 172);
            this.lblTotalLifeCycleVal.Name = "lblTotalLifeCycleVal";
            this.lblTotalLifeCycleVal.Size = new System.Drawing.Size(0, 22);
            this.lblTotalLifeCycleVal.TabIndex = 46;
            // 
            // lblSWRevVal
            // 
            this.lblSWRevVal.AutoSize = true;
            this.lblSWRevVal.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSWRevVal.Location = new System.Drawing.Point(224, 92);
            this.lblSWRevVal.Name = "lblSWRevVal";
            this.lblSWRevVal.Size = new System.Drawing.Size(0, 22);
            this.lblSWRevVal.TabIndex = 45;
            // 
            // lbSWUpdateVal
            // 
            this.lbSWUpdateVal.AutoSize = true;
            this.lbSWUpdateVal.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSWUpdateVal.Location = new System.Drawing.Point(224, 130);
            this.lbSWUpdateVal.Name = "lbSWUpdateVal";
            this.lbSWUpdateVal.Size = new System.Drawing.Size(0, 22);
            this.lbSWUpdateVal.TabIndex = 44;
            // 
            // lblBuildDateVal
            // 
            this.lblBuildDateVal.AutoSize = true;
            this.lblBuildDateVal.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBuildDateVal.Location = new System.Drawing.Point(224, 58);
            this.lblBuildDateVal.Name = "lblBuildDateVal";
            this.lblBuildDateVal.Size = new System.Drawing.Size(0, 22);
            this.lblBuildDateVal.TabIndex = 43;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(201, 209);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 22);
            this.label10.TabIndex = 42;
            this.label10.Text = ":";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(201, 172);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 22);
            this.label9.TabIndex = 41;
            this.label9.Text = ":";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(201, 130);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 22);
            this.label8.TabIndex = 40;
            this.label8.Text = ":";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(201, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 22);
            this.label7.TabIndex = 39;
            this.label7.Text = ":";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(201, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 22);
            this.label6.TabIndex = 38;
            this.label6.Text = ":";
            // 
            // lblSwUpdated
            // 
            this.lblSwUpdated.AutoSize = true;
            this.lblSwUpdated.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSwUpdated.Location = new System.Drawing.Point(9, 130);
            this.lblSwUpdated.Name = "lblSwUpdated";
            this.lblSwUpdated.Size = new System.Drawing.Size(108, 22);
            this.lblSwUpdated.TabIndex = 33;
            this.lblSwUpdated.Text = "SW Updated";
            // 
            // lblBuildDate
            // 
            this.lblBuildDate.AutoSize = true;
            this.lblBuildDate.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBuildDate.Location = new System.Drawing.Point(9, 58);
            this.lblBuildDate.Name = "lblBuildDate";
            this.lblBuildDate.Size = new System.Drawing.Size(91, 22);
            this.lblBuildDate.TabIndex = 28;
            this.lblBuildDate.Text = "Build Date";
            // 
            // lblSWRev
            // 
            this.lblSWRev.AutoSize = true;
            this.lblSWRev.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSWRev.Location = new System.Drawing.Point(9, 92);
            this.lblSWRev.Name = "lblSWRev";
            this.lblSWRev.Size = new System.Drawing.Size(71, 22);
            this.lblSWRev.TabIndex = 29;
            this.lblSWRev.Text = "SW Rev";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 13F, System.Drawing.FontStyle.Bold);
            this.label22.Location = new System.Drawing.Point(11, 18);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(162, 26);
            this.label22.TabIndex = 32;
            this.label22.Text = "Information";
            // 
            // lblLifecycle
            // 
            this.lblLifecycle.AutoSize = true;
            this.lblLifecycle.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLifecycle.Location = new System.Drawing.Point(9, 172);
            this.lblLifecycle.Name = "lblLifecycle";
            this.lblLifecycle.Size = new System.Drawing.Size(145, 22);
            this.lblLifecycle.TabIndex = 35;
            this.lblLifecycle.Text = "Total Life Cycles ";
            // 
            // lblRejection
            // 
            this.lblRejection.AutoSize = true;
            this.lblRejection.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRejection.Location = new System.Drawing.Point(9, 209);
            this.lblRejection.Name = "lblRejection";
            this.lblRejection.Size = new System.Drawing.Size(146, 22);
            this.lblRejection.TabIndex = 37;
            this.lblRejection.Text = "Total Life Rejects";
            // 
            // tabControlSettings
            // 
            this.tabControlSettings.Controls.Add(this.General);
            this.tabControlSettings.Controls.Add(this.Device);
            this.tabControlSettings.Controls.Add(this.IODiagnostics);
            this.tabControlSettings.Controls.Add(this.MotorDebug);
            this.tabControlSettings.Controls.Add(this.tabPage3);
            this.tabControlSettings.Controls.Add(this.tabPage1);
            this.tabControlSettings.Controls.Add(this.Calibration);
            this.tabControlSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControlSettings.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControlSettings.Location = new System.Drawing.Point(0, 0);
            this.tabControlSettings.Margin = new System.Windows.Forms.Padding(4);
            this.tabControlSettings.Name = "tabControlSettings";
            this.tabControlSettings.Padding = new System.Drawing.Point(15, 10);
            this.tabControlSettings.SelectedIndex = 0;
            this.tabControlSettings.Size = new System.Drawing.Size(1365, 763);
            this.tabControlSettings.TabIndex = 47;
            // 
            // Add
            // 
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(122, 24);
            this.Add.Text = "Add";
            this.Add.Click += new System.EventHandler(this.Add_Click_1);
            // 
            // Delete
            // 
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(122, 24);
            this.Delete.Text = "Delete";
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Add,
            this.Delete});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(123, 52);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // dataGridViewImageColumn2
            // 
            this.dataGridViewImageColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewImageColumn2.HeaderText = "On/Off";
            this.dataGridViewImageColumn2.Image = ((System.Drawing.Image)(resources.GetObject("dataGridViewImageColumn2.Image")));
            this.dataGridViewImageColumn2.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.dataGridViewImageColumn2.MinimumWidth = 6;
            this.dataGridViewImageColumn2.Name = "dataGridViewImageColumn2";
            this.dataGridViewImageColumn2.ReadOnly = true;
            this.dataGridViewImageColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewImageColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewImageColumn2.Width = 80;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox7.Controls.Add(this.btn_Cali_Rob_Connect);
            this.groupBox7.Controls.Add(this.btn_Cali_Rob_Trigger);
            this.groupBox7.Controls.Add(this.label44);
            this.groupBox7.Controls.Add(this.label45);
            this.groupBox7.Controls.Add(this.label46);
            this.groupBox7.Controls.Add(this.RecieveDataRobo);
            this.groupBox7.Controls.Add(this.label47);
            this.groupBox7.Controls.Add(this.Robo_textBox);
            this.groupBox7.Controls.Add(this.label48);
            this.groupBox7.Controls.Add(this.cmbRoboTrigger);
            this.groupBox7.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold);
            this.groupBox7.Location = new System.Drawing.Point(14, 16);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(460, 401);
            this.groupBox7.TabIndex = 183;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Robot";
            // 
            // btn_Cali_Rob_Connect
            // 
            this.btn_Cali_Rob_Connect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btn_Cali_Rob_Connect.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cali_Rob_Connect.ForeColor = System.Drawing.Color.White;
            this.btn_Cali_Rob_Connect.Location = new System.Drawing.Point(67, 293);
            this.btn_Cali_Rob_Connect.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Cali_Rob_Connect.Name = "btn_Cali_Rob_Connect";
            this.btn_Cali_Rob_Connect.Size = new System.Drawing.Size(132, 43);
            this.btn_Cali_Rob_Connect.TabIndex = 100;
            this.btn_Cali_Rob_Connect.Text = "Connect";
            this.btn_Cali_Rob_Connect.UseVisualStyleBackColor = false;
            // 
            // btn_Cali_Rob_Trigger
            // 
            this.btn_Cali_Rob_Trigger.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btn_Cali_Rob_Trigger.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cali_Rob_Trigger.ForeColor = System.Drawing.Color.White;
            this.btn_Cali_Rob_Trigger.Location = new System.Drawing.Point(254, 293);
            this.btn_Cali_Rob_Trigger.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Cali_Rob_Trigger.Name = "btn_Cali_Rob_Trigger";
            this.btn_Cali_Rob_Trigger.Size = new System.Drawing.Size(132, 43);
            this.btn_Cali_Rob_Trigger.TabIndex = 100;
            this.btn_Cali_Rob_Trigger.Text = "Trigger";
            this.btn_Cali_Rob_Trigger.UseVisualStyleBackColor = false;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.Color.Maroon;
            this.label44.Location = new System.Drawing.Point(146, 32);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(28, 25);
            this.label44.TabIndex = 152;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(8, 33);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(145, 18);
            this.label45.TabIndex = 152;
            this.label45.Text = "Robot Conn Status";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label46.Location = new System.Drawing.Point(43, 150);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(116, 18);
            this.label46.TabIndex = 155;
            this.label46.Text = "Received Data";
            // 
            // RecieveDataRobo
            // 
            this.RecieveDataRobo.AccessibleName = "";
            this.RecieveDataRobo.BackColor = System.Drawing.Color.White;
            this.RecieveDataRobo.Enabled = false;
            this.RecieveDataRobo.Location = new System.Drawing.Point(40, 173);
            this.RecieveDataRobo.Margin = new System.Windows.Forms.Padding(4);
            this.RecieveDataRobo.Name = "RecieveDataRobo";
            this.RecieveDataRobo.ReadOnly = true;
            this.RecieveDataRobo.Size = new System.Drawing.Size(376, 82);
            this.RecieveDataRobo.TabIndex = 154;
            this.RecieveDataRobo.Text = "";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(111, 363);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(150, 18);
            this.label47.TabIndex = 151;
            this.label47.Text = "Trigger Delay Time";
            this.label47.Visible = false;
            // 
            // Robo_textBox
            // 
            this.Robo_textBox.BackColor = System.Drawing.Color.White;
            this.Robo_textBox.Enabled = false;
            this.Robo_textBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Robo_textBox.Location = new System.Drawing.Point(268, 357);
            this.Robo_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.Robo_textBox.Name = "Robo_textBox";
            this.Robo_textBox.ReadOnly = true;
            this.Robo_textBox.Size = new System.Drawing.Size(87, 30);
            this.Robo_textBox.TabIndex = 150;
            this.Robo_textBox.Visible = false;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(37, 105);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(188, 18);
            this.label48.TabIndex = 147;
            this.label48.Text = "Select Trigger command";
            // 
            // cmbRoboTrigger
            // 
            this.cmbRoboTrigger.BackColor = System.Drawing.Color.White;
            this.cmbRoboTrigger.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRoboTrigger.Font = new System.Drawing.Font("Verdana", 11.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRoboTrigger.FormattingEnabled = true;
            this.cmbRoboTrigger.Items.AddRange(new object[] {
            "Command_1",
            "Command_2",
            "Command_3"});
            this.cmbRoboTrigger.Location = new System.Drawing.Point(197, 96);
            this.cmbRoboTrigger.Margin = new System.Windows.Forms.Padding(4);
            this.cmbRoboTrigger.Name = "cmbRoboTrigger";
            this.cmbRoboTrigger.Size = new System.Drawing.Size(219, 33);
            this.cmbRoboTrigger.TabIndex = 86;
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1365, 763);
            this.Controls.Add(this.tabControlSettings);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.Settings_Load);
            this.Calibration.ResumeLayout(false);
            this.CaliberationPanel.ResumeLayout(false);
            this.tabCalib.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.grpCameraCalib.ResumeLayout(false);
            this.grpboxCamera.ResumeLayout(false);
            this.grpboxCamera.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage23.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AE_LIMITS)).EndInit();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CPK_dataGridView2)).EndInit();
            this.tabPage12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GRR_dataGridView3)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Table_Vision_Settings)).EndInit();
            this.MotorDebug.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.grbMotor.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Axis_Settings)).EndInit();
            this.IODiagnostics.ResumeLayout(false);
            this.tabIO.ResumeLayout(false);
            this.btn_input.ResumeLayout(false);
            this.btn_input.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Output1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Input1)).EndInit();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAI)).EndInit();
            this.Device.ResumeLayout(false);
            this.DeviceSettingsPanel.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.tabConnectionDetails.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.IP_Details_table)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Serial_Comm_table)).EndInit();
            this.grpSystemSettings.ResumeLayout(false);
            this.grpSystemSettings.PerformLayout();
            this.General.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.pnlShiftSettings.ResumeLayout(false);
            this.grpShiftSettings.ResumeLayout(false);
            this.grpShiftSettings.PerformLayout();
            this.pnlGeneral.ResumeLayout(false);
            this.pnlSupport.ResumeLayout(false);
            this.pnlSupport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnlInfo.ResumeLayout(false);
            this.pnlInfo.PerformLayout();
            this.tabControlSettings.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Timer timer1;
        private TabPage Calibration;
        private Panel CaliberationPanel;
        private TabControl tabCalib;
        private TabPage tabPage2;
        private GroupBox grpCameraCalib;
        private GroupBox grpboxCamera;
        private CheckBox chkCCD5;
        private CheckBox chkCCD1;
        private Button btnCamera_Stop;
        private Button btnCamera_Start;
        private TabPage tabPage4;
        private TabPage tabPage1;
        private TabControl tabControl5;
        private TabPage tabPage23;
        private Button button23;
        private Button button24;
        private DataGridView AE_LIMITS;
        private TabPage tabPage8;
        private Button CPK_Save;
        private Button CPK_Edit;
        private DataGridView CPK_dataGridView2;
        private TabPage tabPage12;
        private Button button31;
        private Button button32;
        private DataGridView GRR_dataGridView3;
        private TabPage tabPage3;
        private Button button1;
        private Button button2;
        private DataGridView Table_Vision_Settings;
        private TabPage MotorDebug;
        private Panel panel2;
        private Button btnSave;
        private Button btnedit;
        private GroupBox grbMotor;
        private TabPage IODiagnostics;
        private TabPage Device;
        private Panel DeviceSettingsPanel;
        private GroupBox groupBox1;
        private CheckBox SFC_PDCA_Bypass;
        private CheckBox Buzzer_Bypass;
        private CheckBox Safety_door_bypass;
        private CheckBox Barcode_scanner_bypass;
        private Panel panel4;
        private GroupBox grpSystemSettings;
        private TabPage General;
        private Panel panel5;
        private Panel pnlShiftSettings;
        private GroupBox grpShiftSettings;
        private ComboBox cmbShift;
        private Label lblShift;
        private Label lblEndTime;
        private DateTimePicker dtpEndTime;
        private Label lblStartTime;
        private DateTimePicker dtpStartTime;
        private Button btnEditGeneral;
        private Button btnSaveGeneral;
        private Panel pnlGeneral;
        private Panel pnlSupport;
        private PictureBox pictureBox2;
        private Label label39;
        private Label label11;
        private Label label38;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label17;
        private Panel pnlInfo;
        private Label lblTotalRejectVal;
        private Label lblTotalLifeCycleVal;
        private Label lblSWRevVal;
        private Label lbSWUpdateVal;
        private Label lblBuildDateVal;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label lblSwUpdated;
        private Label lblBuildDate;
        private Label lblSWRev;
        private Label label22;
        private Label lblLifecycle;
        private Label lblRejection;
        private TabControl tabControlSettings;
        private RadioButton radioButtonProd;
        private RadioButton radioButtoncpk;
        private RadioButton radioButtondry;
        private RadioButton radioButtongrr;
        private RadioButton radioButtonDynamic;
        private RadioButton radioButtonStatic;
        private DataGridView Axis_Settings;
        private ToolStripMenuItem Add;
        private ToolStripMenuItem Delete;
        private ContextMenuStrip contextMenuStrip1;
        private TabControl tabIO;
        private TabPage btn_input;
        private TextBox txtSearchForOutput;
        private TextBox txtSearchForInput;
        private Label label30;
        private Label label29;
        private DataGridView DGV_Output1;
        private DataGridViewButtonColumn dataGridViewImageColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridView DGV_Input1;
        private DataGridViewImageColumn InOnOff;
        private DataGridViewTextBoxColumn InputName;
        private TabPage tabPage10;
        private Label label3;
        private Label label4;
        private DataGridView dataGridView2;
        private DataGridView dgvAI;
        private Timer timer2;
        private DataGridViewImageColumn dataGridViewImageColumn2;
        private Button btnEditSettings;
        private Button btnSaveSettings;
        private TabControl tabConnectionDetails;
        private TabPage tabPage5;
        private DataGridView IP_Details_table;
        private TabPage tabPage6;
        private DataGridView Serial_Comm_table;
        private GroupBox groupBox7;
        private Button btn_Cali_Rob_Connect;
        private Button btn_Cali_Rob_Trigger;
        private Label label44;
        private Label label45;
        private Label label46;
        public RichTextBox RecieveDataRobo;
        private Label label47;
        public TextBox Robo_textBox;
        private Label label48;
        private ComboBox cmbRoboTrigger;
    }

 
}