﻿using Advantech;
using DIO;
using ExceptionLib;
using HelperClassLib;
using Master;
using Master.AutoSequences;
using Program;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UI.UI_Forms;
using UIForms;
using static DIO.DIDO;

namespace Master
{
    public class IOChecks
    {
        public int IOEInput { get; set; }
        public int IOECode { get; set; }
        public bool ShowPopup { get; set; }
        public bool NCCondition { get; set; }
        public string ErrDes { get; set; }
    }

    public static class SystemMonitor
    {
        public static bool active_sequence = false;
        public static bool autoseq_running = false;
        public static bool autoseq_pause = false;
        //public static bool tower_lamp_thread_lock = false;
        public static int tower_lamp_flickering_time = 5000; //in milli sec
        public static int tower_lamp_flickering_time1 = 3000; //in milli sec
        public static List<IOChecks> IOChecksList = new List<IOChecks>();
        //public static CancellationTokenSource _cts_Sequence;
        //private static List<Func<Task>> _methodsToRun;
        //private static readonly object _lock = new object();
        public static System.Threading.Timer System_Monitor_thread;
        public static bool System_Monitor_thread_lock = false;
        public static ExceptionLib.ErrorManage er1 = new ExceptionLib.ErrorManage();

        public static void System_Monitor_BG_thread()
        {

            System_Monitor_thread_lock = false;
            GlobalVariable.ComObj.ResetAxisError_All_Axis(true);
            GlobalVariable.ComObj.ServoOn_All_Axis(true);
           // GlobalVariable.DIDO.WriteOPS(true, (int)EOutput.M_C_Lmp_On_Sigl);
            //**devchange: uncomment below lines after getting SQL con
            //GlobalVariable.helper = new SqlHelper(GlobalVariable.SQL_ConnStr);

            //**devchange: uncomment below lines after connected to machine
            //Task.Run(() => UpdateMachineStatus());
            Task.Run(() => GetIOChecksList());
            System_Monitor_thread = new System.Threading.Timer(_ =>
            {
                _ = System_Monitor_BG(null);
            }, null, 100, 100);
        }


        public static async Task System_Monitor_BG(object sender)
        {
            if (!System_Monitor_thread_lock)
            {
                System_Monitor_thread_lock = true;

                //check card open if not dont check anything below that
                if (!GlobalVariable.g_CardInitSucc)
                {
                    GlobalVariable.AlarmTrigger(ECode.Motion_Card_not_open, true, 1);
                    System_Monitor_thread_lock = false;
                    return;
                }

                GlobalVariable.DI = GlobalVariable.ComObj.DI_RefreshValue(GlobalVariable.DI.Length, GlobalVariable.InputPortCfg);

                #region START PUSH BUTTON
              //  if (GlobalVariable.DI[(int)DIDO.EInput.Strt_PB])
                {
                    if (!GlobalVariable.bautoseq_running)
                    {
                        MainForm.StartAutoSequence();
                    }
                    else if (GlobalVariable.current_MCStatus == GlobalVariable.MachineStatus.Pause)
                    {
                        //MainForm.StartAutoSequence();
                        GlobalAutoSequenceExecutor.Resume();
                    }
                    else
                    {
                        GlobalAutoSequenceExecutor.Pause();
                    }
                }
                #endregion

                #region STOP PUSH BUTTON   
              //  if (GlobalVariable.DI[(int)DIDO.EInput.Strt_PB])  //**devchange: Stop Pushbutton enum
                {
                    Master.AutoSequences.GlobalAutoSequenceExecutor.Stop();
                    //GlobalVariable.b_gPause = true;
                }
                #endregion

                #region RESET PUSH BUTTON
             //   if (GlobalVariable.DI[(int)DIDO.EInput.Rst_PB]) //**devchange: Reset Pushbutton enum
                {
                    er1.ResetAlarm();
                    GlobalVariable.ResetAllAlarms();
                    GlobalVariable.ComObj.ResetAxisError_All_Axis();
                    GlobalVariable.ComObj.ServoOn_All_Axis(true);
                    GlobalVariable.ComObj.ResetAxisError_All_Axis();
                    //GlobalVariable.b_gPause = false;
                }
                #endregion
                await Tower_Lamp_Handler();

                #region ESTOP PUSH BUTTON
             //   if (GlobalVariable.DI[(int)DIDO.EInput.Emg_Button_1_FB])
                {
                    GlobalVariable.AlarmTrigger(ECode.Emg_Pressed_Error, true, 1);
                }
                #endregion

                System_Monitor_thread_lock = false;
            }
        }


        private static void GetIOChecksList()
        {
            try
            {
                string filePath = "IOChecks.csv";

                string[] csvLines;

                if (File.Exists(filePath))
                {
                    csvLines = File.ReadAllLines(filePath);

                    if (csvLines.Length > 0)
                    {
                        for (int i = 1; i < csvLines.Length; i++)
                        {
                            string[] data = csvLines[i].Split(',');

                            var IOs = new IOChecks
                            {
                                //(int)(DIDO.EInput)Enum.Parse(typeof(DIDO.EInput), GetString("SenseExtendEnumName")),
                                IOEInput = (int)(DIDO.EInput)Enum.Parse(typeof(DIDO.EInput), Convert.ToString(data[0])),
                                IOECode = (int)(DIDO.ECode)Enum.Parse(typeof(DIDO.ECode), Convert.ToString(data[0])),
                                ShowPopup = Convert.ToBoolean(data[2]),
                                NCCondition = Convert.ToBoolean(data[3]),
                                ErrDes = Convert.ToString(data[3])
                            };

                            IOChecksList.Add(IOs);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "SystemMonitor", "GetIOChecksList", ex.Message, ex.StackTrace);
                // throw;
            }
        }

        public static bool AnyActiveAlarms()
        {
            return GlobalVariable.g_lstAlarmInfo.Any(a => a.AlarmHappen);
        }

        public static int Machine_Status()
        {
            //GlobalVariable.ComObj.DI_RefreshValue(GlobalVariable.DI.Length);
            //if (GlobalVariable.DI[(int)DIDO.EInput.Emg_Button_1_FB] || !GlobalVariable.DI[(int)DIDO.EInput.Saf_Rel_FB])
            //{
            //    GlobalVariable.b_gStop = true;
            //    GlobalVariable.ComObj.ServoOFF_All_Axis();
            //    return 1;       //  Red - Buzzer
            //}

            foreach (var check in IOChecksList)
            {
                if (!GlobalVariable.DI[(int)check.IOEInput])
                {
                    GlobalVariable.AlarmTrigger((ECode)(int)check.IOECode, true, Convert.ToInt16(check.ShowPopup));
                    return 1;       //  Red - Buzzer
                }
            }

           // if (GlobalVariable.DI[(int)DIDO.EInput.Rst_PB])
            {
                //GlobalVariable.ComObj.ServoOFF_All_Axis();
                if (GlobalVariable.bautoseq_running)
                {
                    GlobalAutoSequenceExecutor.Resume();
                }
                GlobalVariable.ComObj.ResetAxisError_All_Axis();
                GlobalVariable.ResetAllAlarms();
                return 4;       //  Yellow
            }

            if (GlobalVariable.bhomeseq_running)
                return 5;        // Yellow - Blinking

            if (GlobalVariable.bactive_machine)
                return 4;        // Yellow - steady - Machine ready

            if (GlobalVariable.bautoseq_running)
                return 3;        //  Green

            if (!GlobalVariable.b_gHomingDone)
                return 2;        //  Red




            return -1;
        }

        public static async Task Tower_Lamp_Handler()
        {
            int machine_status = 1;
            //string machine_status = "";
            machine_status = Machine_Status();
            switch (machine_status)
            {
                case 1:  // Red with Buzzer
                    CommonTowerLamp(true, false, false, false);
                    await Task.Delay(tower_lamp_flickering_time);
                   // GlobalVariable.DIDO.WriteOPS(false, (int)EOutput.TL_Bzr);
                    break;
                case 2: // Red
                    CommonTowerLamp(true, false, false, false);
                    break;
                case 3: // Green
                    CommonTowerLamp(false, true, false, false);
                    break;
                case 4: // Yellow
                    CommonTowerLamp(false, false, true, false);
                    break;
                case 5: // Yellow Blinking
                    CommonTowerLamp(false, false, true, false);
                    await Task.Delay(tower_lamp_flickering_time1);
                   // GlobalVariable.DIDO.WriteOPS(false, (int)EOutput.TL_Ye);
                    break;
            }
        }

        private static void CommonTowerLamp(bool red, bool green, bool yellow, bool buzzer)
        {
            try
            {
                //** devchange : change the Enum according to the specific Machine
               // GlobalVariable.DIDO.WriteOPS(red, (int)EOutput.TL_Rd);
               // GlobalVariable.DIDO.WriteOPS(green, (int)EOutput.TL_Gn);
               // GlobalVariable.DIDO.WriteOPS(yellow, (int)EOutput.TL_Ye);
               // GlobalVariable.DIDO.WriteOPS(buzzer, (int)EOutput.TL_Bzr);

            }
            catch (Exception)
            {

                //throw;
            }
        }

        public static async Task UpdateMachineStatus()
        {
            try
            {
                DateTime lastRun = DateTime.Now;
                while (true)
                {
                    DateTime now = DateTime.Now;
                    if ((now - lastRun).TotalMinutes >= 10)
                    {
                        SqlParameter[] param = null;

                        GlobalVariable.sqlHelperConn = new SqlHelper(GlobalVariable.SQL_ConnStr);

                        param = new SqlParameter[]
                            {
                                new SqlParameter("@shift", GlobalVariable.CurrentShift),
                                new SqlParameter("@Date", DateTime.Now.ToString("MM-dd-yyyy")),
                                new SqlParameter("@PassCount", GlobalVariable.dGlobal_Pass_count),
                                new SqlParameter("@FailCount", GlobalVariable.dGlobal_Reject_count),
                                new SqlParameter("@Yield", GlobalVariable.dGlobal_Yield_Count),
                                new SqlParameter("@OverallCount", GlobalVariable.dGlobal_Total_count),
                                new SqlParameter("@CycleTime", GlobalVariable.dGlobal_Cycle_time)
                            };
                        GetDatasets(CommandType.StoredProcedure, "sp_UpdateMachineStatus", param);

                        //GlobalVariable.helper.ExecuteScalar("sp_UpdateMachineStatus", System.Data.CommandType.StoredProcedure, param);


                        lastRun = now;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "SystemMonitor", "UpdateMachineStatus", ex.Message, ex.StackTrace);
                //throw;
            }
        }

        public static DataSet GetDatasets(CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        {
            DataSet objDs = default;
            try
            {

                var db = new SqlConnection(GlobalVariable.SQL_ConnStr);
                var cmd = new SqlCommand();
                cmd.CommandTimeout = 120;
                SqlDataAdapter objAdap;

                PrepareCommands(cmd, db, default, cmdType, cmdText, commandParameters);
                objAdap = new SqlDataAdapter(cmd);
                objDs = new DataSet();
                objDs.Clear();
                objAdap.Fill(objDs);
                return objDs;
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "SystemMonitor", "GetDatasets", ex.Message, ex.StackTrace);
                return objDs;
                // throw ex;
            }

        }

        private static void PrepareCommands(SqlCommand cmd, SqlConnection conn, SqlTransaction trans, CommandType cmdType, string cmdText, SqlParameter[] cmdParms)
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            cmd.Connection = conn;
            cmd.CommandText = cmdText;
            if (trans != null)
            {
                cmd.Transaction = trans;
            }

            cmd.CommandType = cmdType;
            if (cmdParms != null)
            {
                foreach (SqlParameter parm in cmdParms)
                {
                    if (parm != null)
                    {
                        cmd.Parameters.Add(parm);
                    }
                }
            }
        }
    }
}
