﻿using DIO;
using HelperClassLib;
using Master;
using Master.CommonClass;
using Program;
using System;
using System.Collections.Generic;


public static class ObjectList
{
    public static bool globalblock = false;


    #region AXIS OBJECT LIST
    /// <summary>
    /// way Create a object for Advantech PCI card connected Access.
    /// if Devices is connected in Series Axix will start from zero to List of Connected Devices.
    /// Stepper Drive Connected in Series card will consider as a Posistion of the Derive as a Axis.
    /// It start from "0".
    /// </summary>

    public static Advantech_PCIE X1 = new Advantech_PCIE(0, "X1");
    public static Advantech_PCIE X2 = new Advantech_PCIE(1, "X2");
    public static Advantech_PCIE ZAxis2 = new Advantech_PCIE(0, "Z2");
    public static Advantech_PCIE YAxis1 = new Advantech_PCIE(0, "Y1");
    public static Advantech_PCIE XAxis1 = new Advantech_PCIE(0, "X1");
    public static Advantech_PCIE XAxis2 = new Advantech_PCIE(0, "X2");
    public static Advantech_PCIE YAxis2 = new Advantech_PCIE(0, "Y2");
    public static Advantech_PCIE YAxis3 = new Advantech_PCIE(0, "Y3");
    public static Advantech_PCIE XAxis3 = new Advantech_PCIE(0, "X3");
    public static Advantech_PCIE RAxis1 = new Advantech_PCIE(0, "R1");
    public static Advantech_PCIE RAxis2 = new Advantech_PCIE(0, "R2");

    //For Servo
    public static Advantech_PCIE Servo_X1 = new Advantech_PCIE((int)DIDO.EAxis.Servo_X1, DIDO.EAxis.Servo_X1.ToString(), GlobalVariable.g_lstAxisConfig[(int)DIDO.EAxis.Servo_X1].pulse_mm);
    public static Advantech_PCIE Servo_Y1 = new Advantech_PCIE((int)DIDO.EAxis.Servo_Y1, DIDO.EAxis.Servo_Y1.ToString(), GlobalVariable.g_lstAxisConfig[(int)DIDO.EAxis.Servo_Y1].pulse_mm);
    public static Advantech_PCIE Servo_Z1 = new Advantech_PCIE((int)DIDO.EAxis.Servo_Z1, DIDO.EAxis.Servo_Z1.ToString(), GlobalVariable.g_lstAxisConfig[(int)DIDO.EAxis.Servo_Z1].pulse_mm);

    //For Stepper  (if connected in Axis)
    public static Advantech_PCIE Stepper_1 = new Advantech_PCIE((int)DIDO.EAxis.Stepper_1, DIDO.EAxis.Stepper_1.ToString(), GlobalVariable.g_lstAxisConfig[(int)DIDO.EAxis.Stepper_1].pulse_mm);
    public static Advantech_PCIE Stepper_2 = new Advantech_PCIE((int)DIDO.EAxis.Stepper_2, DIDO.EAxis.Stepper_2.ToString(), GlobalVariable.g_lstAxisConfig[(int)DIDO.EAxis.Stepper_2].pulse_mm);
    public static Advantech_PCIE Stepper_3 = new Advantech_PCIE((int)DIDO.EAxis.Stepper_3, DIDO.EAxis.Stepper_3.ToString(), GlobalVariable.g_lstAxisConfig[(int)DIDO.EAxis.Stepper_3].pulse_mm);

    //**devchange: MUST ADD THE DICTIONARIY AFTER CREATING AN OBJECT (for needed only)
    // for Mapping to Manual screen axis list need to map bellow with all motion axis like bellow
    public static Dictionary<int, Advantech_PCIE> MotorObj = new Dictionary<int, Advantech_PCIE>
        {
            { (int)DIDO.EAxis.Servo_X1, Servo_X1 },
            { (int)DIDO.EAxis.Servo_Y1, Servo_Y1 },
            { (int)DIDO.EAxis.Servo_Z1, Servo_Z1 },
            { (int)DIDO.EAxis.Stepper_1, Stepper_1 },
            { (int)DIDO.EAxis.Stepper_2, Stepper_2 },
            { (int)DIDO.EAxis.Stepper_3, Stepper_3 },

        };
    #endregion


    #region TCPIP OBJECT LIST
    /// <summary>
    /// Way to create a TCPIP Object.       
    /// </summary>
    public static SocketClient CCD1 = new SocketClient("CCD1");
    public static SocketClient CCD2 = new SocketClient("CCD2");
    public static SocketClient CCD3 = new SocketClient("CCD3");
    public static SocketClient CCD4 = new SocketClient("CCD4");
    public static SocketClient CCD5 = new SocketClient("CCD5");

    public static SocketClient SFC = new SocketClient("SFC");

    public static SocketClient Scanner1 = new SocketClient("Scanner1");
    public static SocketClient Scanner2 = new SocketClient("Scanner2");

    public static SocketClient Robot = new SocketClient("Robot");
    public static SocketClient RobotSts = new SocketClient("Robot_Auto");
    public static SocketClient RobotErr = new SocketClient("RobotError");

    public static Serial_Communication OPT = new Serial_Communication("COM5");
    public static Serial_Communication OPT2 = new Serial_Communication("OPT2");

    //**devchange: MUST ADD THE DICTIONARIY AFTER CREATING AN OBJECT (for needed only)

    #region INIT OBJECT DICTIONARIES
    public static Dictionary<int, SocketClient> CCDObj = new Dictionary<int, SocketClient>()
    {
         { 0, CCD1 },
         { 1, CCD2},
         { 2, CCD3 },
         { 3, CCD4 },
         { 4, CCD5 },
    };
    public static Dictionary<int, SocketClient> ScnrObj = new Dictionary<int, SocketClient>()
    {
         { 0, Scanner1 },
         { 1, Scanner2 },
    };
    public static Dictionary<int, SocketClient> RoboObj = new Dictionary<int, SocketClient>()
    {
        { 0, Robot },
        { 1, RobotSts },
        { 2, RobotErr },
    };
    public static Dictionary<int, Serial_Communication> COMObj = new Dictionary<int, Serial_Communication>
        {
            { 0, OPT},
            { 1, OPT2},
        };
    #endregion

    public static void ConnectAllObj()
    {
        // Connect all CCD objects
        foreach (var kvp in CCDObj)
        {
            try
            {
                kvp.Value.ConnectAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to connect CCD {kvp.Key}: {ex.Message}");
            }
        }

        // Connect all Scanner objects
        foreach (var kvp in ScnrObj)
        {
            try
            {
                kvp.Value.ConnectAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to connect Scanner {kvp.Key}: {ex.Message}");
            }
        }

        // Connect all Robo objects
        foreach (var kvp in RoboObj)
        {
            try
            {
                kvp.Value.ConnectAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to connect Robo {kvp.Key}: {ex.Message}");
            }
        }


        foreach (var kvp in COMObj)
        {
            try
            {
                kvp.Value.Connect_OPT();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to connect COMPORT {kvp.Key}: {ex.Message}");
            }
        }




    }

    #endregion



    /// <summary>
    /// Way to create a SQLConnection.       
    /// </summary>
    //public static SqlHelper SQL_Helper = new SqlHelper(GlobalVariable.SQL_SqlConnectionString);

}
