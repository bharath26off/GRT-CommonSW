﻿using ExceptionLib;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.IO;
namespace Master
{

    /******************************************************************************
    *              MACHINE SPECIFIC GLOBAL VARIABLES CONFIGURATION                 
    *              [interlocks, variables, receipes]
    *******************************************************************************/

    //**devchange: change the variables according the machine
    public partial class GlobalVariable
    {

        #region  ROBOT VARIABLES
        public static bool g_RoboSafePos = false;
        public static bool g_RobotSeqRun = false;
        public static string g_RobotCmd = string.Empty;
        public static string g_RobotErrCmd = string.Empty;
        public static string g_RobotStatus = string.Empty;
        public static string g_RobotResult = string.Empty;
        public static string g_RobotSeqCmd = string.Empty;
        public static double g_RoboXValue;
        public static double g_RoboYValue;
        public static double g_RobotAngle;
        public static double g_RobotHValue;
        public static int g_RobotretryCount = 3;

        #endregion


        #region VISION VARIABLES
        public static string g_VisionCmd = string.Empty;
        public static string g_VisionStatus = string.Empty;
        public static string g_VisionResult = string.Empty;
        public static int g_VisionretryCount = 3;
        public static List<string> g_VisionObservation = new List<string>();

        #endregion

        #region  TOSSING SEQUENCE VARIABLES
        public static string g_TossingCmd = string.Empty;
        public static string g_TossingResult = string.Empty;
        #endregion


        #region CONVEYOR MOTOR SPEEDS

        public static int LoadingConveyorDir = 0;
        public static double LoadingConveyorVelocity = 1000;
        public static double LoadingConveyorAcc = 1000;
        public static double LoadingConveyorDeAcc = 1000;
        public static int WorkingConveyorDir = 0;
        public static double WorkingConveyorVelocity = 1000;
        public static double WorkingConveyorAcc = 1000;
        public static double WorkingConveyorDeAcc = 1000;
        public static int UnLoadingConveyorDir = 0;
        public static double UnLoadingConveyorVelocity = 1000;
        public static double UnLoadingConveyorAcc = 1000;
        public static double UnLoadingConveyorDeAcc = 1000;

        public static bool IsBTHLoadingFeeder_Run = false;
        public static bool IsBTHInspection_Run = false;

        public static bool LoadingConvWrk = false;
        public static bool WorkingConvWrk = false;
        public static bool UnLoadingConvWrk = false;

        #endregion


        #region RECEIPE SCREEN HELPERS and RECEIPE VARIABLES

        //Receipe
        public static double[] Receipe_Pressing_X = new double[2];
        public static double[] Receipe_Pressing_XVel = new double[2];
        public static double[] Receipe_Pressing_XAcc = new double[2];
        public static double[] Receipe_Pressing_XDeAcc = new double[2];
        public static double[] Receipe_Pressing_Z = new double[2];
        public static double[] Receipe_Pressing_ZVel = new double[2];
        public static double[] Receipe_Pressing_ZAcc = new double[2];
        public static double[] Receipe_Pressing_ZDeAcc = new double[2];

        public static double[] Receipe_Inspection_X = new double[9];
        public static double[] Receipe_Inspection_XVel = new double[9];
        public static double[] Receipe_Inspection_XAcc = new double[9];
        public static double[] Receipe_Inspection_XDeAcc = new double[9];
        public static double[] Receipe_Inspection_Y = new double[9];
        public static double[] Receipe_Inspection_YVel = new double[9];
        public static double[] Receipe_Inspection_YAcc = new double[9];
        public static double[] Receipe_Inspection_YDeAcc = new double[9];
        public static double[] Receipe_BTH = new double[15];
        public static double[] Receipe_BTHVel = new double[15];
        public static double[] Receipe_BTHAcc = new double[15];
        public static double[] Receipe_BTHDeAcc = new double[15];

        public static double Recipe_RoboSpeed;
        public static double Recipe_RoboPickDelay;
        public static double Recipe_RoboplaceDelay;

        public static DataTable LoadCsvData(string filePath)
        {
            string[] csvLines;
            DataTable dataTable = new DataTable();
            try
            {
                if (File.Exists(filePath))
                {
                    csvLines = File.ReadAllLines(filePath);

                    if (csvLines.Length > 0)
                    {
                        //Add columns to DataTable
                        string[] headers = csvLines[0].Split(',');
                        headers = headers.Take(5).ToArray();
                        //string toremove = headers[0];
                        //headers = headers.Where(x => x != toremove).ToArray();
                        foreach (string header in headers)
                        {
                            dataTable.Columns.Add(header);
                        }

                        //Add rows to DataTable
                        for (int i = 1; i < csvLines.Length; i++)
                        {
                            string[] data = csvLines[i].Split(',');
                            data = data.Take(5).ToArray();
                            //string elementToRemove = data[1];
                            //data = data.Where(x => x != elementToRemove).ToArray();
                            dataTable.Rows.Add(data);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Recipe Param File is missing", "Recipe Group Manager Software", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "GlobalVariable", "", ex.Message, ex.ToString());
            }
            return dataTable;
        }
        public static void LoadReceipe()
        {
            try
            {
                DataTable dataTable = new DataTable();
                dataTable = HelperClassLib.GetDataFromHelper.GetDataFromCSV(Environment.CurrentDirectory + @"\Data\PressingModuleReceipe_Param.csv");
                LoadReceipeTables(dataTable, "PRESSINGMODULE");
                dataTable = HelperClassLib.GetDataFromHelper.GetDataFromCSV(Environment.CurrentDirectory + @"\Data\InspectionModuleReceipe_Param.csv");
                LoadReceipeTables(dataTable, "INSPECTIONMODULE");
                dataTable = HelperClassLib.GetDataFromHelper.GetDataFromCSV(Environment.CurrentDirectory + @"\Data\BTHGantryReceipe_Param.csv");
                LoadReceipeTables(dataTable, "BTHGANTRY");
                dataTable = HelperClassLib.GetDataFromHelper.GetDataFromCSV(Environment.CurrentDirectory + @"\Data\RoboReceipe_Param.csv");
                LoadReceipeTables(dataTable, "ROBOT");
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "GlobalVariable", "", ex.Message, ex.ToString());
            }
        }
        public static void LoadReceipeTables(DataTable dt, string Gantry)
        {
            try
            {
                if (Gantry.ToUpper() == "ROBOT")
                {
                    Recipe_RoboSpeed = Convert.ToDouble(dt.Rows[0][1].ToString());
                    Recipe_RoboPickDelay = Convert.ToDouble(dt.Rows[1][1].ToString());
                    Recipe_RoboplaceDelay = Convert.ToDouble(dt.Rows[2][1].ToString());
                }
                else
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (Gantry.ToUpper() == "PRESSINGMODULE")
                        {
                            Receipe_Pressing_X[i] = Convert.ToDouble(dt.Rows[i]["X"].ToString());
                            Receipe_Pressing_Z[i] = Convert.ToDouble(dt.Rows[i]["Z"].ToString());

                            Receipe_Pressing_XVel[i] = Convert.ToDouble(dt.Rows[i][2].ToString());
                            Receipe_Pressing_XAcc[i] = Convert.ToDouble(dt.Rows[i][3].ToString());
                            Receipe_Pressing_XDeAcc[i] = Convert.ToDouble(dt.Rows[i][4].ToString());

                            Receipe_Pressing_ZVel[i] = Convert.ToDouble(dt.Rows[i][10].ToString());
                            Receipe_Pressing_ZAcc[i] = Convert.ToDouble(dt.Rows[i][11].ToString());
                            Receipe_Pressing_ZDeAcc[i] = Convert.ToDouble(dt.Rows[i][12].ToString());
                        }
                        else if (Gantry.ToUpper() == "INSPECTIONMODULE")
                        {
                            Receipe_Inspection_X[i] = Convert.ToDouble(dt.Rows[i]["X"].ToString());
                            Receipe_Inspection_Y[i] = Convert.ToDouble(dt.Rows[i]["Y"].ToString());

                            Receipe_Inspection_XVel[i] = Convert.ToDouble(dt.Rows[i][2].ToString());
                            Receipe_Inspection_XAcc[i] = Convert.ToDouble(dt.Rows[i][3].ToString());
                            Receipe_Inspection_XDeAcc[i] = Convert.ToDouble(dt.Rows[i][4].ToString());

                            Receipe_Inspection_YVel[i] = Convert.ToDouble(dt.Rows[i][6].ToString());
                            Receipe_Inspection_YAcc[i] = Convert.ToDouble(dt.Rows[i][7].ToString());
                            Receipe_Inspection_YDeAcc[i] = Convert.ToDouble(dt.Rows[i][8].ToString());
                        }
                        else if (Gantry.ToUpper() == "BTHGANTRY")
                        {
                            Receipe_BTH[i] = Convert.ToDouble(dt.Rows[i]["X"].ToString());

                            Receipe_BTHVel[i] = Convert.ToDouble(dt.Rows[i][2].ToString());
                            Receipe_BTHAcc[i] = Convert.ToDouble(dt.Rows[i][3].ToString());
                            Receipe_BTHDeAcc[i] = Convert.ToDouble(dt.Rows[i][4].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(Logger.LogType.Error, "GlobalVariable", "", ex.Message, ex.ToString());
            }
        }
        #endregion
    }
}
